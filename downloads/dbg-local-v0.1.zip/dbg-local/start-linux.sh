#!/bin/sh
set -eu
dbgdesk_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$dbgdesk_dir"
exec python3 server.py "$@"
