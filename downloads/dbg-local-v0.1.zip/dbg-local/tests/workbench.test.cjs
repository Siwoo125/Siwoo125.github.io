const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const english=process.argv.includes('--en');
class Element {
  constructor(){this.value='';this.textContent='';this.children=[];this.dataset={};this.handlers={};this.open=false;this.checked=false;this.classList={add(){},remove(){},toggle(){}};}
  addEventListener(name,handler){this.handlers[name]=handler;}
  append(...nodes){this.children.push(...nodes);if(!this.value&&nodes[0]?.value)this.value=nodes[0].value;}
  replaceChildren(){this.children=[];this.value='';}
  setAttribute(){} click(){if(this.onclick)return this.onclick();}
  focus(){} scrollIntoView(){} remove(){} showModal(){this.open=true;} close(){this.open=false;}
  querySelector(){for(const child of this.children){if(child.onclick)return child;const result=child.querySelector?.();if(result)return result;}return null;}
}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Element());return nodes.get(id);};
get('args').value='[]';get('address').value='$sp';
let state='idle',stopSequence=0,rax='0x1',memory='0011',commands=[],downloads=[];
const snapshot=()=>({state,path:'/tmp/target',engine:'gdb',target_id:1,stop_sequence:stopSequence,
  stop:{reason:'end-stepping-range',frame:{addr:'0x100',func:'main'}},errors:{},events:[],
  registers:state==='stopped'?[{name:'rax',value:rax}]:[],assembly:state==='stopped'?[{address:'0x100',inst:'nop'}]:[],
  stack:state==='stopped'?[{frame:{level:'0',func:'main',addr:'0x100'}}]:[],memory:state==='stopped'?[{begin:'0x200',contents:memory}]:[],breakpoints:[]});
const document={documentElement:{lang:english?'en':'ko'},hidden:false,body:new Element(),getElementById:get,
  createElement:()=>new Element(),addEventListener(){},querySelector:()=>new Element(),querySelectorAll:selector=>selector==='.reg'?get('registers').children:[]};
const context={document,window:{DBGInspector:require('../web/inspector.js'),DBG_I18N:english?JSON.parse(fs.readFileSync('content/en/ui.json','utf8')):{},addEventListener(){}},
  location:{hash:'',pathname:'/'},history:{replaceState(){}},sessionStorage:{getItem:()=> 'AUTH_SECRET',setItem(){}},URLSearchParams,
  Blob,URL:{createObjectURL(blob){downloads.push(blob);return 'blob:test';},revokeObjectURL(){}},setInterval(){},setTimeout(){},
  async fetch(url,options){
    if(url==='/api/state')return {ok:true,json:async()=>({result:snapshot()})};
    const data=JSON.parse(options.body);commands.push(data);
    return {ok:true,json:async()=>({result:{}})};
  }};
vm.createContext(context);vm.runInContext(fs.readFileSync('web/workbench.js','utf8'),context);vm.runInContext(fs.readFileSync('web/app.js','utf8'),context);
const run=code=>vm.runInContext(code,context);
(async()=>{
  await new Promise(resolve=>setImmediate(resolve));
  const workbench=run('workbench');
  assert.equal(workbench.records.length,0);
  state='stopped';stopSequence=1;await run('refresh()');
  assert.equal(workbench.records.length,1);
  await run('refresh()');assert.equal(workbench.records.length,1,'polling does not duplicate one stop');
  stopSequence=2;rax='0x2';memory='0012';await run('refresh()');
  assert.equal(workbench.records.length,2,'two stops at the same PC are recorded separately');
  assert.equal(get('snapshot-diff').children.length,2,'register and byte changes are displayed');
  workbench.update(null);assert.equal(workbench.records.length,2,'control refresh handles the saved stopped state');
  workbench.saveReport();const report=await downloads.at(-1).text();assert(report.includes('0x2'));assert(!report.includes('AUTH_SECRET'));
  const settings={type:'dbgdesk-workspace',version:1,path:'/tmp/another',args:['hello'],memoryAddress:'0x300',breakpoints:['main','*0x100']};
  commands=[];
  await workbench.importWorkspace({size:80,text:async()=>JSON.stringify(settings)});
  assert.equal(workbench.pending.length,0,'import is rejected while a target is live and stopped');
  state='idle';await run('refresh()');
  await workbench.importWorkspace({size:80,text:async()=>JSON.stringify(settings)});
  assert.equal(get('path').value,'/tmp/another');assert.equal(get('args').value,'["hello"]');
  assert.equal(workbench.pending.length,2);assert.equal(commands.length,0,'import prepares data and does not issue debugger commands');
  state='loaded';await run('refresh()');await workbench.applyWorkspace();
  assert.deepEqual(commands.map(c=>c.action),['break-add','break-add']);assert.equal(workbench.pending.length,0);
  assert(!commands.some(c=>['run','load','attach'].includes(c.action)));
  state='stopped';stopSequence=3;await run('refresh()');
  workbench.openPalette();get('palette-query').value='rax';workbench.renderPalette();
  assert(get('palette-results').children[0].children[0].textContent.includes('rax'));
  get('palette-results').children[0].children[0].click();assert.equal(get('command-palette').open,false);
  for(let i=4;i<58;i++){stopSequence=i;await run('refresh()');}
  assert.equal(workbench.records.length,50,'history is bounded');
  assert.equal(workbench.records[0].stop_sequence,8);
  console.log('Workbench '+(english?'EN':'KO')+': history, same-PC stops, diffs, report download, no-execution workspace import, breakpoint apply, palette and 50-record limit passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
