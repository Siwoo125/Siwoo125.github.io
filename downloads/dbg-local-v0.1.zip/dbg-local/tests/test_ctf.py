import os
import shutil
import struct
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import Mock
from binary_info import inspect_binary
from debugger import Debugger
from inferior_io import TargetIO


class CTFGuardTests(unittest.TestCase):
    def engine(self):
        engine=Debugger();engine.state='stopped';engine.command=Mock(return_value={});return engine

    def test_edits_cannot_run_while_target_is_running(self):
        engine=self.engine();engine.state='running'
        for action in ('memory-write','register-write'):
            with self.assertRaises(ValueError):engine.action(action,{})
        engine.command.assert_not_called()

    def test_invalid_writes_do_not_touch_target(self):
        engine=self.engine()
        for data in [{'address':'$pc','hex':'90'},{'address':'0x1','hex':'0'},{'address':'0x1','hex':'zz'}, {'address':'0x1','hex':'90'*257}]:
            with self.assertRaises(ValueError):engine.action('memory-write',data)
        for data in [{'name':'rax\n-exec-run','value':'1'},{'name':'rax','value':'system(0)'},{'name':'rax','value':str(1<<64)}]:
            with self.assertRaises(ValueError):engine.action('register-write',data)
        engine.selected_frame=1
        with self.assertRaises(ValueError):engine.action('register-write',{'name':'rax','value':'1'})
        engine.command.assert_not_called()

    def test_memory_readback_failure_is_reported(self):
        engine=self.engine();engine.command.side_effect=[{'memory':[{'contents':'00'}]}, {}, {'memory':[{'contents':'00'}]}]
        with self.assertRaises(RuntimeError):engine.action('memory-write',{'address':'0x1234','hex':'90'})

    def test_input_bytes_never_become_gdb_commands(self):
        engine=self.engine();engine.input_mode='pty';engine.target_io.send=Mock(return_value=4)
        self.assertEqual(engine.action('input-send',{'mode':'hex','value':'41 00 42 0a'}),{'sent':4})
        engine.target_io.send.assert_called_once_with(b'A\x00B\n');engine.command.assert_not_called()
        engine.attached=True
        with self.assertRaises(ValueError):engine.action('input-send',{'value':'hello'})

    def test_address_expressions_are_not_arbitrary_gdb_expressions(self):
        for expression in ('$rdi+0x10','$pc-4','0x1234','1234'):
            self.assertEqual(Debugger.address_expression(expression),expression)
        for expression in ('system(0)','*$pc','$pc;run','$rax+foo','$pc\n-exec-run',None):
            with self.assertRaises(ValueError):Debugger.address_expression(expression)

    def test_truncated_elf_and_out_of_range_pe_header_are_bounded(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'file'
            for data in (b'\x7fELF', b'MZ'+b'\0'*58+struct.pack('<I',0xfffffff0)):
                path.write_bytes(data);self.assertIn('header_error',inspect_binary(path))
            path.write_bytes(b'\0flag{demo}\0')
            info=inspect_binary(path);self.assertEqual(info['strings'][0],{'offset':'0x1','text':'flag{demo}'})

    @unittest.skipUnless(os.name=='posix','POSIX PTY only; Windows uses target console')
    def test_pty_bytes_and_output_are_separate_from_gdb(self):
        terminal=TargetIO()
        try:
            terminal.open();self.assertEqual(terminal.send(b'A\x00B\n'),4)
            self.assertEqual(os.read(terminal.slave,4),b'A\x00B\n')
            os.write(terminal.slave,'한글 output'.encode())
            deadline=time.monotonic()+3
            while 'output' not in terminal.text() and time.monotonic()<deadline:time.sleep(.02)
            self.assertIn('한글 output',terminal.text())
        finally:terminal.close()
        self.assertIsNone(terminal.master);self.assertIsNone(terminal.slave)


@unittest.skipUnless(shutil.which('gdb') and shutil.which('gcc'), 'native GDB and GCC required')
class NativeCTFTests(unittest.TestCase):
    def wait_for(self, predicate, debugger):
        deadline=time.monotonic()+20
        while not predicate() and time.monotonic()<deadline:time.sleep(.03)
        self.assertTrue(predicate(),list(debugger.events)[-12:])

    def compile(self, source, directory, stripped=False):
        binary=str(Path(directory)/('ctf.exe' if os.name=='nt' else 'ctf'))
        subprocess.run(['gcc','-O0','-g' if not stripped else '-s',source,'-o',binary],check=True)
        return binary

    def test_native_pe_or_elf_memory_register_edits_solve_gate(self):
        with tempfile.TemporaryDirectory() as folder:
            binary=self.compile('examples/ctf_gate.c',folder)
            engine=Debugger()
            try:
                engine.start();engine.action('load',{'path':binary})
                self.assertEqual(engine.binary_info['format'],'PE' if os.name=='nt' else 'ELF')
                self.assertEqual(engine.input_mode,'console' if os.name=='nt' else 'pty',engine.input_error)
                engine.action('break-add',{'location':'checkpoint'});engine.action('run',{})
                self.wait_for(lambda:engine.state=='stopped',engine)
                for name,contents in [('gate','37130000'),('tag','50415353')]:
                    address=engine.action('symbol-address',{'name':name})['address']
                    engine.action('memory-write',{'address':address,'hex':contents})
                state=engine.snapshot();name='rax' if any(r['name']=='rax' for r in state['registers']) else 'eax'
                original=next(r['value'] for r in state['registers'] if r['name']==name)
                result=engine.action('register-write',{'name':name,'value':'0x2a'})
                self.assertEqual(int(result['after'][0]['value'],16),42)
                engine.action('register-write',{'name':name,'value':original})
                sequence=engine.stop_sequence;engine.action('finish',{})
                self.wait_for(lambda:engine.state=='stopped' and engine.stop_sequence>sequence,engine)
                self.assertEqual(engine.command('-data-evaluate-expression "$eax"')['value'],'1')
                engine.action('continue',{});self.wait_for(lambda:engine.state=='exited',engine)
            finally:engine.close()

    def test_stripped_binary_stops_without_main_symbol(self):
        with tempfile.TemporaryDirectory() as folder:
            binary=self.compile('examples/ctf_gate.c',folder,True);engine=Debugger()
            try:
                engine.start();engine.action('load',{'path':binary});engine.action('entry',{})
                self.wait_for(lambda:engine.state=='stopped',engine)
                self.assertTrue(engine.snapshot()['assembly'])
                engine.action('detach',{})
            finally:engine.close()

    @unittest.skipUnless(os.name=='posix','Web input uses POSIX PTY; Windows uses target console')
    def test_elf_accepts_nul_and_newline_from_web_input(self):
        with tempfile.TemporaryDirectory() as folder:
            binary=self.compile('examples/ctf_input.c',folder);engine=Debugger()
            try:
                engine.start();engine.action('load',{'path':binary});engine.action('break-add',{'location':'input_done'})
                engine.action('run',{});self.wait_for(lambda:'payload>' in engine.target_io.text(),engine)
                self.assertEqual(engine.action('input-send',{'mode':'hex','value':'4100420a'})['sent'],4)
                self.wait_for(lambda:engine.state=='stopped',engine)
                self.assertEqual(engine.snapshot()['frame']['func'],'input_done')
                engine.action('continue',{});self.wait_for(lambda:engine.state=='exited',engine)
                self.wait_for(lambda:'bytes=4100420a' in engine.target_io.text(),engine)
            finally:engine.close()
