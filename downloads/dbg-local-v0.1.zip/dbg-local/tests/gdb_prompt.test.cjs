'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('web/gdb-download-prompt.js','utf8');
function scenario() {
 const events={},closed=[];let shown=0;
 const button=name=>({addEventListener(event,handler){events[name]=handler;}});
 const elements={'setup':{open:false},'cpu-gdb-download':button('reopen'),'gdb-download-link':button('download'),'gdb-setup-link':button('setup')};
 elements['gdb-download-dialog']={showModal(){shown++;},close(value){closed.push(value);},querySelectorAll:()=>[button('dismiss')]};
 vm.runInNewContext(source,{document:{getElementById:id=>elements[id]}});
 return {events,closed,elements,get shown(){return shown;}};
}
const p=scenario();assert.equal(p.shown,1);assert.deepEqual(p.closed,[]);
p.events.dismiss();assert.deepEqual(p.closed,['browser']);p.events.reopen();assert.equal(p.shown,2);
p.events.download();assert.equal(p.closed.at(-1),'download');
p.events.setup();assert.equal(p.elements.setup.open,true);assert.equal(p.closed.at(-1),'setup');
assert.doesNotThrow(()=>vm.runInNewContext(source,{document:{getElementById:()=>null}}));
console.log('GDB prompt: immediate modal, no automatic download, dismiss/reopen and setup disclosure passed');
