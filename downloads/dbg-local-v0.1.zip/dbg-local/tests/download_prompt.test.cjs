const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const code = fs.readFileSync('web/download-prompt.js', 'utf8');
function visit(storage, lang = 'ko') {
  const handlers = {};
  let shown = 0, closed = 0, appended = 0;
  const dialog = {
    innerHTML: '', setAttribute() {},
    querySelector(selector) { return {addEventListener(event, handler) { handlers[selector] = handler; }}; },
    addEventListener(event, handler) { handlers[event] = handler; },
    showModal() { shown++; }, close() { closed++; },
  };
  vm.runInNewContext(code, {
    localStorage: {getItem(key) { return storage[key]; }, setItem(key, value) { storage[key] = value; }},
    document: {documentElement: {lang}, createElement() { return dialog; }, body: {append() { appended++; }}},
    fetch() { throw Error('Download started before approval'); },
  });
  return {dialog, handlers, get shown() {return shown;}, get closed() {return closed;}, get appended() {return appended;}};
}
for (const lang of ['ko', 'en']) {
  const storage = {};
  const first = visit(storage, lang);
  assert.equal(first.shown, 1);
  assert.ok(first.dialog.innerHTML.includes('download href="/downloads/dbg-local-v0.1.zip"'));
  first.handlers['[data-later]']();
  assert.equal(first.closed, 1);
  assert.equal(visit(storage, lang).appended, 0, 'Later persists across navigation');
  const accepted = {};
  const second = visit(accepted, lang);
  second.handlers['[data-download]']({preventDefault() {throw Error('Default download was blocked');}});
  assert.equal(second.closed, 1);
  assert.equal(visit(accepted, lang).shown, 0, 'Download choice persists');
}
console.log('First-visit prompt, dismissal and consent download behavior passed');
