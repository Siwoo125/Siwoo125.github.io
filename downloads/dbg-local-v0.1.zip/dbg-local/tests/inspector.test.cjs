const assert=require('node:assert/strict');
const I=require('../web/inspector.js');
const native={state:'stopped',target_id:1,stop_sequence:1,path:'C:\\private\\target.exe',engine:'C:\\tools\\gdb.exe',
  stop:{reason:'breakpoint-hit',frame:{addr:'0x100',func:'main'}},
  registers:[{name:'rax',value:'0x01'},{name:'rip',value:'0x100'}],
  memory:[{begin:'0x200',contents:'0011aaff'}],assembly:[{address:'0x100',opcodes:'90',inst:'nop'}],
  stack:[{frame:{level:'0',func:'main',addr:'0x100',file:'C:\\private\\main.c',line:'4'}}],
  breakpoints:[{bkpt:{'original-location':'main'}},{bkpt:{'original-location':'main'}}],
  events:['PRIVATE_LOG'],errors:{},token:'NEVER_EXPORT',args:['SECRET_ARG']};
const a=I.capture(native,'$sp','2026-10-17T01:00:00Z');
native.registers[0].value='0xff';
assert.equal(a.registers[0].value,'0x01','recorded state is not a reference to live state');
assert.equal(a.token,undefined);assert.equal(a.args,undefined);
const b=JSON.parse(JSON.stringify(a));b.registers=[{name:'rax',value:'0x1'},{name:'rip',value:'0x101'},{name:'rbx',value:'0x2'}];b.memory=[{begin:'0x0200',contents:'0012aaff'}];
let diff=I.compare(a,b);
assert.deepEqual(diff.registers.map(r=>r.name),['rip','rbx'],'equivalent numeric spellings do not produce changes');
assert.deepEqual(diff.memory,[{address:'0x201',before:'11',after:'12'}]);
assert.equal(diff.memoryAvailable,true);
const c=JSON.parse(JSON.stringify(b));c.registers=[];c.memory=[];c.target_id=2;c.memoryAddress='0x300';
diff=I.compare(b,c);assert.equal(diff.registers[0].after,null);assert.equal(diff.memory[0].after,null);
assert.equal(diff.memoryAvailable,false);assert.equal(diff.differentTarget,true);assert.equal(diff.differentRange,true);
assert.equal(I.memoryBytes([{begin:'bad',contents:'00'},{begin:'0x0',contents:'xx'}]).size,0);
assert.throws(()=>I.capture({state:'running'},'$sp'));
const workspace=I.workspace(a,{path:a.path,args:['a b','한글'],memoryAddress:'$sp'});
assert.deepEqual(workspace.breakpoints,['main']);
assert.deepEqual(workspace.args,['a b','한글']);
assert.equal(workspace.token,undefined);
const input={...workspace,token:'ignore',commands:['run'],__proto__:{polluted:true}};
const clean=I.validateWorkspace(input);assert.equal(clean.commands,undefined);assert.equal(clean.polluted,undefined);
for(const change of [{version:2},{args:'run'},{args:[null]},{breakpoints:['main\n-exec-run']},{memoryAddress:'system("calc")'},{path:'bad\0path'},{breakpoints:Array(129).fill('main')}]){
  assert.throws(()=>I.validateWorkspace({...workspace,...change}));
}
const report=I.report(a);
assert(report.includes('target.exe'));assert(report.includes('main.c:4'));
assert(!report.includes('C:\\private'));assert(!report.includes('NEVER_EXPORT'));assert(!report.includes('SECRET_ARG'));assert(!report.includes('PRIVATE_LOG'));
assert(!report.includes('0011aaff'));
const detailed=I.report(a,{memory:true,logs:true});assert(detailed.includes('0011aaff'));assert(detailed.includes('PRIVATE_LOG'));
const hostile=JSON.parse(JSON.stringify(a));hostile.assembly[0].inst='```\n# injected';
assert(I.report(hostile).includes('````\n'),'code fences grow to contain target-controlled text safely');
console.log('Snapshot immutability, register/byte diffs, missing ranges, workspace validation, and report privacy passed.');
const otherFrame={...a,selected_frame:2,current_thread:'3'};
assert.equal(I.compare(a,otherFrame).differentContext,true);
assert(I.report(otherFrame).includes('Thread: 3 / Frame: 2'));
for(const extra of [{cond:'value == 2'},{ignore:'3'},{enabled:'n'},{disp:'del'},{type:'hw watchpoint'}]){
  assert.throws(()=>I.workspace({...a,breakpoints:[{bkpt:{'original-location':'main',...extra}}]},{path:'target',args:[],memoryAddress:'$sp'}),/Advanced breakpoint settings would be lost/);
}
