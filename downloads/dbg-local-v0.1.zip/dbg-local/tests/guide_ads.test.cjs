'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('web/guide-ads.js','utf8');
function page(origin,{client='ca-pub-4642715416425714',hasSlot=true,hasDialog=false}={}) {
  const appended=[],slot={dataset:{adClient:client}},queue=[{existing:true}],footer=[];
  let close;
  const context={location:{origin},window:{adsbygoogle:queue},document:{
    currentScript:{dataset:{adOrigin:'https://dbgdesk.pages.dev',adClient:client}},
    documentElement:{lang:'ko'},querySelectorAll:()=>hasSlot?[slot]:[],
    getElementById:()=>hasDialog?{addEventListener(event,handler){assert.equal(event,'close');close=handler;}}:null,
    querySelector:()=>({append:node=>footer.push(node)}),
    createElement:()=>({addEventListener(event,handler){this[event]=handler;}}),head:{append:node=>appended.push(node)}
  }};
  vm.runInNewContext(source,context);
  return {appended,slot,queue,context,footer,close};
}
for(const origin of ['http://127.0.0.1:8890','http://localhost:8765','https://siwoo125.github.io','https://preview.dbgdesk.pages.dev','http://dbgdesk.pages.dev']) {
 const result=page(origin);assert.equal(result.appended.length,0,origin);assert.equal(result.queue.length,1,origin);
}
const live=page('https://dbgdesk.pages.dev');assert.equal(live.appended.length,1);
const gated=page('https://dbgdesk.pages.dev',{hasDialog:true});assert.equal(gated.appended.length,0);gated.close();assert.equal(gated.appended.length,1);
assert.equal(live.appended[0].src,'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4642715416425714');
assert.equal(live.appended[0].async,true);assert.equal(live.appended[0].crossOrigin,'anonymous');
assert.equal(live.queue.length,2);assert.equal(live.slot.dataset.adRequested,'true');
let consentCallback,revocations=0;
live.context.window.__tcfapi=(command,version,callback)=>{assert.equal(command,'addEventListener');consentCallback=callback;};
live.context.window.googlefc.showRevocationMessage=()=>revocations++;
live.context.window.googlefc.callbackQueue[0].CONSENT_API_READY();
consentCallback({gdprApplies:false},true);assert.equal(live.footer.length,0);
consentCallback({gdprApplies:true},true);assert.equal(live.footer.length,1);
consentCallback({gdprApplies:true},true);assert.equal(live.footer.length,1);
assert.equal(live.footer[0].textContent,'개인정보 및 쿠키 설정');live.footer[0].click();assert.equal(revocations,1);
consentCallback({gdprApplies:false},true);assert.equal(live.footer[0].hidden,true);
assert.equal(page('https://dbgdesk.pages.dev',{hasSlot:false}).appended.length,0);
assert.equal(page('https://dbgdesk.pages.dev',{client:'invalid&extra=value'}).appended.length,0);
console.log('Guide ads: approved-origin-only loading, localhost/preview isolation, one slot and existing queue preserved');
