const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
for (const lang of ['ko', 'en']) {
  const elements = new Map();
  function get(id) {
    if (!elements.has(id)) elements.set(id, {
      value: '', textContent: '', disabled: false, dataset: {},
      classList: {toggle() {}, add() {}, remove() {}},
      addEventListener() {}, scrollIntoView() {},
    });
    return elements.get(id);
  }
  let interval;
  const context = {
    document: {documentElement: {lang, dataset: {hosting: 'public'}}, getElementById: get,
      querySelectorAll: () => [], addEventListener() {}, hidden: false},
    window: {addEventListener() {}}, location: {hash: '#token=do-not-use-on-public-host'},
    URLSearchParams, setInterval(callback) { interval = callback; },
    sessionStorage: {getItem() { throw Error('Public host read a local token'); }, setItem() { throw Error('Public host stored a local token'); }},
    fetch() { throw Error('Public workspace called the native API'); },
  };
  vm.runInNewContext(fs.readFileSync('web/app.js', 'utf8'), context);
  assert.equal(get('choose-file').disabled, true);
  assert.equal(get('status').textContent, lang === 'en' ? 'Engine not connected' : '엔진 미연결');
  get('connect').onclick();
  assert.equal(get('engine-setup').open, true);
  interval();
}
console.log('Public workspace opens without reading local tokens or calling native APIs');
