import unittest
from unittest.mock import Mock
from debugger import Debugger

class AdvancedTests(unittest.TestCase):
    def engine(self, state='stopped'):
        engine=Debugger();engine.state=state;engine.command=Mock(return_value={});return engine

    def test_conditional_temporary_and_hit_count_share_one_insert(self):
        engine=self.engine('loaded')
        engine.action('break-add', {'location':'accumulate','condition':'value == 2','ignore':3,'temporary':True})
        engine.command.assert_called_once_with('-break-insert -t -c "value == 2" -i 3 "accumulate"')

    def test_reject_executable_conditions_and_option_injection_before_mutation(self):
        for update in [{'condition':'system(1) == 0'},{'condition':'x = 1'},{'condition':'x++ > 1'},{'condition':'a\n== 1'},
                       {'ignore':True},{'ignore':1000001},{'temporary':'false'},{'location':'-t main'}, {'location':'main\n-exec-run'}]:
            engine=self.engine('loaded')
            with self.subTest(update=update),self.assertRaises(ValueError):engine.action('break-add', {'location':'main',**update})
            engine.command.assert_not_called()

    def test_breakpoint_toggle_and_running_guard(self):
        engine=self.engine();engine.action('break-disable', {'number':'2.1'})
        engine.command.assert_called_with('-break-disable 2.1')
        engine.action('break-enable', {'number':'2.1'});engine.command.assert_called_with('-break-enable 2.1')
        engine.state='running';engine.command.reset_mock()
        for action in ['break-add','break-enable','break-disable','break-delete','watch-add','thread-select','frame-select','run-to']:
            with self.assertRaises(ValueError):engine.action(action,{})
        engine.command.assert_not_called()

    def test_data_watchpoint_restricts_target_to_fixed_width_literal(self):
        engine=self.engine();engine.action('watch-add', {'address':'0x1234','size':8,'mode':'access'})
        engine.command.assert_called_once_with('-break-watch -a "*(unsigned long long*)0x1234"')
        for invalid in [{'address':'malloc(8)'},{'address':'0x1\n-exec-run'},{'size':3},{'mode':'write;run'}]:
            engine.command.reset_mock()
            with self.assertRaises(ValueError):engine.action('watch-add', {'address':'0x1234',**invalid})
            engine.command.assert_not_called()

    def test_context_selection_never_executes(self):
        engine=self.engine();engine.action('frame-select', {'frame':2});self.assertEqual(engine.selected_frame,2)
        engine.action('thread-select', {'thread':3});self.assertEqual(engine.selected_frame,0)
        self.assertEqual([c.args[0] for c in engine.command.call_args_list], ['-stack-select-frame 2','-thread-select 3'])
        for action,data in [('thread-select',{'thread':0}),('frame-select',{'frame':'1;run'})]:
            with self.assertRaises(ValueError):engine.action(action,data)

    def test_run_to_uses_temporary_breakpoint_and_cleans_failed_continue(self):
        engine=self.engine();engine.command.side_effect=[{'bkpt':{'number':'9'}},RuntimeError('cannot continue'),{}]
        with self.assertRaises(RuntimeError):engine.action('run-to',{'address':'0x100'})
        self.assertEqual(engine.state,'stopped')
        self.assertEqual([c.args[0] for c in engine.command.call_args_list], ['-break-insert -t "*0x100"','-exec-continue','-break-delete 9'])

    def test_snapshot_reports_selected_context_and_locals(self):
        engine=self.engine();engine.selected_frame=1
        def command(cmd, **kwargs):
            return {'-thread-info':{'threads':[{'id':'2'}],'current-thread-id':'2'},'-stack-info-frame':{'frame':{'level':'1','func':'main'}},'-stack-list-variables --simple-values':{'variables':[{'name':'x','value':'4'}]}}.get(cmd,{})
        engine.command=command;state=engine.snapshot()
        self.assertEqual(state['current_thread'],'2');self.assertEqual(state['selected_frame'],1)
        self.assertEqual(state['locals'][0]['value'],'4');self.assertEqual(state['frame']['func'],'main')
