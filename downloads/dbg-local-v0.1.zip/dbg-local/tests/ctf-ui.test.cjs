const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const en=process.argv.includes('--en');
class Node {
  constructor(){this.children=[];this.value='';this.checked=false;this.disabled=false;this.textContent='';this.button={};}
  append(...items){this.children.push(...items);} replaceChildren(){this.children=[];}
  querySelector(){return this.button;}
}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Node());return nodes.get(id);};
const document={documentElement:{lang:en?'en':'ko'},getElementById:get,createElement:()=>new Node()};
const context={document,window:{}};vm.runInNewContext(fs.readFileSync('web/ctf.js','utf8'),context);
const commands=[],ui=new context.window.DBGCTF({action:(action,data)=>commands.push({action,...data})});
const state={selected_frame:0,registers:[{name:'rax',value:'0x1'}],binary:{format:'ELF',bits:64,machine:'x86-64',entry:'0x1000',strings:[{offset:'0x10',text:'<script>not HTML</script>'}]},input:{mode:'pty',available:true,output:'hello\n'}};
ui.update(state,false,'stopped');assert.equal(commands.length,0,'Rendering cannot modify the target');
assert.equal(get('target-output').textContent,'hello\n');
assert.equal(get('binary-strings').children[0].children[1].textContent,'<script>not HTML</script>');
get('memory-write-address').value='0x1000';get('memory-write-hex').value='50 41 53 53';get('memory-write-form').onsubmit({preventDefault(){}});
assert.equal(commands.at(-1).action,'memory-write');assert.equal(commands.at(-1).hex,'50 41 53 53');
get('register-write-name').value='rax';get('register-write-value').value='0x2a';get('register-write-form').onsubmit({preventDefault(){}});
assert.equal(commands.at(-1).name,'rax');assert.equal(commands.at(-1).value,'0x2a');
get('target-input-mode').value='text';get('target-input-value').value='hello';get('target-input-newline').checked=true;
get('target-input-form').onsubmit({preventDefault(){}});assert.equal(commands.at(-1).value,'hello\n');
get('target-input-mode').value='hex';get('target-input-value').value='4100420a';get('target-input-form').onsubmit({preventDefault(){}});
assert.equal(commands.at(-1).value,'4100420a','HEX input never gets an implicit newline');
ui.update({...state,selected_frame:1},false,'stopped');assert.equal(get('register-write-form').button.disabled,true);
ui.update({...state,input:{mode:'console',available:false}},false,'running');
assert.equal(get('memory-write-form').button.disabled,true);assert.equal(get('target-input-form').button.disabled,true);
assert.ok(get('target-input-status').textContent.includes('Windows'));
console.log('CTF '+(en?'EN':'KO')+': explicit edits, input bytes, safe text rendering and state guards passed');
