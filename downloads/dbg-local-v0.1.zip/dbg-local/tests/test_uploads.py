import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote
from unittest.mock import patch

from debugger import Debugger
from server import MAX_BINARY_BYTES, MAX_SESSION_BYTES, make_server


class UploadTests(unittest.TestCase):
    def setUp(self):
        self.engine = Debugger()
        self.server = make_server(0, self.engine)
        self.directory = Path(self.server.uploads.name)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.assertFalse(self.directory.exists())

    def upload(self, name='hello.exe', body=b'MZ\x00\x01', token=True, headers=None):
        request_headers = {'Content-Type':'application/octet-stream', 'X-Filename':quote(name, safe='')}
        if token:
            request_headers['Authorization']='Bearer '+self.server.token
        request_headers.update(headers or {})
        request = urllib.request.Request(self.server.origin+'/api/files',data=body,headers=request_headers)
        return urllib.request.urlopen(request,timeout=3)

    def rejects(self, code, **kwargs):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.upload(**kwargs)
        self.assertEqual(error.exception.code,code)
        error.exception.close()
        self.assertEqual(self.server.upload_count,0)

    def test_bytes_unicode_name_and_same_name_isolation_without_execution(self):
        name='테스트 바이너리.exe'
        with self.upload(name=name) as response:
            first=json.load(response)['result']
        with self.upload(name=name,body=b'MZ\x10\x11') as response:
            second=json.load(response)['result']
        self.assertNotEqual(first['path'],second['path'])
        self.assertEqual(Path(first['path']).name,name)
        self.assertTrue(Path(first['path']).is_relative_to(self.directory))
        self.assertEqual(Path(first['path']).read_bytes(),b'MZ\x00\x01')
        self.assertEqual(Path(second['path']).read_bytes(),b'MZ\x10\x11')
        self.assertIsNone(self.engine.proc)
        self.assertEqual(self.engine.state,'disconnected')

    def test_authentication_required(self):
        self.rejects(401,token=False)

    def test_external_origin_rejected(self):
        self.rejects(403,headers={'Origin':'https://example.test'})

    def test_rebinding_host_rejected(self):
        self.rejects(403,headers={'Host':'example.test'})

    def test_empty_and_oversized_rejected_before_writing(self):
        self.rejects(413,body=b'')
        self.rejects(413,headers={'Content-Length':str(MAX_BINARY_BYTES+1)})
        self.assertEqual(list(self.directory.iterdir()),[])

    def test_path_traversal_and_windows_device_names_rejected(self):
        for name in ('../x.exe',r'..\x.exe','C:hello.exe','CON.exe','nul','LPT1.bin','x.exe.','x.exe ','.','..','x\n.exe'):
            self.rejects(400,name=name)

    def test_session_quota_checked_before_writing(self):
        self.server.upload_bytes=MAX_SESSION_BYTES
        self.rejects(413)
        self.assertEqual(list(self.directory.iterdir()),[])

    def test_saved_file_can_be_loaded_into_gdb_without_running_it(self):
        with self.upload() as response:
            path=json.load(response)['result']['path']
        self.engine.state='idle'
        with patch.object(self.engine,'command',return_value={}) as command:
            self.engine.action('load',{'path':path,'args':['a b']})
        self.assertEqual(self.engine.path,path)
        self.assertEqual(self.engine.state,'loaded')
        commands=[call.args[0] for call in command.call_args_list]
        self.assertTrue(any(c.startswith('-file-exec-and-symbols ') for c in commands))
        self.assertFalse(any(c.startswith('-exec-run') for c in commands))
        self.engine.state='idle'

    def test_loaded_target_can_be_replaced_and_invalid_args_do_not_change_target(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'hello.exe';path.write_bytes(b'MZ')
            self.engine.state='loaded'
            with patch.object(self.engine,'command',return_value={}) as command:
                with self.assertRaises(ValueError):
                    self.engine.action('load',{'path':str(path),'args':'bad'})
                command.assert_not_called()
                self.engine.action('load',{'path':str(path),'args':[]})
            self.assertEqual(self.engine.path,str(path))
            self.engine.state='idle'


if __name__=='__main__':
    unittest.main()
