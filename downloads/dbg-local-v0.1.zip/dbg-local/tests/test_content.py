import json
import shutil
import subprocess
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit
from xml.etree import ElementTree as ET

from scripts.build_content import build, PROJECT


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links=[]
        self.ids=[]
        self.text=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag=='a' and 'href' in attrs:
            self.links.append(attrs['href'])
    def handle_data(self,text):
        self.text.append(text)


class ContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory=tempfile.TemporaryDirectory()
        cls.root=Path(cls.directory.name)
        cls.summary=build(output_root=cls.root)
        cls.routes=json.loads((cls.root/'routes.json').read_text())

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def test_twenty_distinct_articles_with_1500_prose_characters(self):
        articles=[json.loads(p.read_text()) for p in (PROJECT/'content/articles').glob('*.json')]
        self.assertEqual(len(articles),20)
        self.assertEqual(len({a['slug'] for a in articles}),20)
        self.assertEqual(len({a['title'] for a in articles}),20)
        for article in articles:
            prose=''.join(t for s in article['sections'] for t in s['paragraphs'])
            self.assertGreaterEqual(len(prose),1500,article['slug'])
            path='/guides/'+article['slug']+'/'
            body=(self.root/self.routes[path][0]).read_text()
            parsed=Links();parsed.feed(body)
            self.assertIn(article['sections'][0]['paragraphs'][0], ''.join(parsed.text))
            self.assertEqual(body.count('<h1>'),1)
            self.assertEqual(len(parsed.ids),len(set(parsed.ids)))

    def test_internal_links_and_toc_targets_exist(self):
        valid=set(self.routes)|{'/'}
        for route,(filename,mime) in self.routes.items():
            if not mime.startswith('text/html'):
                continue
            parsed=Links();parsed.feed((self.root/filename).read_text())
            for href in parsed.links:
                if href.startswith('#'):
                    self.assertIn(href[1:],parsed.ids,route)
                elif href.startswith('/'):
                    self.assertIn(urlsplit(href).path,valid,(route,href))
        parsed=Links();parsed.feed((self.root/'index.html').read_text())
        for href in parsed.links:
            if href.startswith('/'):
                self.assertIn(urlsplit(href).path,valid)

    def test_local_preview_is_not_indexable(self):
        self.assertFalse(self.summary['public'])
        robots=(self.root/self.routes['/robots.txt'][0]).read_text()
        self.assertIn('Disallow: /\n',robots)
        for path,(filename,mime) in self.routes.items():
            if mime.startswith('text/html'):
                self.assertIn('noindex, nofollow',(self.root/filename).read_text())
        self.assertIn('noindex, nofollow',(self.root/'index.html').read_text())

    def test_sitemap_and_rss_are_complete_valid_xml(self):
        sitemap=ET.fromstring((self.root/self.routes['/sitemap.xml'][0]).read_text())
        locations=sitemap.findall('{*}url/{*}loc')
        self.assertEqual(len(locations),52)
        for node in locations:
            self.assertIn(urlsplit(node.text).path,set(self.routes)|{'/'})
        rss=ET.fromstring((self.root/self.routes['/rss.xml'][0]).read_text())
        self.assertEqual(len(rss.findall('channel/item')),20)

    def test_future_public_export_uses_configured_origin(self):
        with tempfile.TemporaryDirectory() as tmp:
            build(base_url='https://docs.example.test',output_root=tmp)
            routes=json.loads((Path(tmp)/'routes.json').read_text())
            html=(Path(tmp)/routes['/guides/'][0]).read_text()
            self.assertIn('rel="canonical" href="https://docs.example.test/guides/"',html)
            self.assertNotIn('noindex',html)
            self.assertNotIn('127.0.0.1',(Path(tmp)/routes['/sitemap.xml'][0]).read_text())
            root=(Path(tmp)/'index.html').read_text()
            self.assertIn('rel="canonical" href="https://docs.example.test/"',root)

    def test_both_languages_have_matching_articles_and_navigation(self):
        import re
        for path,(filename,mime) in self.routes.items():
            if not mime.startswith('text/html') or not path.startswith('/en/'):
                continue
            text=(self.root/filename).read_text()
            self.assertIn('<html lang="en">',text)
            self.assertIn('href="'+path+'" lang="en"',text)
            self.assertIn('href="'+path[3:]+'" lang="ko"',text)
            parser=Links();parser.feed(text)
            visible=''.join(parser.text).replace('한국어','')
            self.assertIsNone(re.search('[가-힣]',visible),path)
            self.assertIn('href="/en/guides/"',text)
            self.assertIn('href="/en/privacy/"',text)
        en_articles=list((PROJECT/'content/en/articles').glob('*.json'))
        self.assertEqual(len(en_articles),20)
        for original in (PROJECT/'content/articles').glob('*.json'):
            korean=json.loads(original.read_text())
            english=json.loads((PROJECT/'content/en/articles'/original.name).read_text())
            self.assertEqual(korean['slug'],english['slug'])
            self.assertEqual(len(korean['sections']),len(english['sections']))
            self.assertGreaterEqual(sum(len(t) for s in english['sections'] for t in s['paragraphs']),1500)
        root=(self.root/self.routes['/en/'][0]).read_text()
        self.assertIn('src="/en/ui.js"',root)
        self.assertEqual(root.count('class="language-switch"'),1)
        self.assertEqual((self.root/'index.html').read_text().count('class="language-switch"'),1)
        rss=ET.fromstring((self.root/self.routes['/en/rss.xml'][0]).read_text())
        self.assertEqual(rss.findtext('channel/language'),'en')
        self.assertEqual(len(rss.findall('channel/item')),20)
        self.assertTrue(all('/en/guides/' in node.text for node in rss.findall('channel/item/link')))

    def test_public_hreflang_matches_same_article(self):
        with tempfile.TemporaryDirectory() as tmp:
            build(base_url='https://docs.example.test',output_root=tmp)
            routes=json.loads((Path(tmp)/'routes.json').read_text())
            path='/en/guides/first-debug-session/'
            body=(Path(tmp)/routes[path][0]).read_text()
            self.assertIn('rel="canonical" href="https://docs.example.test'+path+'"',body)
            self.assertIn('hreflang="ko" href="https://docs.example.test'+path[3:]+'"',body)
            self.assertIn('hreflang="en" href="https://docs.example.test'+path+'"',body)

    def test_base_url_cannot_include_path_or_credentials(self):
        for value in ['http://example.test','https://user:pass@example.test','https://example.test/path','https://example.test?x=1']:
            with self.assertRaises(ValueError):
                build(base_url=value,output_root=self.root)

    def test_contact_uses_configured_email_without_server_send(self):
        body=(self.root/self.routes['/contact/'][0]).read_text()
        self.assertIn('mailto:psiwoo66@gmail.com',body)
        self.assertIn('data-email="psiwoo66@gmail.com"',body)
        self.assertIn('보내기 버튼은 메일 앱에서',body)
        script=(PROJECT/'web/contact.js').read_text()
        self.assertNotIn('fetch(',script)
        self.assertIn('encodeURIComponent',script)
        self.assertNotIn('Blob(',script)

    @unittest.skipUnless(shutil.which('node'), 'Node required for JavaScript check')
    def test_mailto_encodes_subject_and_body_without_extra_headers(self):
        script = """
const fs=require('fs'), vm=require('vm');
const context={};vm.createContext(context);
vm.runInContext(fs.readFileSync('web/contact.js','utf8'),context);
const result=context.composeMailto('psiwoo66@gmail.com','오류 제보','제목 & bcc=bad@example.test','첫 줄\\n다음 줄 ? & 한글');
process.stdout.write(result);
"""
        result=subprocess.run(['node','-e',script],cwd=PROJECT,check=True,capture_output=True,text=True).stdout
        from urllib.parse import parse_qs
        parsed=urlsplit(result)
        self.assertEqual(parsed.scheme,'mailto')
        self.assertEqual(parsed.path,'psiwoo66@gmail.com')
        query=parse_qs(parsed.query)
        self.assertEqual(set(query),{'subject','body'})
        self.assertIn('제목 & bcc=bad@example.test',query['subject'][0])
        self.assertEqual(query['body'][0],'첫 줄\n다음 줄 ? & 한글')


if __name__=='__main__':
    unittest.main()
