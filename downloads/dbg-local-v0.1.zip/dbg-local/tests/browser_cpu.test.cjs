'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const Unicorn=require('../web/vendor/unicorn.js'), Capstone=require('../web/vendor/capstone.js');
const {BrowserEngine,parseBinary}=require('../web/browser-engine.js');
function fixture(name){return fs.readFileSync('web/browser-examples/'+name);}
function elf64(code){const b=Buffer.from(fixture('sum64.elf'));b.fill(0,0x100);b.set(code,0x100);return b;}
(async()=>{
 const [u,c]=await Promise.all([Unicorn(),Capstone()]);
 for(const name of ['sum32.elf','sum64.elf','sum32.pe','sum64.pe']) {
  const e=new BrowserEngine(u,c),image=parseBinary(fixture(name));
  let s=e.load(fixture(name));assert.equal(s.assembly[0].mnemonic,'mov');assert.equal(s.instructions,0);
  s=e.run(1);assert.equal(s.registers[image.bits===32?'eip':'rip'],'0x'+(image.entry+5).toString(16));
  s=e.run(1);assert.equal(s.registers[image.bits===32?'ebx':'rbx'],'0x5');
  // Stop on the next loop entry, after one addition, rather than fabricate a trace.
  e.breakpoints.add(image.entry+10);s=e.run(1000);assert.equal(s.status,'paused');assert.equal(s.registers[image.bits===32?'eax':'rax'],'0x5');
  e.breakpoints.clear();s=e.run(1000);assert.equal(s.status,'halted');assert.equal(s.registers[image.bits===32?'eax':'rax'],'0xf');
  const data=image.format==='ELF'?0x100200:image.bits===32?0x401100:0x140001100;
  assert.deepEqual(e.read(data,4),[15,0,0,0]);
  e.memoryWrite(data,[0x37,0x13,0,0]);assert.deepEqual(e.read(data,4),[0x37,0x13,0,0]);
  e.setRegister(image.bits===32?'eax':'rax',42n);assert.equal(e.getRegister(image.bits===32?'eax':'rax'),42n);
  assert.throws(()=>e.setRegister(image.bits===32?'eax':'rax',-1n));
  assert.throws(()=>e.memoryWrite(1,[0]));assert.throws(()=>e.memoryWrite(data,new Array(257).fill(0)));
  e.close();
 }
 // Real x64 Linux syscalls: read four bytes, write them, exit with code zero.
 const ioCode=[0x31,0xc0,0x31,0xff,0x48,0xbe,0,2,0x10,0,0,0,0,0,0xba,4,0,0,0,0x0f,5,0xb8,1,0,0,0,0xbf,1,0,0,0,0x0f,5,0xb8,60,0,0,0,0x31,0xff,0x0f,5];
 const e=new BrowserEngine(u,c);e.load(elf64(ioCode));let s=e.run(1000);assert.equal(s.status,'waiting');
 const waitingPC=s.registers.rip;e.feed([0x41,0,0x42,0x0a]);s=e.run(1000);assert.equal(s.status,'exited');assert.equal(s.output,'A\0B\n');assert.notEqual(s.registers.rip,waitingPC);assert.equal(s.reason,'Exit code 0');
 assert.deepEqual(e.read(0x100200,4),[0x41,0,0x42,0x0a]);e.close();
 // Unsupported calls stop before an operation rather than pretending it succeeded.
 e.load(elf64([0xb8,0xff,0xff,0,0,0x0f,5]));s=e.run(100);assert.equal(s.status,'unsupported');assert.match(s.reason,/65535/);e.close();
 // An infinite loop yields after a bounded request and remains inspectable.
 e.load(elf64([0xeb,0xfe]));s=e.run(10);assert.equal(s.status,'ready');assert.equal(s.instructions,10);assert.match(s.reason,/budget/);e.close();
 const bad=Buffer.from(fixture('sum64.elf'));bad[18]=0xb7;assert.throws(()=>parseBinary(bad),/x86/);
 const truncated=Buffer.from(fixture('sum64.pe'));truncated.writeUInt32LE(0xffffff00,0x3c);assert.throws(()=>parseBinary(truncated));
 const huge=Buffer.from(fixture('sum64.elf'));huge.writeBigUInt64LE(0x5000000n,64+40);assert.throws(()=>parseBinary(huge),/memory|range/i);
 assert.throws(()=>parseBinary(new Uint8Array(32*1024*1024+1)));
 console.log('Actual browser WASM CPU: ELF/PE x86/x64, steps, breakpoints, edits, NUL I/O, exit and bounded failures passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
