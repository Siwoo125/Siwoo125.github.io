'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const Unicorn=require('../web/vendor/unicorn.js'), Capstone=require('../web/vendor/capstone.js');
const {BrowserEngine,parseBinary}=require('../web/browser-engine.js');
function fixture(name){return fs.readFileSync('web/browser-examples/'+name);}
function elf64(code){const b=Buffer.from(fixture('sum64.elf'));b.fill(0,0x100);b.set(code,0x100);return b;}
(async()=>{
 const [u,c]=await Promise.all([Unicorn(),Capstone()]);
 for(const name of ['sum32.elf','sum64.elf','sum32.pe','sum64.pe']) {
  const e=new BrowserEngine(u,c),image=parseBinary(fixture(name));
  let s=e.load(fixture(name));assert.equal(s.assembly[0].mnemonic,'mov');assert.equal(s.instructions,0);
  s=e.run(1);assert.equal(s.registers[image.bits===32?'eip':'rip'],'0x'+(image.entry+5).toString(16));
  s=e.run(1);assert.equal(s.registers[image.bits===32?'ebx':'rbx'],'0x5');
  // Stop on the next loop entry, after one addition, rather than fabricate a trace.
  e.breakpoints.add(image.entry+10);s=e.run(1000);assert.equal(s.status,'paused');assert.equal(s.registers[image.bits===32?'eax':'rax'],'0x5');
  e.breakpoints.clear();s=e.run(1000);assert.equal(s.status,'halted');assert.equal(s.registers[image.bits===32?'eax':'rax'],'0xf');
  const data=image.format==='ELF'?0x100200:image.bits===32?0x401100:0x140001100;
  assert.deepEqual(e.read(data,4),[15,0,0,0]);
  e.memoryWrite(data,[0x37,0x13,0,0]);assert.deepEqual(e.read(data,4),[0x37,0x13,0,0]);
  e.setRegister(image.bits===32?'eax':'rax',42n);assert.equal(e.getRegister(image.bits===32?'eax':'rax'),42n);
  assert.throws(()=>e.setRegister(image.bits===32?'eax':'rax',-1n));
  assert.throws(()=>e.memoryWrite(1,[0]));assert.throws(()=>e.memoryWrite(data,new Array(257).fill(0)));
  e.close();
 }
 // Editing already executed code must invalidate cached translations. The edit
 // also preserves neighbouring bytes and can cross a mapped page boundary.
 for(const name of ['sum32.elf','sum64.elf','sum32.pe','sum64.pe']) {
  const e=new BrowserEngine(u,c);e.load(fixture(name));e.run(1);
  const entry=e.image.entry, acc=e.image.bits===64?'rax':'eax';
  const next=e.read(entry+5,8), registers=e.snapshot().registers;
  e.memoryWrite(entry,[0xb8,42,0,0,0]);
  assert.deepEqual(e.snapshot().registers,registers);assert.deepEqual(e.read(entry+5,8),next);
  e.setRegister(e.pcName,BigInt(entry));assert.equal(e.run(1).registers[acc],'0x2a');
  e.memoryWrite(entry,[0xb8,7,0,0,0]);e.setRegister(e.pcName,BigInt(entry));
  assert.equal(e.run(1).registers[acc],'0x7');
  e.memoryWrite(0x7fc00ffe,[1,2,3,4]);assert.deepEqual(e.read(0x7fc00ffe,4),[1,2,3,4]);
  e.breakpoints.add(entry+5);e.breakpoints.delete(entry+5);assert.equal(e.breakpoints.size,0);
  e.close();
 }
 // Save actual CPU/RAM state, close it, then restore in a fresh WASM instance.
 const [u2,c2]=await Promise.all([Unicorn(),Capstone()]);
 for(const name of ['sum32.elf','sum64.elf','sum32.pe','sum64.pe']) {
  const e=new BrowserEngine(u,c),bytes=fixture(name);e.load(bytes);const entry=e.image.entry;
  // call sub; mov eax,7; hlt; sub: mov eax,42; ret
  const code=[0xe8,6,0,0,0,0xb8,7,0,0,0,0xf4,0xb8,42,0,0,0,0xc3];
  e.memoryWrite(entry,code);let s=e.runTo(entry+11);
  assert.equal(s.instructions,1);assert.equal(s.stack[0].value,'0x'+(entry+5).toString(16));
  const pc=e.pcName,acc=e.image.bits===64?'rax':'eax';
  e.breakpoints.add(entry+16);s=e.runTo(entry+5);
  assert.equal(s.registers[pc],'0x'+(entry+16).toString(16));assert.equal(e.runTarget,entry+5);
  const resumed=new BrowserEngine(u2,c2);resumed.restore(bytes,structuredClone(e.checkpoint()));
  s=resumed.run(100);assert.equal(s.registers[pc],'0x'+(entry+5).toString(16));assert.equal(s.runTarget,null);assert.equal(s.registers[acc],'0x2a');
  resumed.close();e.close();e.load(bytes);e.memoryWrite(entry,code);
  e.breakpoints.add(entry+16);e.disabledBreakpoints.add(entry+16);s=e.stepOver();
  assert.equal(s.instructions,3);assert.equal(s.registers[pc],'0x'+(entry+5).toString(16));assert.equal(s.registers[acc],'0x2a');
  const saved=e.checkpoint();e.restore(bytes,structuredClone(saved));assert(e.disabledBreakpoints.has(entry+16));
  e.nop(entry+5);assert.deepEqual(e.read(entry+5,5),new Array(5).fill(0x90));
  s=e.run(5);assert.equal(s.registers[acc],'0x2a');assert.equal(s.registers[pc],'0x'+(entry+10).toString(16));
  const before=e.snapshot();assert.throws(()=>e.runTo(1),/mapped/);assert.deepEqual(e.snapshot(),before);
  assert.throws(()=>e.nop(1),/mapped/);
  delete saved.disabledBreakpoints;delete saved.runTarget;e.restore(bytes,saved);assert.equal(e.disabledBreakpoints.size,0);
  e.close();
 }
 for(const name of ['sum32.elf','sum64.elf','sum32.pe','sum64.pe']) {
  const source=new BrowserEngine(u,c),target=new BrowserEngine(u2,c2),bytes=fixture(name);
  source.load(bytes);source.run(4);source.feed([65,0,66]);source.output='before\0after';
  source.breakpoints.add(source.image.entry+10);
  // Preserve a page deliberately zeroed, rather than reintroducing original code.
  source.cpu.mem_write(source.image.entry-(source.image.entry%4096),new Uint8Array(4096));
  source.memoryWrite(source.image.entry,[0xf4]);source.memoryWrite(0x7fc00080,[11,22,33]);
  source.setRegister(source.pcName,BigInt(source.image.entry));
  const wide=Uint8Array.from({length:64},(_,i)=>i+1);
  source.rawRegister('XMM0',wide);
  const before=source.snapshot(),saved=structuredClone(source.checkpoint());source.close();
  const restored=target.restore(bytes,saved);
  assert.deepEqual(restored,before);assert.deepEqual(target.read(0x7fc00080,3),[11,22,33]);
  assert.deepEqual(target.read(target.image.entry+1,8),new Array(8).fill(0));
  assert.deepEqual(target.rawRegister('XMM0').slice(0,16),wide.slice(0,16));
  assert.deepEqual(target.input,[65,0,66]);assert.equal(target.instructions,4);
  const badSave=structuredClone(saved);badSave.pages[0].start=1;
  assert.throws(()=>target.restore(bytes,badSave),/page/);assert.deepEqual(target.snapshot(),before);
  assert.equal(target.run(1).instructions,5);target.close();
 }
 // Flags and x87 stack must survive reload before a conditional branch / FPU operation.
 for(const code of [[0x31,0xc0,0x74,0x05,0xb8,99,0,0,0,0xf4],[0xd9,0xe8,0xd9,0xe8,0xde,0xc1,0xf4]]) {
  const bytes=elf64(code),source=new BrowserEngine(u,c),target=new BrowserEngine(u2,c2);
  source.load(bytes);source.run(code[0]===0x31?1:2);const saved=source.checkpoint();
  target.restore(bytes,structuredClone(saved));
  for(const name of ['FP0','FP7','FPSW','FPTAG'])assert.deepEqual(target.rawRegister(name),source.rawRegister(name));
  const expected=source.run(100),actual=target.run(100);assert.deepEqual(actual,expected);
  assert.deepEqual(target.rawRegister('FP7'),source.rawRegister('FP7'));source.close();target.close();
 }
 // Real x64 Linux syscalls: read four bytes, write them, exit with code zero.
 const ioCode=[0x31,0xc0,0x31,0xff,0x48,0xbe,0,2,0x10,0,0,0,0,0,0xba,4,0,0,0,0x0f,5,0xb8,1,0,0,0,0xbf,1,0,0,0,0x0f,5,0xb8,60,0,0,0,0x31,0xff,0x0f,5];
 const e=new BrowserEngine(u,c);e.load(elf64(ioCode));let s=e.run(1000);assert.equal(s.status,'waiting');
 const waitingPC=s.registers.rip;const waitingSave=e.checkpoint();e.restore(elf64(ioCode),waitingSave);assert.equal(e.status,'waiting');e.feed([0x41,0,0x42,0x0a]);s=e.run(1000);assert.equal(s.status,'exited');assert.equal(s.output,'A\0B\n');assert.notEqual(s.registers.rip,waitingPC);assert.equal(s.reason,'Exit code 0');
 assert.deepEqual(e.read(0x100200,4),[0x41,0,0x42,0x0a]);e.close();
 // Unsupported calls stop before an operation rather than pretending it succeeded.
 e.load(elf64([0xb8,0xff,0xff,0,0,0x0f,5]));s=e.run(100);assert.equal(s.status,'unsupported');assert.match(s.reason,/65535/);e.close();
 // An infinite loop yields after a bounded request and remains inspectable.
 e.load(elf64([0xeb,0xfe]));s=e.run(10);assert.equal(s.status,'ready');assert.equal(s.instructions,10);assert.match(s.reason,/budget/);e.close();
 const bad=Buffer.from(fixture('sum64.elf'));bad[18]=0xb7;assert.throws(()=>parseBinary(bad),/x86/);
 const truncated=Buffer.from(fixture('sum64.pe'));truncated.writeUInt32LE(0xffffff00,0x3c);assert.throws(()=>parseBinary(truncated));
 const huge=Buffer.from(fixture('sum64.elf'));huge.writeBigUInt64LE(0x5000000n,64+40);assert.throws(()=>parseBinary(huge),/memory|range/i);
 assert.throws(()=>parseBinary(new Uint8Array(32*1024*1024+1)));
 console.log('Actual browser WASM CPU: ELF/PE x86/x64, checkpoint restore across WASM instances, RAM, flags, SIMD/x87, I/O and bounded execution passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
