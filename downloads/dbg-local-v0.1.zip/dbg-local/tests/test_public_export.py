import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from urllib.parse import urlsplit
from html.parser import HTMLParser
from scripts.export_public import export, ROOT

class Links(HTMLParser):
    def __init__(self):
        super().__init__(); self.links = []
    def handle_starttag(self, tag, attrs):
        for name, value in attrs:
            if name in ('href', 'src') and value and value.startswith('/'):
                self.links.append(value)

class PublicExportTests(unittest.TestCase):
    def test_public_export_is_static_and_download_matches(self):
        with tempfile.TemporaryDirectory() as folder:
            dest = Path(folder)
            result = export('https://example.com', dest)
            pages = list(dest.rglob('*.html'))
            self.assertEqual(result['pages'], 56)
            for page in pages:
                text = page.read_text()
                self.assertNotIn('noindex', text)
                if page.parent.name == 'debugger':
                    self.assertIn('data-hosting="public"', text)
                    self.assertIn('id="workspace"', text)
                    self.assertIn('id="assembly"', text)
                    self.assertIn('src="/app.js"', text)
                else:
                    self.assertNotIn('/app.js', text)
                self.assertNotIn('/api/action', text)
                parser = Links(); parser.feed(text)
                for link in parser.links:
                    path = urlsplit(link).path
                    target = dest/path.lstrip('/')
                    if path.endswith('/'): target /= 'index.html'
                    self.assertTrue(target.is_file(), (page, link))
            self.assertNotIn('Disallow: /\n', (dest/'robots.txt').read_text())
            self.assertFalse((dest/'server.py').exists())
            zip_path = dest/'downloads/dbg-local-v0.1.zip'
            self.assertEqual(zip_path.read_bytes(), (ROOT/'dbg-local-v0.1.zip').read_bytes())
            self.assertEqual(hashlib.sha256(zip_path.read_bytes()).hexdigest(), result['sha256'])
            self.assertIn('https://example.com/en/', (dest/'index.html').read_text())
            self.assertNotIn('id="launch-debugger"', (dest/'index.html').read_text())
            self.assertIn('href="/debugger/"', (dest/'index.html').read_text())
            self.assertIn('href="/en/debugger/"', (dest/'en/guides/index.html').read_text())
            self.assertIn('https://example.com/en/debugger/', (dest/'en/debugger/index.html').read_text())
            self.assertIn('https://example.com/debugger/', (dest/'sitemap.xml').read_text())
