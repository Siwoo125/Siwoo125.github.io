const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const english = process.argv.includes('--en');

class Element {
  constructor() {
    this.value = ''; this.textContent = ''; this.disabled = false; this.handlers = {};
    this.classList = { toggle() {}, add() {}, remove() {} };
  }
  addEventListener(name, handler) { this.handlers[name] = handler; }
  replaceChildren() {} append() {} setAttribute() {}
  click() { this.clicked = true; }
}
const elements = new Map();
const get = id => { if (!elements.has(id)) elements.set(id, new Element()); return elements.get(id); };
get('args').value = '[]';
const requests = [];
let engineState = 'disconnected', failConnect = false;
const snapshot = () => ({state:engineState,engine:'gdb',stop:{},assembly:[],registers:[],stack:[],memory:[],breakpoints:[],events:[],errors:{}});
const context = {
  document:{documentElement:{lang:english?'en':'ko'},getElementById:get,querySelectorAll:()=>[],createElement:()=>new Element(),addEventListener(){},hidden:false},
  window:{DBG_I18N:english?JSON.parse(fs.readFileSync('content/en/ui.json','utf8')):{},addEventListener(){}}, location:{hash:'',pathname:'/'}, history:{replaceState(){}},
  sessionStorage:{getItem:()=> 'test-token',setItem(){}}, URLSearchParams,
  setInterval(){},
  async fetch(url, options) {
    requests.push({url,...options});
    if (url === '/api/state') return {ok:true,json:async()=>({result:snapshot()})};
    if (url === '/api/files') return {ok:true,json:async()=>({result:{name:options.body.name,path:'/tmp/staged/'+options.body.name,size:options.body.size}})};
    const data = JSON.parse(options.body);
    if (data.action === 'connect') {
      if (failConnect) return {ok:false,json:async()=>({error:english?'GDB was not found.':'GDB 없음'})};
      engineState = 'idle';
    }
    if (data.action === 'load') engineState = 'loaded';
    return {ok:true,json:async()=>({result:{}})};
  },
};
vm.createContext(context);
vm.runInContext(fs.readFileSync('web/app.js','utf8'),context);
const settle = () => new Promise(resolve => setImmediate(resolve));
const nonStateRequests = () => requests.filter(r=>r.url!=='/api/state');
const file = {name:'테스트.exe',size:4,bytes:Buffer.from([77,90,0,1])};

(async () => {
  await settle();
  assert.equal(get('status').textContent,english?'Disconnected':'연결 안 됨');
  get('choose-file').onclick();
  assert.equal(get('binary-file').clicked,true,'button opens browser file input');
  await get('binary-file').handlers.change({target:{files:[file]}});
  let calls=nonStateRequests();
  assert.equal(calls[0].url,'/api/files');
  assert.equal(calls[0].body,file,'binary object is sent directly, not a fake path');
  assert.equal(calls[0].headers.Authorization,'Bearer test-token');
  assert.equal(calls[0].headers['X-UI-Language'],english?'en':'ko');
  assert.equal(decodeURIComponent(calls[0].headers['X-Filename']),file.name);
  assert.deepEqual(calls.slice(1).map(r=>JSON.parse(r.body).action),['connect','load']);
  assert.equal(get('selected-file').textContent,'테스트.exe · 4 B');
  assert.equal(get('path').value,'/tmp/staged/테스트.exe');
  assert.equal(get('choose-file').disabled,false,'loaded target can be replaced');
  assert.equal(get('binary-file').value,'','same file may be selected again');

  requests.length=0;
  const dropped={name:'second.bin',size:3};
  let prevented=false;
  get('file-drop').handlers.drop({preventDefault(){prevented=true;},dataTransfer:{files:[dropped]}});
  await settle();
  assert.equal(prevented,true);
  calls=nonStateRequests();
  assert.equal(calls[0].body,dropped,'drop uses the same file-opening flow');
  assert.deepEqual(calls.slice(1).map(r=>JSON.parse(r.body).action),['load']);
  assert.equal(get('selected-file').textContent,'second.bin · 3 B');

  requests.length=0;
  get('file-drop').handlers.drop({preventDefault(){},dataTransfer:{files:[file,dropped]}});
  assert.equal(nonStateRequests().length,0);
  assert.match(get('notice').textContent,english?/one binary/:/하나만/);
  await get('binary-file').handlers.change({target:{files:[{name:'empty.bin',size:0}]}});
  assert.equal(nonStateRequests().length,0);
  await get('binary-file').handlers.change({target:{files:[{name:'large.bin',size:128*1024*1024+1}]}});
  assert.equal(nonStateRequests().length,0);

  engineState='disconnected'; failConnect=true;
  await vm.runInContext('refresh()',context);
  await get('binary-file').handlers.change({target:{files:[file]}});
  assert.match(get('notice').textContent,english?/GDB was not found/:/GDB 없음/);
  assert.equal(get('selected-file').textContent,'테스트.exe · 4 B','selected file is retained when engine is missing');
  assert.equal(get('choose-file').disabled,false);
  assert(!nonStateRequests().some(r=>r.url==='/api/action'&&JSON.parse(r.body).action==='run'),'opening never runs the binary');
  console.log('File picker, drop, auto-connect/load, validation and missing-engine behavior passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
