const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const english=process.argv.includes('--en');
class Node {
  constructor(){this.children=[];this.value='';this.checked=false;this.dataset={};this.attrs={};this.disabled=false;}
  append(...items){this.children.push(...items);}
  replaceChildren(){this.children=[];}
  setAttribute(k,v){this.attrs[k]=v;}
  querySelector(){return this.button;}
}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,new Node());return nodes.get(id);};
get('watch-form').button=new Node();
const document={documentElement:{lang:english?'en':'ko'},getElementById:get,createElement:()=>new Node(),querySelectorAll:()=>[]};
const context={window:{},document};vm.createContext(context);vm.runInContext(fs.readFileSync('web/advanced.js','utf8'),context);
const commands=[],ui=new context.window.DBGAdvanced({action:(action,data)=>commands.push({action,...data})});
const snapshot={state:'stopped',current_thread:'2',selected_frame:1,threads:[{id:'2',name:'worker',frame:{func:'main'}}],locals:[{name:'counter',type:'int',value:'5'}],stack:[{frame:{level:'1',func:'main',addr:'0x100'}}],breakpoints:[{bkpt:{number:'3',enabled:'y',type:'breakpoint',cond:'counter == 5',times:'8',ignore:'2','original-location':'main'}}]};
ui.update(snapshot,false,'stopped');
assert.equal(commands.length,0,'rendering never executes a command');
assert.equal(get('context-label').textContent,'T2 / #1');
assert.equal(get('thread-select').value,'2');
get('thread-select').value='4';get('thread-select').onchange();assert.equal(commands.at(-1).action,'thread-select');assert.equal(commands.at(-1).thread,'4');
get('stack').children[0].onclick();assert.equal(commands.at(-1).action,'frame-select');assert.equal(commands.at(-1).frame,'1');
assert.equal(get('stack').children[0].attrs['aria-pressed'],'true');
get('breakpoints').children[0].children[0].onclick();assert.equal(commands.at(-1).action,'break-disable');
assert.equal(get('local-variables').children[0].children[2].textContent,'5');
get('watch-address').value=' 0x1234 ';get('watch-size').value='4';get('watch-mode').value='write';
get('watch-form').onsubmit({preventDefault(){}});assert.equal(commands.at(-1).action,'watch-add');assert.equal(commands.at(-1).address,'0x1234');
get('break-condition').value='counter == 5';get('break-ignore').value='3';get('break-temporary').checked=true;
assert.equal(ui.breakOptions().temporary,true);assert.equal(ui.breakOptions().ignore,'3');
ui.update(null,true,'stopped');assert.equal(get('thread-select').disabled,true);assert.equal(get('watch-form').button.disabled,true);
ui.update({...snapshot,threads:[],stack:[],locals:[],breakpoints:[]},false,'running');
assert.equal(get('thread-select').disabled,true);assert.equal(get('context-label').textContent,'—');
console.log('Advanced '+(english?'EN':'KO')+': context selection, breakpoint toggles, watchpoint submission and busy controls passed.');
