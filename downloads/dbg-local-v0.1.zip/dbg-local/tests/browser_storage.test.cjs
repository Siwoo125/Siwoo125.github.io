'use strict';
const assert=require('node:assert/strict');
const SessionStore=require('../web/browser-storage.js');
(async()=>{
 const data=new Map(),transactions=[];let fail=false;
 const store=new SessionStore(null);
 store.database=Promise.resolve({transaction(){
  const writes=[],tx={objectStore:()=>({
   put(value,key){writes.push(()=>data.set(key,structuredClone(value)));},
   delete(key){writes.push(()=>data.delete(key));},
   get(key){const r={};setImmediate(()=>{r.result=structuredClone(data.get(key));r.onsuccess();});return r;}
  })};
  transactions.push(()=>{if(fail){fail=false;tx.error=Error('QuotaExceededError');tx.onabort();}else{writes.forEach(fn=>fn());tx.oncomplete();}});
  return tx;
 }});
 const tick=()=>new Promise(resolve=>setImmediate(resolve));
 let resolved=false;
 const first=store.save({bytes:new Uint8Array([65,0,66]),id:1}).then(()=>{resolved=true;});
 const second=store.save({id:2});await tick();assert.equal(resolved,false);assert.equal(transactions.length,1);
 transactions.shift()();await first;await tick();assert.equal(transactions.length,1);
 transactions.shift()();await second;assert.equal(data.get('session').id,2);
 const rejected=store.save({id:3});await tick();fail=true;transactions.shift()();await assert.rejects(rejected,/Quota/);assert.equal(data.get('session').id,2);
 const clear=store.clear(),later=store.preference(true);await tick();transactions.shift()();await clear;
 assert.equal(data.has('session'),false);assert.equal(data.get('autoSave'),false);
 await tick();transactions.shift()();await later;assert.equal(data.get('autoSave'),true);
 await assert.rejects(new SessionStore(null).read(),/unavailable/);
 console.log('Session storage: commit acknowledgement, FIFO writes, quota abort recovery and ordered deletion passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
