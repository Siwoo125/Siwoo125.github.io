import json
import io
import os
import shutil
import subprocess
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from debugger import Debugger, MIParser, quote, record
from server import make_server


class ParserTests(unittest.TestCase):
    def test_nested_stop_and_escaped_path(self):
        row = record(r'12^done,stack=[frame={level="0",addr="0x1000",func="main",fullname="C:\\hello\\main.c",args=[{name="argc",value="1"}]}]')
        self.assertEqual(row['token'], '12')
        frame = row['data']['stack'][0]['frame']
        self.assertEqual(frame['fullname'], r'C:\hello\main.c')
        self.assertEqual(frame['args'], [{'name':'argc','value':'1'}])

    def test_stream_and_octal(self):
        self.assertEqual(record(r'~"hello\n\042world\042"')['text'], 'hello\n"world"')
        self.assertIsNone(record('(gdb)'))

    def test_values_and_repeated_result_list(self):
        row = record('^done,register-names=["rax","","rip"],stack=[frame={level="0"},frame={level="1"}]')
        self.assertEqual(row['data']['register-names'], ['rax','','rip'])
        self.assertEqual(len(row['data']['stack']), 2)

    def test_quote_prevents_command_line_injection(self):
        encoded = quote('"\n-exec-run\n')
        self.assertNotIn('\n', encoded)
        self.assertEqual(MIParser(encoded).value(), '"\n-exec-run\n')

    def test_utf8_korean_paths(self):
        path = 'C:\\사용자\\온라인DBG\\hello.exe'
        self.assertEqual(MIParser(quote(path)).value(), path)
        self.assertEqual(MIParser(r'"\355\225\234\352\270\200"').value(), '한글')

    def test_truncated_input(self):
        for value in ('"broken', '["x"', '{name="x"'):
            with self.assertRaises(ValueError):
                MIParser(value).value()


class GuardTests(unittest.TestCase):
    def test_stop_sequence_distinguishes_same_address_stops(self):
        debugger=Debugger()
        class Process:
            stdout=io.StringIO('*stopped,reason="end-stepping-range",frame={addr="0x100"}\n*running,thread-id="all"\n*stopped,reason="end-stepping-range",frame={addr="0x100"}\n')
        debugger._read(Process())
        self.assertEqual(debugger.stop_sequence,2)
        snapshot=debugger.snapshot()
        self.assertEqual(snapshot['stop_sequence'],2)
        self.assertEqual(snapshot['target_id'],0)

    def test_execution_requires_state(self):
        debugger = Debugger()
        for action in ('run','continue','pause','step','next','finish'):
            with self.assertRaises(ValueError):
                debugger.action(action,{})

    def test_memory_rejects_expression_execution(self):
        debugger = Debugger()
        debugger.state = 'stopped'
        debugger.command = lambda *a, **k: {}
        with self.assertRaises(ValueError):
            debugger.snapshot('system("calc")')


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = make_server(0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def request(self, path='/api/state', token=True, headers=None, data=None):
        h={'Content-Type':'application/json'}
        if token:
            h['Authorization']='Bearer '+self.server.token
        h.update(headers or {})
        req=urllib.request.Request(self.server.origin+path, data=json.dumps(data or {}).encode(),headers=h)
        return urllib.request.urlopen(req,timeout=3)

    def test_authenticated_local_state(self):
        with self.request() as response:
            self.assertEqual(json.load(response)['result']['state'],'disconnected')
            self.assertNotIn('Access-Control-Allow-Origin',response.headers)

    def test_no_auth_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request(token=False)
        self.assertEqual(error.exception.code,401)

    def test_foreign_origin_rejected_even_with_token(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request(headers={'Origin':'https://evil.example'})
        self.assertEqual(error.exception.code,403)

    def test_dns_rebinding_host_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request(headers={'Host':'evil.example'})
        self.assertEqual(error.exception.code,403)

    def test_english_error_response(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request(path='/api/action',headers={'X-UI-Language':'en'},data={'action':'unknown'})
        self.assertEqual(error.exception.code,400)
        self.assertEqual(json.load(error.exception)['error'],'Unsupported command')
        error.exception.close()

    def test_asset_headers_and_allowlist(self):
        with urllib.request.urlopen(self.server.origin+'/') as response:
            self.assertIn("frame-ancestors 'none'",response.headers['Content-Security-Policy'])
            self.assertIn('DBG Desk',response.read().decode())
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(self.server.origin+'/debugger.py')
        self.assertEqual(error.exception.code,404)


@unittest.skipUnless(shutil.which('gdb') and shutil.which('gcc'), 'native GDB and GCC required')
class NativeTests(unittest.TestCase):
    def test_actual_process_break_step_memory_detach(self):
        with tempfile.TemporaryDirectory() as directory:
            binary=str(Path(directory)/('counter.exe' if os.name=='nt' else 'counter'))
            subprocess.run(['gcc','-g','-O0','examples/counter.c','-o',binary],check=True)
            debugger=Debugger()
            def wait_stop():
                deadline=time.monotonic()+10
                while debugger.state!='stopped' and time.monotonic()<deadline:
                    time.sleep(.05)
                self.assertEqual(debugger.state,'stopped')
            try:
                debugger.start()
                debugger.action('load',{'path':binary,'args':[]})
                debugger.action('break-add',{'location':'accumulate'})
                debugger.action('run',{})
                wait_stop()
                state=debugger.snapshot()
                self.assertTrue(state['assembly'])
                self.assertTrue(state['registers'])
                self.assertTrue(state['memory'])
                self.assertTrue(state['stack'])
                debugger.action('continue',{})
                wait_stop()
                self.assertEqual(debugger.stop['frame']['func'],'accumulate')
                previous=debugger.stop['frame']['addr']
                debugger.action('step',{})
                wait_stop()
                self.assertNotEqual(debugger.stop['frame']['addr'],previous)
                debugger.action('detach',{})
                self.assertEqual(debugger.state,'idle')
            finally:
                debugger.close()


if __name__=='__main__':
    unittest.main()
