#include <stdio.h>
#include <string.h>

volatile unsigned int gate = 0;
volatile unsigned char tag[4] = {'N', 'O', 'P', 'E'};

__attribute__((noinline)) int checkpoint(void) {
    return gate == 0x1337 && memcmp((const void *)tag, "PASS", 4) == 0;
}

int main(void) {
    int solved = checkpoint();
    puts(solved ? "CTF demo solved" : "CTF demo locked");
    return solved ? 0 : 1;
}
