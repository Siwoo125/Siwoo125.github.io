# CTF 시작하기

공개 사이트는 화면과 다운로드를 제공합니다. 실제 디버깅은 내려받은 로컬 서버에서 합니다. Windows EXE는 Windows GDB로, Linux ELF는 Linux/WSL의 GDB로 여세요. macOS에서 x86 ELF나 PE를 바로 실행하는 백엔드는 포함하지 않습니다.

## 설치와 실행

Windows: Python 3.10 이상과 MSYS2 UCRT64의 GDB·GCC가 필요합니다. `start-windows.bat`를 실행하면 브라우저가 열립니다. 기본 `C:\msys64\ucrt64\bin\gdb.exe`는 자동으로 찾습니다. 다른 위치는 `--gdb` 또는 `GDB_PATH`로 지정합니다.

Linux/WSL: Python 3.10 이상, `gdb`, `gcc`를 설치하고 `sh start-linux.sh`로 실행합니다. 브라우저가 열리지 않으면 터미널에 나온 인증 URL 전체를 엽니다. WSL에서는 서버를 WSL 안에서 실행하고 Windows 브라우저로 해당 로컬 주소를 열 수 있습니다. 네트워크 설정에 따라 localhost 전달 설정이 필요할 수 있습니다.

## 메모리를 바꿔 잠금 통과하기

컴파일:

```sh
gcc -g -O0 examples/ctf_gate.c -o examples/ctf_gate
```

Windows에서는 출력 이름에 `.exe`를 붙입니다. 생성한 실행 파일을 디버거의 **파일 열기**로 열거나 드롭합니다.

1. 중단점에 `checkpoint`를 추가하고 **실행**합니다.
2. **CTF 도구 → 심볼 주소 조회**에 `gate`를 넣습니다. 조회한 실제 주소가 메모리 쓰기 입력란에 들어갑니다.
3. HEX에 `37 13 00 00`을 넣고 **메모리 쓰기**를 누릅니다. x86/x86-64의 little endian 정수 `0x1337`입니다.
4. `tag`의 주소를 조회하고 `50 41 53 53`을 씁니다. ASCII `PASS`입니다.
5. **Step out**하면 `checkpoint`의 반환값이 1이 됩니다. **계속** 실행하면 `CTF demo solved`를 출력하고 종료합니다.

레지스터는 정지 상태·호출 프레임 0에서 수정합니다. 예를 들어 `rax`를 `0x2a`로 바꾼 뒤 레지스터 패널에서 확인할 수 있습니다. 임의로 PC/SP를 바꾸면 실행 흐름이나 스택도 바뀝니다. 메모리 쓰기는 최대 256바이트이며 쓰기 후 다시 읽어 검증합니다. 실행 파일 자체를 수정하지 않습니다.

## 입력을 받는 문제

```sh
gcc -g -O0 examples/ctf_input.c -o examples/ctf_input
```

`input_done`에 중단점을 추가하고 실행합니다. Linux에서는 **프로그램 입력·출력**에 `payload>`가 표시됩니다. HEX 모드로 `41 00 42 0a`를 전송하면 NUL을 포함한 네 바이트가 대상에 전달됩니다. 멈춘 뒤 계속 실행하면 `bytes=4100420a`가 출력됩니다. UTF-8 모드에서는 줄바꿈 추가 여부를 선택할 수 있습니다.

Windows에서는 실행 시 열리는 별도 대상 콘솔에 입력합니다. 웹 입력은 POSIX PTY 대상만 지원하며, 다른 프로세스에 Attach한 경우 입력을 가로채지 않습니다. PTY 패널은 전체 터미널 에뮬레이터가 아니며 한 번에 최대 4096바이트를 보냅니다.

## 심볼 없는 파일과 PIE

**첫 명령어에서 시작**은 GDB `starti`로 실행합니다. `main` 심볼 없이 정지하며 동적 실행 파일은 로더에서 먼저 멈출 수 있습니다. 이후 F7/F8, 실제 주소 중단점, 선택 주소까지 실행을 사용합니다. 디스어셈블리 주소 입력란에서는 `0x주소`, `$pc`, `$rdi+0x10`과 같은 제한된 주소식을 사용할 수 있습니다.

파일 정보의 진입점은 파일 헤더의 값입니다. PIE/ASLR 적용 후 주소와 같다고 가정하지 마세요. 문자열의 주소는 파일 오프셋이며 실행 중 가상 주소가 아닙니다. 문자열은 앞 16 MiB, 최대 200개, 각 256자로 제한합니다. NX/ASLR 표시는 헤더 플래그이며 전체 checksec 검사 결과가 아닙니다.

역실행, 디스크 파일 패치, Python/JavaScript 언어 디버깅, 모든 아키텍처의 호환성은 제공하지 않습니다. 이 예제는 사용법 검증용이며 실제 대회 문제의 풀이를 보장하지 않습니다.

## 구현에 사용한 문서

- [GDB/MI 데이터 명령](https://sourceware.org/gdb/current/onlinedocs/gdb.html/GDB_002fMI-Data-Manipulation.html)
- [GDB 시작·starti](https://sourceware.org/gdb/current/onlinedocs/gdb.html/Starting.html)
- [GDB 대상 입출력](https://sourceware.org/gdb/current/onlinedocs/gdb.html/Input_002fOutput.html)
- [Microsoft PE 형식](https://learn.microsoft.com/en-us/windows/win32/debug/pe-format)
