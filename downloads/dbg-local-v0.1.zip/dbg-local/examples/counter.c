#include <stdio.h>

static int accumulate(int value) {
    int result = value * 3;
    return result + 1;
}

int main(void) {
    volatile int total = 0;
    for (int i = 0; i < 5; ++i) {
        total += accumulate(i);
    }
    printf("total = %d\n", total);
    return total == 35 ? 0 : 1;
}
