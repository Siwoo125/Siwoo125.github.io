#include <stdio.h>

__attribute__((noinline)) void input_done(void) { puts("input received"); }

int main(void) {
    unsigned char bytes[4];
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("payload> ");
    if (fread(bytes, 1, 4, stdin) != 4) return 2;
    input_done();
    printf("bytes=%02x%02x%02x%02x\n", bytes[0], bytes[1], bytes[2], bytes[3]);
    return 0;
}
