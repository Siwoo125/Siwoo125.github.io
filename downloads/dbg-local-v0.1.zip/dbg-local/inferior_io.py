"""A separate POSIX PTY for target bytes, never for GDB commands."""
import codecs
import os
import select
import threading
from collections import deque


class TargetIO:
    def __init__(self):
        self.master = self.slave = None
        self.path = ''
        self.thread = None
        self.stop = threading.Event()
        self.output = deque(maxlen=128)
        self.lock = threading.Lock()

    def open(self):
        self.close()
        if os.name != 'posix':
            raise OSError('POSIX PTY required')
        import pty
        import tty
        self.master, self.slave = pty.openpty()
        tty.setraw(self.slave)
        self.path = os.ttyname(self.slave)
        os.set_blocking(self.master, False)
        self.stop.clear()
        self.clear()
        self.thread = threading.Thread(target=self._read, daemon=True)
        self.thread.start()
        return self.path

    def _read(self):
        decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
        while not self.stop.is_set():
            try:
                ready, _, _ = select.select([self.master], [], [], .2)
                if not ready:
                    continue
                data = os.read(self.master, 1024)
                if not data:
                    return
                with self.lock:
                    self.output.append(decoder.decode(data))
            except (OSError, ValueError, TypeError):
                return

    def send(self, payload):
        if self.master is None:
            raise ValueError('Target input is unavailable')
        if not 0 < len(payload) <= 4096:
            raise ValueError('Send 1–4096 bytes at a time')
        try:
            return os.write(self.master, payload)
        except BlockingIOError:
            raise ValueError('Target input buffer is full; continue the target and retry') from None

    def text(self):
        with self.lock:
            return ''.join(self.output)

    def clear(self):
        with self.lock:
            self.output.clear()

    def close(self):
        self.stop.set()
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)
        for name in ('master', 'slave'):
            descriptor = getattr(self, name)
            if descriptor is not None:
                os.close(descriptor)
                setattr(self, name, None)
        self.path = ''

