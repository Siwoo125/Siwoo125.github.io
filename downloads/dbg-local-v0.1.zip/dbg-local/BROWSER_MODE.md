# Browser CPU debugger

Public `/debugger/` and `/en/debugger/` use CPU emulation in a Web Worker.
No Python/GDB installation, localhost connection, file upload or paid execution
service is used. The same-origin static engine assets are fetched by the browser.
Advanced native debugging remains available at `/native/` and `/en/native/`.

## Supported operations

- Little-endian x86/x64 ELF executable images and PE32/PE32+ images.
- PT_LOAD/image mapping, BSS zero initialization, a bounded stack and ELF argv.
- Real CPU instructions via pinned Unicorn.js 2.1.4; Capstone.js 5.0.9 decoding.
- Single instruction step; continue (at most 10,000 instructions or 150 ms).
- Address breakpoints, bounded register and memory writes, memory inspection.
- HEX edits to mapped code take effect on the next execution, including code
  executed before the edit. The affected pages are re-mapped to invalidate
  translated instructions, preserving neighbouring bytes and CPU registers.
  No assembly-text editor or patched executable download is included.
- Stack bytes can be inspected at ESP/RSP; browser mode has no call-stack panel.
- Limited Linux read(0), write(1/2), exit and exit_group, including NUL input.
- Up to 32 MiB per file, 64 MiB of image memory, 2 MiB stack, 128 breakpoints,
  and 64 KiB input/output bounds. A worker request timeout terminates a hung
  engine; reopening a file creates a clean worker.

## Local session storage

Auto-save is enabled by default. After each successful action the worker captures
architectural registers (including supported SIMD/x87 registers), mapped RAM,
execution count/status, address breakpoints and queued input/output. IndexedDB
stores the latest checkpoint, original binary, inspected address and up to 100
action summaries on this device. Writes are serialized and reported saved only
after the transaction commits. No binary or checkpoint is uploaded.

Reloading restores a stopped worker without executing target instructions.
Save now captures explicitly, including when auto-save is off. Disabling auto-save
keeps the previous save. Delete saved session removes it and disables auto-save.
The current live session stays open. Storage failures do not stop live debugging.
Browser profiles and origins have separate stores; Korean and English paths on the
same origin share one. Multiple tabs use last-write-wins storage. Private mode,
site-data clearing or browser eviction can remove saved data. This saves one
current browser CPU session, not every instruction or an external GDB process.

## Limits

This is CPU emulation, not a full guest OS or a native process debugger.
Linux dynamic interpreters, shared objects, TLS/process initialization, the
filesystem and other syscalls are not implemented. Windows imports, DLLs,
APIs, TLS callbacks and process initialization are not implemented. A PE/ELF
file can be mapped and inspected even if its OS dependencies cannot run.
Such a file can stop on unsupported calls or unmapped memory. No claim of
compatibility with arbitrary CTF binaries, Windows applications or Linux
programs is made. Native Attach, source symbols, conditional breakpoints,
workspaces and recorded-stop comparison are available in local GDB mode.

## Included original examples

`python3 -m scripts.build_browser_examples` creates ELF32, ELF64, PE32 and PE64
CPU exercises from a documented instruction stream. They compute 5+4+3+2+1,
write 15 to mapped memory and halt with HLT. They are CPU exercises rather
than normal operating-system applications. File extensions do not change
format detection; `.pe` files contain real PE headers and machine code.

- ELF memory result: `0x100200`, bytes `0f 00 00 00`.
- PE32 memory result: `0x401100`.
- PE64 memory result: `0x140001100`.

Tests run the actual pinned WASM engine with these four image formats,
step and address breakpoints, real register/memory edits, Linux input/output
and exit handling, unsupported syscall stops and bounded loops.

## Source and licenses

The browser engine files use GPL-2.0-only headers. Runtime notices and exact
Unicorn binding/core source archives are in `web/vendor/`. Capstone copyright
notices are retained. `web/vendor/NOTICE.txt` lists versions, source commits,
build instructions, licenses and SHA-256 hashes. The site serves these same
files and source archives. Engine code is not downloaded from an external CDN.
