"""Bounded, read-only ELF/PE headers and ASCII strings. No code execution."""
import os
import re
import struct

LIMIT = 16 * 1024 * 1024


def inspect_binary(path):
    with open(path, 'rb') as source:
        data = source.read(LIMIT)
    result = {'format':'unknown', 'size':os.path.getsize(path), 'strings':[],
              'scanned_bytes':len(data), 'strings_limited':False}
    def unpack(fmt, offset):
        if offset < 0 or offset + struct.calcsize(fmt) > len(data):
            raise ValueError('Truncated or unsupported binary header')
        return struct.unpack_from(fmt, data, offset)
    try:
        if data.startswith(b'\x7fELF'):
            bits = {1:32, 2:64}.get(data[4])
            endian = {1:'<', 2:'>'}.get(data[5])
            if not bits or not endian:
                raise ValueError('Unsupported ELF class or byte order')
            kind, machine = unpack(endian+'HH', 16)
            entry = unpack(endian+('I' if bits==32 else 'Q'), 24)[0]
            phoff = unpack(endian+('I' if bits==32 else 'Q'), 28 if bits==32 else 32)[0]
            phsize, phnum = unpack(endian+'HH', 42 if bits==32 else 54)
            nx = None
            if phnum > 256 or (phnum and phsize < (32 if bits==32 else 56)):
                raise ValueError('Unsupported ELF program header table')
            for i in range(phnum):
                offset = phoff + i*phsize
                phkind = unpack(endian+'I', offset)[0]
                if phkind == 0x6474e551:
                    flags = unpack(endian+'I', offset+(24 if bits==32 else 4))[0]
                    nx = not bool(flags & 1)
            result.update(format='ELF', bits=bits, machine={3:'x86',62:'x86-64',40:'ARM',183:'AArch64'}.get(machine,str(machine)),
                          byte_order='little' if endian=='<' else 'big', entry=hex(entry),
                          image_type={2:'ET_EXEC',3:'ET_DYN (PIE/shared)'}.get(kind,str(kind)), nx=nx)
        elif data.startswith(b'MZ'):
            pe = unpack('<I', 0x3c)[0]
            if data[pe:pe+4] != b'PE\0\0':
                raise ValueError('Missing PE signature')
            machine = unpack('<H', pe+4)[0]
            optional_size = unpack('<H', pe+20)[0]
            optional = pe+24
            magic = unpack('<H', optional)[0]
            bits = {0x10b:32,0x20b:64}.get(magic)
            if not bits or optional_size < 72:
                raise ValueError('Unsupported PE optional header')
            entry = unpack('<I', optional+16)[0]
            base = unpack('<I' if bits==32 else '<Q', optional+(28 if bits==32 else 24))[0]
            flags = unpack('<H', optional+70)[0]
            result.update(format='PE', bits=bits, machine={0x14c:'x86',0x8664:'x86-64',0xaa64:'AArch64'}.get(machine,hex(machine)),
                          byte_order='little', entry=hex(base+entry), entry_rva=hex(entry), image_base=hex(base),
                          nx=bool(flags&0x100), aslr=bool(flags&0x40))
    except (ValueError, IndexError, struct.error) as error:
        result['header_error'] = str(error)
    # Offsets are file offsets, not runtime addresses (ASLR is not inferred).
    for match in re.finditer(rb'[\x20-\x7e]{4,}', data):
        if len(result['strings']) == 200:
            result['strings_limited'] = True
            break
        result['strings'].append({'offset':hex(match.start()),'text':match[0][:256].decode('ascii')})
    result['strings_limited'] |= result['size'] > len(data)
    return result
