#!/usr/bin/env python3
"""Serve the debugger UI and authenticated API on IPv4 loopback only."""
import argparse
import hmac
import json
import secrets
import os
import re
import shutil
import tempfile
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, unquote
from debugger import Debugger

ROOT = Path(__file__).parent / 'web'
MAX_BINARY_BYTES = 128 * 1024 * 1024
MAX_SESSION_BYTES = 512 * 1024 * 1024


class LocalServer(ThreadingHTTPServer):
    daemon_threads = True

    def server_close(self):
        super().server_close()
        try:
            if hasattr(self, 'engine'):
                self.engine.close()
        finally:
            if hasattr(self, 'uploads'):
                with self.upload_lock:
                    self.upload_closed = True
                    self.uploads.cleanup()



def make_server(port=8765, debugger=None):
    english_messages = json.loads((Path(__file__).parent/'content/en/ui.json').read_text())
    engine = debugger or Debugger()
    token = secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Never log authentication or local paths.

        def reply(self, status, payload, content_type='application/json; charset=utf-8'):
            if isinstance(payload, dict) and self.headers.get('X-UI-Language') == 'en':
                if 'error' in payload:
                    text = payload['error']
                    prefix = '현재 상태에서는 실행할 수 없는 명령입니다: '
                    payload = {**payload, 'error': ('Command unavailable in state: '+text[len(prefix):] if text.startswith(prefix) else english_messages.get(text,text))}
                result = payload.get('result')
                if isinstance(result,dict) and isinstance(result.get('errors'),dict):
                    result['errors'] = {key:english_messages.get(value,value) for key,value in result['errors'].items()}
            body = json.dumps(payload, ensure_ascii=False).encode() if isinstance(payload, dict) else payload
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Robots-Tag', 'noindex, nofollow')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
            self.end_headers()
            self.wfile.write(body)

        def permitted(self, api=False):
            if self.headers.get('Host') != self.server.authority:
                self.reply(403, {'error':'Invalid Host'})
                return False
            origin = self.headers.get('Origin')
            if origin and origin != self.server.origin:
                self.reply(403, {'error':'외부 웹사이트에서의 연결은 허용하지 않습니다.'})
                return False
            if api and not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                self.reply(401, {'error':'시작 터미널의 인증 URL로 다시 접속하세요.'})
                return False
            return True

        def do_GET(self):
            if not self.permitted():
                return
            files = {'/':('index.html','text/html; charset=utf-8'),
                     '/app.js':('app.js','text/javascript; charset=utf-8'),
                     '/style.css':('style.css','text/css; charset=utf-8'),
                     '/contact.js':('contact.js','text/javascript; charset=utf-8'),
                     '/inspector.js':('inspector.js','text/javascript; charset=utf-8'),
                     '/workbench.js':('workbench.js','text/javascript; charset=utf-8')}
            routes_path = ROOT / 'routes.json'
            if routes_path.exists():
                files.update(json.loads(routes_path.read_text()))
            path = urlsplit(self.path).path
            if path != '/' and not path.endswith('/') and path+'/' in files:
                self.send_response(308)
                self.send_header('Location', path+'/')
                self.send_header('Content-Length','0')
                self.end_headers()
                return
            asset = files.get(path)
            if not asset:
                return self.reply(404, {'error':'Not found'})
            self.reply(200, (ROOT / asset[0]).read_bytes(), asset[1])

        def do_POST(self):
            if not self.permitted(api=True):
                return
            if self.path == '/api/files':
                return self.receive_file()
            if self.path not in ('/api/action', '/api/state'):
                return self.reply(404, {'error':'Not found'})
            if self.headers.get_content_type() != 'application/json':
                return self.reply(415, {'error':'JSON required'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if length <= 0 or length > 16384:
                    return self.reply(413, {'error':'Request too large'})
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict):
                    raise ValueError('JSON object required')
                if self.path == '/api/state':
                    result = engine.snapshot(data.get('address'))
                else:
                    result = engine.action(data.get('action'), data)
                self.reply(200, {'ok': True, 'result':result})
            except (ValueError, RuntimeError, OSError, TypeError, KeyError) as exc:
                self.reply(400, {'error':str(exc)})

        def receive_file(self):
            # This endpoint stages bytes only; execution still requires Run.
            self.close_connection = True
            if self.headers.get_content_type() != 'application/octet-stream':
                return self.reply(415, {'error':'바이너리 파일 형식으로 전송하세요.'})
            if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length', [])) != 1:
                return self.reply(400, {'error':'파일 크기가 필요합니다.'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= MAX_BINARY_BYTES:
                    return self.reply(413, {'error':'파일은 1바이트 이상, 128 MiB 이하여야 합니다.'})
                name = unquote(self.headers.get('X-Filename',''), errors='strict')
                if (not name or name in ('.', '..') or len(name.encode('utf-8')) > 240
                        or re.search(r'[\\/:*?"<>|\x00-\x1f\x7f]', name)
                        or name.endswith((' ', '.'))
                        or re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³])', name.split('.')[0], re.I)):
                    return self.reply(400, {'error':'사용할 수 없는 파일 이름입니다.'})
                with self.server.upload_lock:
                    if self.server.upload_closed:
                        return self.reply(503, {'error':'서버가 종료 중입니다.'})
                    if (self.server.upload_bytes + length > MAX_SESSION_BYTES
                            or self.server.upload_count >= 32):
                        return self.reply(413, {'error':'세션의 임시 파일 한도에 도달했습니다. 서버를 재시작하세요.'})
                    directory = Path(tempfile.mkdtemp(prefix='binary-', dir=self.server.uploads.name))
                    path = directory / name
                    try:
                        self.connection.settimeout(30)
                        with path.open('xb') as output:
                            remaining = length
                            while remaining:
                                chunk = self.rfile.read(min(remaining, 1024 * 1024))
                                if not chunk:
                                    raise ValueError('파일 전송이 중단되었습니다.')
                                output.write(chunk)
                                remaining -= len(chunk)
                        os.chmod(path, 0o700)
                    except Exception:
                        shutil.rmtree(directory)
                        raise
                    self.server.upload_bytes += length
                    self.server.upload_count += 1
                self.reply(200, {'ok': True, 'result': {'path':str(path), 'name':name, 'size':length}})
            except (ValueError, OSError, UnicodeError) as exc:
                self.reply(400, {'error':str(exc)})

    server = LocalServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    server.authority = f'127.0.0.1:{server.server_port}'
    server.origin = 'http://' + server.authority
    server.engine, server.token = engine, token
    server.uploads = tempfile.TemporaryDirectory(prefix='dbgdesk-')
    server.upload_lock = threading.Lock()
    server.upload_bytes, server.upload_count = 0, 0
    server.upload_closed = False
    return server


def main():
    parser = argparse.ArgumentParser(description='DBG / local native debugger')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--gdb', help='Path to gdb.exe / gdb')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    from scripts.build_content import build
    build()
    server = make_server(args.port, Debugger(args.gdb))
    url = server.origin + '/#token=' + server.token
    print('DBG Desk — 이 URL은 이 PC에서만 사용하세요.\n' + url, flush=True)
    if not args.no_browser:
        threading.Timer(.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
