"""Local GDB/MI bridge. Python stdlib only; no shell execution."""
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from collections import deque
from inferior_io import TargetIO
from binary_info import inspect_binary


class MIParser:
    def __init__(self, text):
        self.text, self.i = text, 0

    def value(self):
        s = self.text
        if self.i >= len(s):
            raise ValueError('Incomplete MI value')
        c = s[self.i]
        if c == '"':
            start = self.i
            self.i += 1
            while self.i < len(s):
                if s[self.i] == '\\':
                    self.i += 2
                elif s[self.i] == '"':
                    self.i += 1
                    # GDB uses C strings (including octal escapes).
                    raw = s[start + 1:self.i - 1]
                    encoded = bytearray()
                    cursor = 0
                    for escape in re.finditer(r'\\([0-7]{1,3}|.)', raw):
                        encoded.extend(raw[cursor:escape.start()].encode('utf-8'))
                        x = escape.group(1)
                        if x[0].isdigit():
                            encoded.append(int(x, 8) & 255)
                        else:
                            encoded.extend({'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','v':'\v','a':'\a'}.get(x, x).encode('utf-8'))
                        cursor = escape.end()
                    encoded.extend(raw[cursor:].encode('utf-8'))
                    return encoded.decode('utf-8', errors='replace')
                else:
                    self.i += 1
            raise ValueError('Unterminated MI string')
        if c in '[{':
            self.i += 1
            end, items, mapping = (']' if c == '[' else '}'), [], {}
            while self.i < len(s) and s[self.i] != end:
                match = re.match(r'([\w-]+)=', s[self.i:])
                if match:
                    self.i += len(match[0])
                    key, val = match[1], self.value()
                    if c == '[':
                        items.append({key: val})
                    else:
                        mapping[key] = val
                else:
                    items.append(self.value())
                if self.i < len(s) and s[self.i] == ',':
                    self.i += 1
                elif self.i < len(s) and s[self.i] != end:
                    raise ValueError('Malformed MI collection')
            if self.i >= len(s):
                raise ValueError('Unterminated MI collection')
            self.i += 1
            return items if c == '[' else mapping
        raise ValueError('Unexpected MI value')


def record(line):
    m = re.match(r'^(\d*)([\^*=+~@&])(.*)$', line.strip())
    if not m:
        return None
    token, kind, rest = m.groups()
    if kind in '~@&':
        return {'token': token, 'kind': kind, 'text': MIParser(rest).value()}
    cls, _, payload = rest.partition(',')
    return {'token': token, 'kind': kind, 'class': cls,
            'data': MIParser('{' + payload + '}').value() if payload else {}}


def quote(value):
    escaped = ''
    for char in str(value):
        if char in ('"', '\\'):
            escaped += '\\' + char
        elif ord(char) < 32 or ord(char) == 127:
            escaped += '\\' + format(ord(char), '03o')
        else:
            escaped += char
    return '"' + escaped + '"'


class Debugger:
    def __init__(self, executable=None):
        self.executable = executable or os.environ.get('GDB_PATH') or shutil.which('gdb')
        if not self.executable and os.name == 'nt':
            self.executable = next((path for path in [r'C:\msys64\ucrt64\bin\gdb.exe',r'C:\msys64\mingw64\bin\gdb.exe'] if os.path.isfile(path)), None)
        self.proc = None
        self.reader = None
        self.lock = threading.RLock()
        self.pending_lock = threading.Lock()
        self.pending = {}
        self.serial = 0
        self.events = deque(maxlen=400)
        self.state = 'disconnected'
        self.stop = {}
        self.path = ''
        self.register_names = []
        self.attached = False
        self.stop_sequence = 0
        self.target_id = 0
        self.selected_frame = 0
        self.target_io = TargetIO()
        self.input_mode = 'unavailable'
        self.input_error = ''
        self.binary_info = {}

    def start(self):
        if self.proc and self.proc.poll() is None:
            return
        if not self.executable:
            raise RuntimeError('GDB를 찾을 수 없습니다. 대상 운영체제용 GDB를 설치하고 GDB_PATH를 설정하세요.')
        self.proc = subprocess.Popen([self.executable, '--quiet', '--nx', '--interpreter=mi2',
                                     '-iex', 'set auto-load off'],
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1)
        self.state = 'idle'
        self.reader = threading.Thread(target=self._read, args=(self.proc,), daemon=True)
        self.reader.start()
        self.command('-gdb-set host-charset UTF-8')
        self.command('-gdb-set pagination off')
        self.command('-gdb-set confirm off')
        self.command('-gdb-set mi-async on')
        self.command('-gdb-set may-call-functions off', optional=True)
        self.command('-gdb-set startup-with-shell off', optional=True)
        self.command('-gdb-set disassembly-flavor intel', optional=True)
        self.input_mode, self.input_error = 'unavailable', ''
        try:
            if os.name == 'posix':
                self.command('-inferior-tty-set '+quote(self.target_io.open()))
                self.input_mode = 'pty'
            elif os.name == 'nt':
                self.command('-gdb-set new-console on')
                self.input_mode = 'console'
        except (OSError, RuntimeError) as error:
            self.target_io.close()
            self.input_error = str(error)

    def _read(self, proc):
        for line in proc.stdout:
            try:
                row = record(line)
            except ValueError:
                row = None
            if row is None:
                if line.strip() != '(gdb)':
                    self.events.append(line.rstrip())
                continue
            if row['kind'] == '^':
                with self.pending_lock:
                    waiter = self.pending.get(row['token'])
                if waiter:
                    waiter.put(row)
            elif row['kind'] == '*' and row['class'] == 'running':
                self.state = 'running'
            elif row['kind'] == '*' and row['class'] == 'stopped':
                self.stop = row['data']
                self.stop_sequence += 1
                self.selected_frame = 0
                self.state = 'exited' if self.stop.get('reason', '').startswith('exited') else 'stopped'
                self.events.append('STOP ' + json.dumps(self.stop, ensure_ascii=False))
            elif row['kind'] in '~@&':
                self.events.append(row['text'].rstrip())
            elif row['kind'] == '=' and row['class'] == 'thread-group-exited':
                self.state = 'exited'
        self.state = 'disconnected'
        with self.pending_lock:
            for waiter in self.pending.values():
                waiter.put({'class':'error','data':{'msg':'GDB 프로세스가 종료되었습니다.'}})

    def command(self, cmd, optional=False):
        with self.lock:
            if not self.proc or self.proc.poll() is not None:
                raise RuntimeError('디버거가 연결되지 않았습니다.')
            self.serial += 1
            token, waiter = str(self.serial), queue.Queue()
            with self.pending_lock:
                self.pending[token] = waiter
            try:
                self.proc.stdin.write(token + cmd + '\n')
                self.proc.stdin.flush()
                try:
                    result = waiter.get(timeout=12)
                except queue.Empty:
                    raise RuntimeError('GDB 응답 시간 초과. 상태를 확인하고 필요하면 디버거를 재시작하세요.')
                if result['class'] == 'error':
                    if optional:
                        return {'error': result['data'].get('msg', 'GDB error')}
                    raise RuntimeError(result['data'].get('msg', 'GDB error'))
                return result['data']
            finally:
                with self.pending_lock:
                    self.pending.pop(token, None)

    def action(self, action, data):
        with self.lock:
            if action == 'connect':
                self.start()
                return {}
            if action == 'load':
                if self.state not in ('idle', 'loaded', 'exited'):
                    raise ValueError('대상을 바꾸기 전에 Detach 또는 종료하세요.')
                path = os.path.abspath(data.get('path', ''))
                if not os.path.isfile(path):
                    raise ValueError('사용자 PC에 존재하는 실행 파일의 절대 경로를 입력하세요.')
                args = data.get('args', [])
                if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
                    raise ValueError('프로그램 인수는 문자열 JSON 배열이어야 합니다.')
                self.command('-file-exec-and-symbols ' + quote(path))
                self.command('-exec-arguments ' + ' '.join(quote(a) for a in args))
                self.path, self.state, self.attached = path, 'loaded', False
                self.selected_frame = 0
                self.register_names = []
                self.target_id += 1
                self.target_io.clear()
                self.binary_info = inspect_binary(path)
                return {}
            if action == 'attach':
                if self.state not in ('idle', 'exited'):
                    raise ValueError('먼저 현재 대상에서 Detach 하세요.')
                pid = int(data.get('pid', 0))
                if pid <= 0:
                    raise ValueError('올바른 PID를 입력하세요.')
                result = self.command('-target-attach ' + str(pid))
                self.attached, self.register_names = True, []
                self.path = ''
                self.binary_info = {}
                self.target_id += 1
                return result
            if action == 'symbol-address':
                name = data.get('name', '')
                if self.state != 'stopped' or not isinstance(name,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}',name):
                    raise ValueError('정지 상태에서 단순 심볼 이름을 입력하세요. 예: gate')
                value = self.command('-data-evaluate-expression '+quote('&'+name)).get('value','')
                match = re.match(r'0x[0-9a-fA-F]+', value)
                if not match:
                    raise ValueError('심볼의 실제 주소를 확인할 수 없습니다.')
                return {'name':name,'address':match[0]}
            if action in ('memory-write', 'register-write'):
                if self.state != 'stopped':
                    raise ValueError('값 수정은 프로세스가 정지한 상태에서만 가능합니다.')
                if action == 'memory-write':
                    address = data.get('address', '')
                    contents = data.get('hex', '')
                    if not isinstance(address, str) or not re.fullmatch(r'0x[0-9a-fA-F]{1,16}', address):
                        raise ValueError('수정할 메모리의 실제 0x주소를 입력하세요.')
                    if not isinstance(contents, str) or not re.fullmatch(r'[0-9a-fA-F\s]{2,1024}', contents):
                        raise ValueError('쓸 바이트를 HEX로 입력하세요. 최대 256바이트입니다.')
                    contents = re.sub(r'\s', '', contents)
                    if not 2 <= len(contents) <= 512 or len(contents)%2:
                        raise ValueError('쓸 바이트를 HEX로 입력하세요. 최대 256바이트입니다.')
                    before = self.command('-data-read-memory-bytes '+address+' '+str(len(contents)//2))
                    self.command('-data-write-memory-bytes '+address+' '+quote(contents))
                    after = self.command('-data-read-memory-bytes '+address+' '+str(len(contents)//2))
                    actual = ''.join(item.get('contents','') for item in after.get('memory',[]))
                    if actual.lower() != contents.lower():
                        raise RuntimeError('메모리 쓰기 후 검증에 실패했습니다. 현재 값을 다시 확인하세요.')
                    self.events.append('MEMORY WRITE '+address+' '+contents)
                    return {'address':address, 'before':before.get('memory',[]), 'after':after.get('memory',[])}
                name, value = data.get('name', ''), data.get('value', '')
                if self.selected_frame != 0:
                    raise ValueError('레지스터 수정은 호출 프레임 0을 선택한 뒤 실행하세요.')
                if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,31}', name):
                    raise ValueError('올바른 레지스터 이름을 선택하세요.')
                if not isinstance(value, str) or not re.fullmatch(r'(?:0x[0-9a-fA-F]{1,16}|-?[0-9]{1,20})', value):
                    raise ValueError('레지스터 값은 64비트 범위의 정수 또는 0x값으로 입력하세요.')
                number = int(value, 16 if value.startswith('0x') else 10)
                if not -(1<<63) <= number < (1<<64):
                    raise ValueError('레지스터 값은 64비트 범위의 정수 또는 0x값으로 입력하세요.')
                if not self.register_names:
                    self.register_names = self.command('-data-list-register-names').get('register-names', [])
                if name not in self.register_names:
                    raise ValueError('현재 대상에 없는 레지스터입니다.')
                index = self.register_names.index(name)
                before = self.command('-data-list-register-values x '+str(index))
                self.command('-data-write-register-values x '+str(index)+' '+hex(number))
                after = self.command('-data-list-register-values x '+str(index))
                self.events.append('REGISTER WRITE '+name+' '+hex(number))
                return {'name':name,'before':before.get('register-values',[]),'after':after.get('register-values',[])}
            if action == 'input-send':
                if self.state not in ('running', 'stopped') or self.attached or self.input_mode != 'pty':
                    raise ValueError('웹 입력은 직접 실행한 POSIX 대상의 실행·정지 상태에서 사용하세요. Windows는 별도 콘솔을 사용합니다.')
                value, mode = data.get('value', ''), data.get('mode', 'text')
                if not isinstance(value,str) or not 0 < len(value) <= 8192 or mode not in ('text','hex'):
                    raise ValueError('입력은 UTF-8 텍스트 또는 HEX로 최대 4096바이트까지 전송하세요.')
                if mode == 'hex':
                    if not re.fullmatch(r'[0-9a-fA-F\s]+', value):
                        raise ValueError('HEX 입력을 확인하세요.')
                    try: payload = bytes.fromhex(value)
                    except ValueError: raise ValueError('HEX 입력을 확인하세요.') from None
                else:
                    payload = value.encode('utf-8')
                return {'sent':self.target_io.send(payload)}
            if action == 'detach':
                result = self.command('-target-detach')
                self.state, self.path, self.attached = 'idle', '', False
                return result
            breakpoint_actions = ('break-add', 'break-delete', 'break-enable', 'break-disable', 'watch-add')
            if action in breakpoint_actions and self.state not in ('loaded', 'stopped', 'exited'):
                raise ValueError('중단점은 파일을 연 뒤 정지 상태에서 설정하세요.')
            if action == 'break-add':
                location = self.break_location(data.get('location', ''))
                condition = data.get('condition', '')
                if not isinstance(condition, str) or len(condition) > 200 or any(ord(c)<32 or ord(c)==127 for c in condition):
                    raise ValueError('조건은 변수 또는 레지스터와 정수의 비교식으로 입력하세요. 예: count == 3')
                condition = condition.strip()
                operand = r'(?:\$?[A-Za-z_][A-Za-z_0-9]*|-?(?:0x[0-9a-fA-F]+|[0-9]+))'
                if condition and not re.fullmatch(operand+r'\s*(?:==|!=|<=|>=|<|>)\s*'+operand, condition):
                    raise ValueError('조건은 변수 또는 레지스터와 정수의 비교식으로 입력하세요. 예: count == 3')
                ignore = str(data.get('ignore', 0))
                if not re.fullmatch(r'[0-9]{1,7}', ignore) or int(ignore) > 1000000:
                    raise ValueError('건너뛸 횟수는 0~1000000 사이의 정수로 입력하세요.')
                temporary = data.get('temporary', False)
                if not isinstance(temporary, bool):
                    raise ValueError('임시 중단점 설정이 올바르지 않습니다.')
                options = (' -t' if temporary else '') + (' -c '+quote(condition) if condition else '')
                if int(ignore):
                    options += ' -i '+str(int(ignore))
                return self.command('-break-insert'+options+' '+quote(location))
            if action in ('break-delete', 'break-enable', 'break-disable'):
                number = str(data.get('number', ''))
                if not re.fullmatch(r'\d+(?:\.\d+)?', number):
                    raise ValueError('잘못된 중단점 번호')
                return self.command('-'+action+' '+number)
            if action == 'watch-add':
                address = data.get('address', '')
                size = str(data.get('size', '4'))
                mode = data.get('mode', 'write')
                if not isinstance(address, str) or not re.fullmatch(r'0x[0-9a-fA-F]{1,16}', address):
                    raise ValueError('데이터 중단점 주소는 0x로 시작하는 실제 주소로 입력하세요.')
                if size not in ('1','2','4','8') or mode not in ('write','read','access'):
                    raise ValueError('데이터 중단점 크기 또는 접근 종류가 올바르지 않습니다.')
                ctype = {'1':'unsigned char','2':'unsigned short','4':'unsigned int','8':'unsigned long long'}[size]
                option = {'write':'','read':' -r','access':' -a'}[mode]
                return self.command('-break-watch'+option+' '+quote('*('+ctype+'*)'+address))
            if action in ('thread-select', 'frame-select'):
                if self.state != 'stopped':
                    raise ValueError('스레드와 프레임은 정지 상태에서 선택하세요.')
                field = 'thread' if action == 'thread-select' else 'frame'
                number = str(data.get(field, ''))
                if not re.fullmatch(r'[0-9]{1,8}', number) or (field == 'thread' and int(number) == 0):
                    raise ValueError('스레드 또는 프레임 번호가 올바르지 않습니다.')
                result = self.command(('-thread-select ' if field == 'thread' else '-stack-select-frame ')+number)
                self.selected_frame = 0 if field == 'thread' else int(number)
                return result
            if action == 'run-to':
                if self.state != 'stopped':
                    raise ValueError('선택한 주소까지 실행하려면 먼저 정지하세요.')
                address = data.get('address', '')
                if not isinstance(address, str) or not re.fullmatch(r'0x[0-9a-fA-F]{1,16}', address):
                    raise ValueError('실행할 주소가 올바르지 않습니다.')
                inserted = self.command('-break-insert -t '+quote('*'+address))
                number = str(inserted.get('bkpt', {}).get('number', ''))
                self.state = 'running'
                try:
                    return self.command('-exec-continue')
                except Exception:
                    if self.state == 'running': self.state = 'stopped'
                    if re.fullmatch(r'\d+(?:\.\d+)?', number):
                        self.command('-break-delete '+number, optional=True)
                    raise
            commands = {'entry':'-interpreter-exec console "starti"', 'run':'-exec-run --start', 'continue':'-exec-continue',
                        'pause':'-exec-interrupt --all', 'step':'-exec-step-instruction',
                        'next':'-exec-next-instruction', 'finish':'-exec-finish',
                        'source-step':'-exec-step', 'source-next':'-exec-next'}
            if action in commands:
                allowed = {'run': ('loaded', 'exited'), 'entry': ('loaded', 'exited'), 'pause': ('running',)}.get(action, ('stopped',))
                if self.state not in allowed:
                    raise ValueError('현재 상태에서는 실행할 수 없는 명령입니다: ' + self.state)
                if action in ('run', 'entry') and self.attached:
                    raise ValueError('연결한 프로세스는 Continue를 사용하세요.')
                previous = self.state
                self.state = 'running' if action != 'pause' else self.state
                try:
                    command = commands[action]
                    if action in ('run', 'entry'):
                        self.target_io.clear()
                    if action == 'run':
                        breaks = self.command('-break-list').get('BreakpointTable', {}).get('body', [])
                        if any((item.get('bkpt', item)).get('enabled') == 'y' for item in breaks):
                            command = '-exec-run'
                    return self.command(command)
                except Exception:
                    if self.state == 'running':
                        self.state = previous
                    raise
            raise ValueError('지원하지 않는 명령')

    @staticmethod
    def break_location(location):
        if not isinstance(location, str):
            raise ValueError('함수, 파일:줄 또는 *0x주소를 입력하세요.')
        location = location.strip()
        if not location or len(location) > 300 or location.startswith('-') or any(ord(c)<32 or ord(c)==127 for c in location):
            raise ValueError('함수, 파일:줄 또는 *0x주소를 입력하세요.')
        return location

    @staticmethod
    def address_expression(value):
        operand = r'(?:0x[0-9a-fA-F]{1,16}|[0-9]{1,20}|\$[A-Za-z][A-Za-z0-9_]{0,31})'
        if not isinstance(value, str) or not re.fullmatch(operand+r'(?:[+-](?:0x[0-9a-fA-F]{1,16}|[0-9]{1,20}))?', value):
            raise ValueError('주소는 0x주소, 정수 또는 $레지스터와 정수 오프셋으로 입력하세요.')
        return value

    def snapshot(self, address=None, assembly_address=None):
        with self.lock:
            state = self.state
            result = {'state':state, 'path':self.path, 'stop':self.stop,
                      'stop_sequence':self.stop_sequence, 'target_id':self.target_id,
                      'events':list(self.events), 'engine':self.executable,
                      'binary':self.binary_info, 'input':{'mode':self.input_mode, 'error':self.input_error,
                      'available':self.input_mode=='pty' and not self.attached, 'output':self.target_io.text()},
                      'registers':[], 'assembly':[], 'stack':[], 'breakpoints':[], 'memory':[], 'errors':{},
                      'threads':[], 'current_thread':'', 'selected_frame':self.selected_frame, 'frame':{}, 'locals':[]}
            if state in ('idle', 'disconnected', 'running'):
                return result
            def fetch(key, command):
                value = self.command(command, optional=True)
                if 'error' in value:
                    result['errors'][key] = value['error']
                return value
            result['breakpoints'] = fetch('breakpoints', '-break-list').get('BreakpointTable', {}).get('body', [])
            if state != 'stopped':
                return result
            info = fetch('threads', '-thread-info')
            result['threads'] = info.get('threads', [])[:256]
            result['current_thread'] = info.get('current-thread-id', '')
            result['frame'] = fetch('frame', '-stack-info-frame').get('frame', {})
            result['locals'] = fetch('locals', '-stack-list-variables --simple-values').get('variables', [])[:128]
            if not self.register_names:
                self.register_names = fetch('registers', '-data-list-register-names').get('register-names', [])
            values = fetch('registers', '-data-list-register-values x').get('register-values', [])
            for item in values:
                n = int(item['number'])
                name = self.register_names[n] if n < len(self.register_names) else str(n)
                if name:
                    result['registers'].append({'name':name, 'value':item['value']})
            assembly_address = self.address_expression(assembly_address or '$pc')
            result['assembly'] = fetch('assembly', '-data-disassemble -s '+quote(assembly_address)+' -e '+quote('('+assembly_address+')+256')+' -- 2').get('asm_insns', [])
            result['stack'] = fetch('stack', '-stack-list-frames 0 30').get('stack', [])
            if address is None:
                address = '$sp'
            address = self.address_expression(address)
            result['memory'] = fetch('memory', '-data-read-memory-bytes ' + quote(address) + ' 256').get('memory', [])
            return result

    def close(self):
        proc = self.proc
        if not proc:
            self.target_io.close()
            return
        try:
            if proc.poll() is None:
                try:
                    if self.state == 'running':
                        self.command('-exec-interrupt --all', optional=True)
                        deadline = time.monotonic() + 2
                        while self.state == 'running' and time.monotonic() < deadline:
                            time.sleep(.05)
                    if self.state == 'stopped':
                        self.command('-target-detach', optional=True)
                except RuntimeError:
                    pass  # The engine may exit while shutdown is already underway.
                if proc.poll() is None:
                    proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
        finally:
            if self.reader and self.reader is not threading.current_thread():
                self.reader.join(timeout=2)
            for stream in (proc.stdin, proc.stdout):
                if stream:
                    stream.close()
            self.proc = None
            self.state = 'disconnected'
            self.target_io.close()
