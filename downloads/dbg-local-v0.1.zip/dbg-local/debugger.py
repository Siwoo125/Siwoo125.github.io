"""Local GDB/MI bridge. Python stdlib only; no shell execution."""
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from collections import deque


class MIParser:
    def __init__(self, text):
        self.text, self.i = text, 0

    def value(self):
        s = self.text
        if self.i >= len(s):
            raise ValueError('Incomplete MI value')
        c = s[self.i]
        if c == '"':
            start = self.i
            self.i += 1
            while self.i < len(s):
                if s[self.i] == '\\':
                    self.i += 2
                elif s[self.i] == '"':
                    self.i += 1
                    # GDB uses C strings (including octal escapes).
                    raw = s[start + 1:self.i - 1]
                    encoded = bytearray()
                    cursor = 0
                    for escape in re.finditer(r'\\([0-7]{1,3}|.)', raw):
                        encoded.extend(raw[cursor:escape.start()].encode('utf-8'))
                        x = escape.group(1)
                        if x[0].isdigit():
                            encoded.append(int(x, 8) & 255)
                        else:
                            encoded.extend({'n':'\n','r':'\r','t':'\t','b':'\b','f':'\f','v':'\v','a':'\a'}.get(x, x).encode('utf-8'))
                        cursor = escape.end()
                    encoded.extend(raw[cursor:].encode('utf-8'))
                    return encoded.decode('utf-8', errors='replace')
                else:
                    self.i += 1
            raise ValueError('Unterminated MI string')
        if c in '[{':
            self.i += 1
            end, items, mapping = (']' if c == '[' else '}'), [], {}
            while self.i < len(s) and s[self.i] != end:
                match = re.match(r'([\w-]+)=', s[self.i:])
                if match:
                    self.i += len(match[0])
                    key, val = match[1], self.value()
                    if c == '[':
                        items.append({key: val})
                    else:
                        mapping[key] = val
                else:
                    items.append(self.value())
                if self.i < len(s) and s[self.i] == ',':
                    self.i += 1
                elif self.i < len(s) and s[self.i] != end:
                    raise ValueError('Malformed MI collection')
            if self.i >= len(s):
                raise ValueError('Unterminated MI collection')
            self.i += 1
            return items if c == '[' else mapping
        raise ValueError('Unexpected MI value')


def record(line):
    m = re.match(r'^(\d*)([\^*=+~@&])(.*)$', line.strip())
    if not m:
        return None
    token, kind, rest = m.groups()
    if kind in '~@&':
        return {'token': token, 'kind': kind, 'text': MIParser(rest).value()}
    cls, _, payload = rest.partition(',')
    return {'token': token, 'kind': kind, 'class': cls,
            'data': MIParser('{' + payload + '}').value() if payload else {}}


def quote(value):
    escaped = ''
    for char in str(value):
        if char in ('"', '\\'):
            escaped += '\\' + char
        elif ord(char) < 32 or ord(char) == 127:
            escaped += '\\' + format(ord(char), '03o')
        else:
            escaped += char
    return '"' + escaped + '"'


class Debugger:
    def __init__(self, executable=None):
        self.executable = executable or os.environ.get('GDB_PATH') or shutil.which('gdb')
        self.proc = None
        self.lock = threading.RLock()
        self.pending_lock = threading.Lock()
        self.pending = {}
        self.serial = 0
        self.events = deque(maxlen=400)
        self.state = 'disconnected'
        self.stop = {}
        self.path = ''
        self.register_names = []
        self.attached = False
        self.stop_sequence = 0
        self.target_id = 0

    def start(self):
        if self.proc and self.proc.poll() is None:
            return
        if not self.executable:
            raise RuntimeError('GDB를 찾을 수 없습니다. Windows용 GDB를 설치하고 GDB_PATH를 설정하세요.')
        self.proc = subprocess.Popen([self.executable, '--quiet', '--nx', '--interpreter=mi2',
                                     '-iex', 'set auto-load off'],
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1)
        self.state = 'idle'
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()
        self.command('-gdb-set host-charset UTF-8')
        self.command('-gdb-set pagination off')
        self.command('-gdb-set confirm off')
        self.command('-gdb-set mi-async on')
        self.command('-gdb-set disassembly-flavor intel', optional=True)

    def _read(self, proc):
        for line in proc.stdout:
            try:
                row = record(line)
            except ValueError:
                row = None
            if row is None:
                if line.strip() != '(gdb)':
                    self.events.append(line.rstrip())
                continue
            if row['kind'] == '^':
                with self.pending_lock:
                    waiter = self.pending.get(row['token'])
                if waiter:
                    waiter.put(row)
            elif row['kind'] == '*' and row['class'] == 'running':
                self.state = 'running'
            elif row['kind'] == '*' and row['class'] == 'stopped':
                self.stop = row['data']
                self.stop_sequence += 1
                self.state = 'exited' if self.stop.get('reason', '').startswith('exited') else 'stopped'
                self.events.append('STOP ' + json.dumps(self.stop, ensure_ascii=False))
            elif row['kind'] in '~@&':
                self.events.append(row['text'].rstrip())
            elif row['kind'] == '=' and row['class'] == 'thread-group-exited':
                self.state = 'exited'
        self.state = 'disconnected'
        with self.pending_lock:
            for waiter in self.pending.values():
                waiter.put({'class':'error','data':{'msg':'GDB 프로세스가 종료되었습니다.'}})

    def command(self, cmd, optional=False):
        with self.lock:
            if not self.proc or self.proc.poll() is not None:
                raise RuntimeError('디버거가 연결되지 않았습니다.')
            self.serial += 1
            token, waiter = str(self.serial), queue.Queue()
            with self.pending_lock:
                self.pending[token] = waiter
            try:
                self.proc.stdin.write(token + cmd + '\n')
                self.proc.stdin.flush()
                try:
                    result = waiter.get(timeout=12)
                except queue.Empty:
                    raise RuntimeError('GDB 응답 시간 초과. 상태를 확인하고 필요하면 디버거를 재시작하세요.')
                if result['class'] == 'error':
                    if optional:
                        return {'error': result['data'].get('msg', 'GDB error')}
                    raise RuntimeError(result['data'].get('msg', 'GDB error'))
                return result['data']
            finally:
                with self.pending_lock:
                    self.pending.pop(token, None)

    def action(self, action, data):
        with self.lock:
            if action == 'connect':
                self.start()
                return {}
            if action == 'load':
                if self.state not in ('idle', 'loaded', 'exited'):
                    raise ValueError('대상을 바꾸기 전에 Detach 또는 종료하세요.')
                path = os.path.abspath(data.get('path', ''))
                if not os.path.isfile(path):
                    raise ValueError('사용자 PC에 존재하는 실행 파일의 절대 경로를 입력하세요.')
                args = data.get('args', [])
                if not isinstance(args, list) or not all(isinstance(a, str) for a in args):
                    raise ValueError('프로그램 인수는 문자열 JSON 배열이어야 합니다.')
                self.command('-file-exec-and-symbols ' + quote(path))
                self.command('-exec-arguments ' + ' '.join(quote(a) for a in args))
                self.path, self.state, self.attached = path, 'loaded', False
                self.register_names = []
                self.target_id += 1
                return {}
            if action == 'attach':
                if self.state not in ('idle', 'exited'):
                    raise ValueError('먼저 현재 대상에서 Detach 하세요.')
                pid = int(data.get('pid', 0))
                if pid <= 0:
                    raise ValueError('올바른 PID를 입력하세요.')
                result = self.command('-target-attach ' + str(pid))
                self.attached, self.register_names = True, []
                self.path = ''
                self.target_id += 1
                return result
            if action == 'detach':
                result = self.command('-target-detach')
                self.state, self.path, self.attached = 'idle', '', False
                return result
            if action == 'break-add':
                location = data.get('location', '').strip()
                if not location or len(location) > 300:
                    raise ValueError('함수, 파일:줄 또는 *0x주소를 입력하세요.')
                return self.command('-break-insert ' + quote(location))
            if action == 'break-delete':
                number = str(data.get('number', ''))
                if not re.fullmatch(r'\d+(?:\.\d+)?', number):
                    raise ValueError('잘못된 중단점 번호')
                return self.command('-break-delete ' + number)
            commands = {'run':'-exec-run --start', 'continue':'-exec-continue',
                        'pause':'-exec-interrupt --all', 'step':'-exec-step-instruction',
                        'next':'-exec-next-instruction', 'finish':'-exec-finish'}
            if action in commands:
                allowed = {'run': ('loaded', 'exited'), 'pause': ('running',)}.get(action, ('stopped',))
                if self.state not in allowed:
                    raise ValueError('현재 상태에서는 실행할 수 없는 명령입니다: ' + self.state)
                if action == 'run' and self.attached:
                    raise ValueError('연결한 프로세스는 Continue를 사용하세요.')
                previous = self.state
                self.state = 'running' if action != 'pause' else self.state
                try:
                    command = commands[action]
                    if action == 'run':
                        breaks = self.command('-break-list').get('BreakpointTable', {}).get('body', [])
                        if any((item.get('bkpt', item)).get('enabled') == 'y' for item in breaks):
                            command = '-exec-run'
                    return self.command(command)
                except Exception:
                    if self.state == 'running':
                        self.state = previous
                    raise
            raise ValueError('지원하지 않는 명령')

    def snapshot(self, address=None):
        with self.lock:
            state = self.state
            result = {'state':state, 'path':self.path, 'stop':self.stop,
                      'stop_sequence':self.stop_sequence, 'target_id':self.target_id,
                      'events':list(self.events), 'engine':self.executable,
                      'registers':[], 'assembly':[], 'stack':[], 'breakpoints':[], 'memory':[], 'errors':{}}
            if state in ('idle', 'disconnected', 'running'):
                return result
            def fetch(key, command):
                value = self.command(command, optional=True)
                if 'error' in value:
                    result['errors'][key] = value['error']
                return value
            result['breakpoints'] = fetch('breakpoints', '-break-list').get('BreakpointTable', {}).get('body', [])
            if state != 'stopped':
                return result
            if not self.register_names:
                self.register_names = fetch('registers', '-data-list-register-names').get('register-names', [])
            values = fetch('registers', '-data-list-register-values x').get('register-values', [])
            for item in values:
                n = int(item['number'])
                name = self.register_names[n] if n < len(self.register_names) else str(n)
                if name:
                    result['registers'].append({'name':name, 'value':item['value']})
            result['assembly'] = fetch('assembly', '-data-disassemble -s "$pc" -e "$pc+96" -- 2').get('asm_insns', [])
            result['stack'] = fetch('stack', '-stack-list-frames 0 30').get('stack', [])
            if address is None:
                address = '$sp'
            if not re.fullmatch(r'(?:0x[0-9a-fA-F]+|[0-9]+|\$(?:sp|pc|rsp|esp|rbp|ebp))', address):
                raise ValueError('메모리 주소는 0x주소, 숫자 또는 $sp/$pc/$rsp/$esp/$rbp/$ebp로 입력하세요.')
            result['memory'] = fetch('memory', '-data-read-memory-bytes ' + quote(address) + ' 256').get('memory', [])
            return result

    def close(self):
        if self.proc and self.proc.poll() is None:
            # Give async-capable targets a chance to detach cleanly.
            if self.state == 'running':
                self.command('-exec-interrupt --all', optional=True)
                deadline = time.monotonic() + 2
                while self.state == 'running' and time.monotonic() < deadline:
                    time.sleep(.05)
            if self.state == 'stopped':
                self.command('-target-detach', optional=True)
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
