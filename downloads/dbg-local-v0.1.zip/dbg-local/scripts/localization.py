"""Localize static markup and preserve a matching route in both languages."""
import html
import json
import re
from html.parser import HTMLParser
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EN=json.loads((ROOT/'content/en/ui.json').read_text())
EN.update(json.loads((ROOT/'content/en/browser.json').read_text()))


def language_path(path, language):
    return '/en'+path if language=='en' else path


def language_links(path, language):
    return '<div class="language-switch" aria-label="Language">' + ''.join(
        f'<a href="{language_path(path,code)}" lang="{code}" hreflang="{code}"' +
        (' aria-current="true"' if code==language else '') + f'>{label}</a>'
        for code,label in [('ko','한국어'),('en','English')])+'</div>'


class EnglishMarkup(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.output=[]

    def text(self, text):
        core=text.strip()
        translated=EN.get(core,core)
        if core.endswith(' | DBG Desk'):
            translated=EN.get(core[:-11],core[:-11])+' | DBG Desk'
        if core.startswith('수정일 '):
            translated='Updated '+core[len('수정일 '):]
        if not core:
            return text
        start=len(text)-len(text.lstrip());end=len(text.rstrip())
        return text[:start]+translated+text[end:]

    def tag(self, tag, attrs, closed=False):
        rendered=[]
        for key,value in attrs:
            if value is not None:
                if tag=='html' and key=='lang': value='en'
                elif key in ('title','placeholder','aria-label','content'): value=self.text(value)
                elif key=='href' and value.startswith('/') and not value.startswith('//'):
                    if value=='/' or any(value.startswith(p) for p in ('/guides/','/about/','/terms/','/privacy/','/contact/','/debugger/','/native/')) or value=='/rss.xml':
                        value='/en'+value
                if key=='content' and value=='ko_KR': value='en_US'
            rendered.append(key if value is None else f'{key}="{html.escape(value,quote=True)}"')
        self.output.append('<'+tag+(' '+' '.join(rendered) if rendered else '')+(' />' if closed else '>'))

    def handle_starttag(self,tag,attrs): self.tag(tag,attrs)
    def handle_startendtag(self,tag,attrs): self.tag(tag,attrs,True)
    def handle_endtag(self,tag): self.output.append('</'+tag+'>')
    def handle_data(self,text): self.output.append(html.escape(self.text(text),quote=False))
    def handle_decl(self,decl): self.output.append('<!'+decl+'>')
    def handle_comment(self,data): self.output.append('<!--'+data+'-->')
    def handle_entityref(self,name): self.output.append('&'+name+';')
    def handle_charref(self,name): self.output.append('&#'+name+';')


def localize_markup(markup, path, language, base, public):
    # Remove previously generated language links when rebuilding the root template.
    markup=re.sub(r'<div class="language-switch".*?</div>','',markup,flags=re.S)
    markup=re.sub(r'<!-- LANG:START -->.*?<!-- LANG:END -->','',markup,flags=re.S)
    if language=='en':
        parser=EnglishMarkup();parser.feed(markup);markup=''.join(parser.output)
        if 'src="/app.js"' in markup or 'src="/contact.js"' in markup:
            markup=markup.replace('<script src=', '<script src="/en/ui.js"></script><script src=',1)
    markup=markup.replace('</nav>', '</nav>'+language_links(path,language),1)
    alternatives=''.join(f'<link rel="alternate" hreflang="{code}" href="{html.escape(base+language_path(path,code),quote=True)}">' for code in ('ko','en'))
    alternatives+=f'<link rel="alternate" hreflang="x-default" href="{html.escape(base+path,quote=True)}">'
    # Local preview keeps noindex; only a configured public origin gets hreflang.
    if public:
        markup=markup.replace('</head>','<!-- LANG:START -->'+alternatives+'<!-- LANG:END --></head>')
    if language=='en' and public:
        markup=markup.replace('rel="canonical" href="'+html.escape(base+path,quote=True)+'"','rel="canonical" href="'+html.escape(base+'/en'+path,quote=True)+'"')
    return markup
