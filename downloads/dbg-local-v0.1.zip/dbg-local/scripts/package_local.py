"""Package source and generated local pages without runtime state."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
files = [root / name for name in ['README.md', 'server.py', 'debugger.py', 'inferior_io.py', 'binary_info.py', 'start-windows.bat', 'start-linux.sh', '.gitignore', 'site_config.json']]
for folder in ['web', 'content', 'scripts', 'tests', 'examples']:
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.exe'))
with zipfile.ZipFile(root / 'dbg-local-v0.1.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, Path('dbg-local') / path.relative_to(root))
print('Updated dbg-local-v0.1.zip')
