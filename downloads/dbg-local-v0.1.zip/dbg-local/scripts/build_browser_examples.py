"""Generate small original, import-free x86/x64 CPU lab binaries."""
from pathlib import Path
import struct
ROOT=Path(__file__).resolve().parents[1]

def sum_code(bits,entry,data_address):
    # EAX = 5 + 4 + 3 + 2 + 1. Store it in memory, then HLT in CPU mode.
    code=bytes.fromhex('b8 00 00 00 00 bb 05 00 00 00 01 d8 83 eb 01 75 f9')
    if bits==32: code+=b'\xa3'+struct.pack('<I',data_address)
    else: code+=b'\x89\x05'+struct.pack('<i',data_address-(entry+len(code)+6))
    return code+b'\xf4'

def elf(bits,code=None):
    base=0x100000; entry=base+0x100;size=0x300
    image=bytearray(size);image[:16]=b'\x7fELF'+bytes([1 if bits==32 else 2,1,1])+bytes(9)
    if bits==32:
        struct.pack_into('<HHIIIIIHHHHHH',image,16,2,3,1,entry,52,0,0,52,32,1,0,0,0)
        struct.pack_into('<IIIIIIII',image,52,1,0,base,base,size,size,7,0x1000)
    else:
        struct.pack_into('<HHIQQQIHHHHHH',image,16,2,62,1,entry,64,0,0,64,56,1,0,0,0)
        struct.pack_into('<IIQQQQQQ',image,64,1,7,0,base,base,size,size,0x1000)
    code=sum_code(bits,entry,base+0x200) if code is None else code
    image[0x100:0x100+len(code)]=code
    return bytes(image)

def pe(bits):
    base=0x400000 if bits==32 else 0x140000000
    optional_size=224 if bits==32 else 240
    image=bytearray(0x400);image[:2]=b'MZ';struct.pack_into('<I',image,0x3c,0x80)
    image[0x80:0x84]=b'PE\0\0';struct.pack_into('<HHIIIHH',image,0x84,0x14c if bits==32 else 0x8664,1,0,0,0,optional_size,0x22)
    opt=0x98;struct.pack_into('<H',image,opt,0x10b if bits==32 else 0x20b)
    struct.pack_into('<I',image,opt+16,0x1000)
    struct.pack_into('<I' if bits==32 else '<Q',image,opt+(28 if bits==32 else 24),base)
    struct.pack_into('<II',image,opt+32,0x1000,0x200)
    struct.pack_into('<II',image,opt+56,0x2000,0x200);struct.pack_into('<H',image,opt+68,3)
    section=opt+optional_size;image[section:section+8]=b'.text\0\0\0'
    struct.pack_into('<IIIIIIHHI',image,section+8,0x1000,0x1000,0x200,0x200,0,0,0,0,0xe0000020)
    code=sum_code(bits,base+0x1000,base+0x1100);image[0x200:0x200+len(code)]=code
    return bytes(image)

def build():
    directory=ROOT/'web/browser-examples';directory.mkdir(exist_ok=True)
    for bits in [32,64]:
        (directory/f'sum{bits}.elf').write_bytes(elf(bits))
        (directory/f'sum{bits}.pe').write_bytes(pe(bits))

if __name__=='__main__':build()
