#!/usr/bin/env python3
"""Build plain HTML guides and policy pages. No framework or external dependencies."""
import argparse
import html
import json
import re
from pathlib import Path
from urllib.parse import urlsplit
from xml.etree import ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
WEB = PROJECT / 'web'
# Support both direct script execution and import by server/tests.
import sys
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))
from scripts.localization import localize_markup, language_path, EN


def esc(value):
    return html.escape(str(value), quote=True)


def sections_html(sections):
    output = []
    for i, section in enumerate(sections, 1):
        output.append(f'<section id="section-{i}"><h2>{esc(section["heading"])}</h2>')
        output.extend(f'<p>{esc(text)}</p>' for text in section['paragraphs'])
        if section.get('code'):
            output.append('<figure class="code-note"><figcaption>'+esc(section.get('code_title',''))+'</figcaption><pre><code>'+esc(section['code'])+'</code></pre></figure>')
        output.append('</section>')
    return ''.join(output)


def nav(active=''):
    entries = [('/', '디버거'), ('/guides/', '가이드'), ('/about/', '소개'),
               ('/terms/', '이용약관'), ('/privacy/', '개인정보처리방침'), ('/contact/', '문의')]
    return '<nav aria-label="주 메뉴">' + ''.join(
        f'<a href="{path}"' + (' aria-current="page"' if active == path else '') + f'>{label}</a>'
        for path, label in entries) + '</nav>'


def _build_language(base_url=None, output_root=None, language="ko"):
    config = json.loads((PROJECT / 'site_config.json').read_text())
    configured = (base_url if base_url is not None else config['public_url']).rstrip('/')
    if configured:
        u = urlsplit(configured)
        if u.scheme != 'https' or not u.hostname or u.username or u.password or u.path or u.query or u.fragment:
            raise ValueError('public_url must be an HTTPS origin without a path, credentials, query or fragment')
    base = configured or 'http://127.0.0.1:8765'
    destination = Path(output_root) if output_root else WEB
    generated = destination / 'generated'
    generated.mkdir(parents=True, exist_ok=True)
    content_root = PROJECT/'content' if language=='ko' else PROJECT/'content/en'
    articles = [json.loads(p.read_text()) for p in sorted((content_root/'articles').glob('*.json'))]
    slugs = set()
    for article in articles:
        slug = article['slug']
        if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', slug) or slug in slugs:
            raise ValueError('Invalid or duplicate article slug')
        slugs.add(slug)
        if sum(len(t) for s in article['sections'] for t in s['paragraphs']) < 1500:
            raise ValueError('Article is shorter than 1500 prose characters: ' + slug)
    pages = json.loads((content_root/'pages.json').read_text())
    routes = {}
    name = config['name']

    def shell(title, description, path, body, active='', script=''):
        canonical = f'<link rel="canonical" href="{esc(base+path)}">' if configured else '<meta name="robots" content="noindex, nofollow">'
        return f'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)} | {esc(name)}</title><meta name="description" content="{esc(description)}">
{canonical}<meta property="og:type" content="{'article' if path.startswith('/guides/') and path!='/guides/' else 'website'}"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:locale" content="ko_KR"><meta property="og:site_name" content="{esc(name)}">
<link rel="stylesheet" href="/style.css"><link rel="alternate" type="application/rss+xml" title="DBG Desk 가이드" href="/rss.xml"></head>
<body><header><a class="brand" href="/">{esc(name)}</a>{nav(active)}</header>
<main class="reading-layout">{body}</main><footer class="site-footer"><span>{esc(name)}</span><div><a href="/privacy/">개인정보처리방침</a> <a href="/terms/">이용약관</a> <a href="/contact/">문의</a> <a href="/rss.xml">RSS</a></div></footer>{script}</body></html>'''

    def write(path, filename, text, mime='text/html; charset=utf-8'):
        if mime.startswith('text/html'):
            text = localize_markup(text, path, language, base, bool(configured))
        path = language_path(path, language)
        if language=='en':
            filename='en/'+filename
        target = generated / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding='utf-8')
        routes[path] = ['generated/' + filename, mime]

    categories = list(dict.fromkeys(a['category'] for a in articles))
    listing = '<div class="reading-heading"><h1>가이드</h1><p>GDB를 사용하는 실습은 고급 로컬 모드 기준입니다. 브라우저 CPU 모드의 지원 범위는 디버거 화면에서 확인할 수 있습니다.</p></div>'
    listing += '<div class="guide-layout"><aside class="guide-categories"><strong>주제</strong>' + ''.join(f'<a href="#category-{i}">{esc(c)}</a>' for i,c in enumerate(categories)) + '<a href="/rss.xml">RSS 구독</a></aside><div class="guide-list">'
    for i, category in enumerate(categories):
        listing += f'<section id="category-{i}"><h2>{esc(category)}</h2><ol>'
        for article in articles:
            if article['category'] != category:
                continue
            listing += f'<li><span class="guide-number">{articles.index(article)+1:02d}</span><a href="/guides/{esc(article["slug"])}/">{esc(article["title"])}</a></li>'
        listing += '</ol></section>'
    listing += '</div></div>'
    write('/guides/', 'guides/index.html', shell('디버깅 가이드', ('Debugging guides and a verified CTF lab.' if language=='en' else f'네이티브 디버깅과 개발 오류, CTF 실습을 다루는 {len(articles)}편의 가이드입니다.'), '/guides/', listing, '/guides/'))

    for i, article in enumerate(articles):
        path = '/guides/' + article['slug'] + '/'
        toc = '<aside class="article-toc"><details open><summary>목차</summary><ol>' + ''.join(f'<li><a href="#section-{j}">{esc(s["heading"])}</a></li>' for j,s in enumerate(article['sections'],1)) + '</ol></details><a href="/guides/">전체 가이드</a></aside>'
        related = [a for a in articles if a['category'] == article['category'] and a != article][:3]
        if len(related)<2:
            related += [a for a in articles if a != article and a not in related][:2-len(related)]
        references = '<section class="references"><h2>참고 문서</h2><ul>' + ''.join(f'<li><a href="{esc(url)}" rel="external noreferrer">{esc(label)}</a></li>' for label,url in article['sources']) + '</ul></section>'
        body = f'<div class="breadcrumb"><a href="/guides/">가이드</a> / {esc(article["category"])}</div><div class="article-layout">{toc}<article class="guide-article"><div class="article-meta">{esc(article["category"])} · {esc(article.get("updated",config["updated"]))}</div><h1>{esc(article["title"])}</h1><div class="article-body">{sections_html(article["sections"])}</div>{references}<section class="related"><h2>함께 읽기</h2><ul>' + ''.join(f'<li><a href="/guides/{esc(a["slug"])}/">{esc(a["title"])}</a></li>' for a in related) + '</ul></section><p class="article-bottom"><a href="/guides/">가이드 목록</a> · <a href="/">디버거 열기</a></p></article></div>'
        write(path, 'guides/'+article['slug']+'/index.html', shell(article['title'], article['description'], path, body, '/guides/'))

    for slug, page in pages.items():
        path = f'/{slug}/'
        body = f'<article class="policy-article"><h1>{esc(page["title"])}</h1><p class="article-meta">수정일 {esc(page.get("updated",config["updated"]))}</p>{sections_html(page["sections"])}</article>'
        write(path, slug+'/index.html', shell(page['title'], page['description'], path, body, path))

    repository = config['github_repository'].rstrip('/')
    if not re.fullmatch(r'https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository):
        raise ValueError('Invalid contact repository')
    issue_url = repository + '/issues/new'
    body = '<article class="policy-article contact-page"><h1>문의하기</h1><p>오류 제보나 가이드 수정 의견을 보내주세요.</p><p>문의는 GitHub 이슈로 받습니다. GitHub 계정이 필요하며 등록한 내용은 누구나 볼 수 있습니다. 개인정보나 비밀 값은 적지 마세요.</p>' + f'<form id="contact-form" class="contact-form" data-issue-url="{esc(issue_url)}"><label for="contact-topic">분류</label><select id="contact-topic"><option>오류 제보</option><option>문서 수정</option><option>기능 제안</option><option>기타</option></select><label for="contact-subject">제목</label><input id="contact-subject" maxlength="160" required><label for="contact-message">내용</label><textarea id="contact-message" rows="10" maxlength="4000" required placeholder="사용 환경, 재현 순서, 오류 메시지를 적어주세요."></textarea><p>입력한 제목과 내용을 GitHub 작성 화면에 전달합니다. 검토한 뒤 GitHub에서 직접 등록해주세요.</p><button type="submit">GitHub에서 문의 작성</button><p id="contact-status" role="status" aria-live="polite"></p></form><p class="contact-help"><a href="{esc(repository)}/issues">기존 문의 보기</a></p><p>문의 내용에 인증 URL이나 비밀번호는 포함하지 마세요.</p></article>'
    write('/contact/', 'contact/index.html', shell('문의하기', 'DBG Desk 오류 제보, 문서 수정과 기능 제안을 보내주세요.', '/contact/', body, '/contact/', '<script src="/contact.js" defer></script>'))

    all_paths = [language_path('/',language)] + list(routes)
    sitemap = ET.Element('urlset', xmlns='http://www.sitemaps.org/schemas/sitemap/0.9')
    article_dates = {language_path('/guides/'+article['slug']+'/', language):article.get('updated',config['updated']) for article in articles}
    article_dates.update({language_path('/'+slug+'/',language):page.get('updated',config['updated']) for slug,page in pages.items()})
    for path in all_paths:
        item = ET.SubElement(sitemap, 'url')
        ET.SubElement(item,'loc').text=base+path
        ET.SubElement(item,'lastmod').text=article_dates.get(path,config['updated'])
    write('/sitemap.xml', 'sitemap.xml', '<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(sitemap,encoding='unicode'), 'application/xml; charset=utf-8')
    rss=ET.Element('rss',version='2.0'); channel=ET.SubElement(rss,'channel')
    for tag,text in [('title',name+' 가이드'),('link',base+language_path('/guides/',language)),('description','디버깅과 개발 오류 조사 가이드'),('language',language)]:
        ET.SubElement(channel,tag).text=EN.get(text,text) if language=='en' else text
    for article in articles:
        item=ET.SubElement(channel,'item'); url=base+language_path('/guides/'+article['slug']+'/',language)
        for tag,text in [('title',article['title']),('link',url),('guid',url),('description',article['description'])]:
            ET.SubElement(item,tag).text=text
    write('/rss.xml','rss.xml','<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(rss,encoding='unicode'),'application/rss+xml; charset=utf-8')
    robots = 'User-agent: *\n' + ('Disallow: /api/\nAllow: /\n' if configured else 'Disallow: /\n') + 'Sitemap: '+base+'/sitemap.xml\n'
    write('/robots.txt','robots.txt',robots,'text/plain; charset=utf-8')
    index = (WEB/'index.html').read_text()
    seo = f'<link rel="canonical" href="{esc(base+"/")}">' if configured else '<meta name="robots" content="noindex, nofollow">'
    index = re.sub(r'<!-- SEO:START -->.*?<!-- SEO:END -->', '<!-- SEO:START -->'+seo+'<!-- SEO:END -->', index, flags=re.S)
    index = localize_markup(index, '/', language, base, bool(configured))
    if language=='en':
        root_path=generated/'en/index.html'
        root_path.parent.mkdir(parents=True,exist_ok=True)
        root_path.write_text(index,encoding='utf-8')
        routes['/en/']=['generated/en/index.html','text/html; charset=utf-8']
        dictionary='window.DBG_I18N = '+json.dumps(EN,ensure_ascii=False)+';\n'
        write('/ui.js','ui.js',dictionary,'text/javascript; charset=utf-8')
    else:
        (destination/'index.html').write_text(index, encoding='utf-8')
    (destination/'routes.json').write_text(json.dumps(routes,ensure_ascii=False,indent=2)+'\n')
    return {'articles':len(articles),'pages':len(all_paths),'public':bool(configured),'base':base}


def build(base_url=None, output_root=None):
    destination=Path(output_root) if output_root else WEB
    ko=_build_language(base_url,output_root,'ko')
    routes=json.loads((destination/'routes.json').read_text())
    _build_language(base_url,output_root,'en')
    routes.update(json.loads((destination/'routes.json').read_text()))
    (destination/'routes.json').write_text(json.dumps(routes,ensure_ascii=False,indent=2)+'\n')
    html_paths=['/']+[path for path,(_,mime) in routes.items() if mime.startswith('text/html')]
    sitemap=ET.Element('urlset',xmlns='http://www.sitemaps.org/schemas/sitemap/0.9')
    dates = {}
    for source in (PROJECT/'content/articles').glob('*.json'):
        article = json.loads(source.read_text())
        for prefix in ['', '/en']:
            dates[prefix+'/guides/'+article['slug']+'/'] = article.get('updated', json.loads((PROJECT/'site_config.json').read_text())['updated'])
    for prefix, source in [('', PROJECT/'content/pages.json'),('/en', PROJECT/'content/en/pages.json')]:
        for slug,page in json.loads(source.read_text()).items():
            dates[prefix+'/'+slug+'/'] = page.get('updated',json.loads((PROJECT/'site_config.json').read_text())['updated'])
    for path in html_paths:
        item=ET.SubElement(sitemap,'url');ET.SubElement(item,'loc').text=ko['base']+path
        ET.SubElement(item,'lastmod').text=dates.get(path,json.loads((PROJECT/'site_config.json').read_text())['updated'])
    (destination/'generated/sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(sitemap,encoding='unicode'))
    return {**ko,'pages':len(html_paths),'languages':['ko','en']}


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--base-url',help='Future HTTPS origin for export; does not publish anything')
    args=parser.parse_args()
    print(json.dumps(build(args.base_url),ensure_ascii=False))
