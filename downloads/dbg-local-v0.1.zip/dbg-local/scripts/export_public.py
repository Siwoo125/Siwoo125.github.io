"""Export a static public site. Never publishes the local debugging API."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import tempfile
from scripts.build_content import build, esc
from scripts.localization import localize_markup
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def export(base_url, destination):
    config = json.loads((ROOT/'site_config.json').read_text())
    publisher = config.get('adsense_publisher_id', '')
    if publisher and not re.fullmatch(r'ca-pub-[0-9]{16}', publisher):
        raise ValueError('Invalid AdSense publisher ID')
    verification_tags = []
    cloudflare = base_url.rstrip('/') == config.get('cloudflare_public_url', '').rstrip('/')
    naver_field = 'cloudflare_naver_site_verification' if cloudflare and config.get('cloudflare_naver_site_verification') else 'naver_site_verification'
    verification_fields = [('google_site_verification','google-site-verification'), (naver_field,'naver-site-verification')]
    if cloudflare:
        verification_fields.append(('cloudflare_google_site_verification', 'google-site-verification'))
    for field, name in verification_fields:
        value = config.get(field, '')
        if value:
            if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,200}', value):
                raise ValueError('Invalid site verification token: '+field)
            verification_tags.append('<meta name="'+name+'" content="'+value+'">')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temporary:
        staging = Path(temporary)
        build(base_url, staging)
        routes = json.loads((staging/'routes.json').read_text())
        for route, (source, mime) in routes.items():
            target = destination / route.lstrip('/')
            if route.endswith('/'):
                target /= 'index.html'
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staging/source, target)
    for asset in ['style.css', 'contact.js', 'inspector.js', 'workbench.js', 'memory-tools.js', 'advanced.js', 'ctf.js', 'app.js']:
        shutil.copyfile(ROOT/'web'/asset, destination/asset)
    archive = ROOT/'dbg-local-v0.1.zip'
    downloads = destination/'downloads'
    downloads.mkdir(exist_ok=True)
    shutil.copyfile(archive, downloads/archive.name)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (downloads/(archive.name+'.sha256')).write_text(digest+'  '+archive.name+'\n')
    for language in ['ko','en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        target = destination/prefix.lstrip('/')/'index.html'
        # Reuse the document shell so navigation and locale links stay consistent.
        template = (destination/prefix.lstrip('/')/'about/index.html').read_text()
        title = 'Local debugger and debugging guides' if english else '로컬 디버거와 디버깅 가이드'
        body = ('<h1>DBG Desk</h1><p>A browser interface for GDB running on your computer.</p><p>Open a binary, set breakpoints and inspect registers, instructions, memory and the call stack. Search loaded memory with HEX patterns or UTF-8 text, inspect numeric values, compare two recorded stops and export a Markdown report. This public website provides guides and the source download; start the Python server on your PC to use the debugger.</p><h2>Run locally</h2><p>Install Python 3.10 or later and GDB. On Windows, install GDB and GCC with MSYS2 UCRT64:</p>' if english else '<h1>DBG Desk</h1><p>내 PC의 GDB를 브라우저에서 사용하는 디버거입니다.</p><p>바이너리를 열어 중단점을 걸고 명령어, 레지스터, 메모리와 호출 스택을 확인합니다. 메모리를 HEX·문자열로 검색하고 바이트를 정수·실수로 읽을 수 있습니다. 두 정지 시점의 값을 비교하고 Markdown 보고서로 저장할 수도 있습니다. 이 공개 사이트에서는 가이드와 소스를 제공합니다. 디버깅 화면은 내려받은 Python 서버를 PC에서 실행해 엽니다.</p><h2>로컬에서 실행하기</h2><p>Python 3.10 이상과 GDB가 필요합니다. Windows에서는 MSYS2 UCRT64 터미널에 다음 명령을 입력합니다.</p>')
        body = body.replace('<h2>Run locally</h2>' if english else '<h2>로컬에서 실행하기</h2>', '<p><a class="debugger-link" href="'+prefix+'/debugger/">'+('Open debugger' if english else '디버거 열기')+'</a></p>'+('<h2>Run locally</h2>' if english else '<h2>로컬에서 실행하기</h2>'))
        body += '<span id="setup"></span><pre><code>pacman -S --needed mingw-w64-ucrt-x86_64-gdb mingw-w64-ucrt-x86_64-gcc</code></pre>'
        body += '<p>'+('Extract the source ZIP, then run this command in its folder:' if english else '소스 ZIP을 풀고 해당 폴더의 터미널에서 실행합니다.')+'</p><pre><code>py -3 server.py --gdb C:\\msys64\\ucrt64\\bin\\gdb.exe</code></pre>'
        body += '<p>'+('Open the local URL printed in the terminal. Select or drop a file to load it; execution starts only when you press Run.' if english else '터미널에 나온 로컬 주소를 엽니다. 파일 선택이나 드래그로 바이너리를 불러온 뒤 실행 버튼을 누릅니다.')+'</p>'
        body += '<p><a download href="/downloads/dbg-local-v0.1.zip">'+('Download source ZIP' if english else '소스 ZIP 다운로드')+'</a> · <a href="/downloads/dbg-local-v0.1.zip.sha256">SHA-256</a></p>'
        body += '<h2>'+('Breakpoints and context' if english else '중단점과 조사 문맥')+'</h2><p>'+('Use comparison conditions, ignored hit counts and temporary breakpoints to narrow down stops. Data breakpoints can stop on memory changes or accesses. Select a thread or stack frame to inspect its registers and local variables. Source-line stepping and run to address complement instruction stepping.' if english else '조건 비교식, 건너뛸 횟수와 임시 중단점으로 필요한 정지 지점을 고릅니다. 데이터 중단점은 메모리 값의 변경이나 접근을 감시합니다. 스레드·호출 프레임을 선택해 해당 문맥의 레지스터와 지역 변수를 확인하고, 소스 줄 실행이나 선택 주소까지 실행할 수 있습니다.')+'</p>'
        body += '<h2>'+('Testing and limitations' if english else '검증 범위와 제한')+'</h2><p>'+('Native GDB debugging of a C example was verified on a GitHub Windows runner with MSYS2 UCRT64. This does not guarantee compatibility with every binary. GDB is installed separately. LLDB, WinDbg, disk file patching and reverse execution are not included. CTF tools support memory/register edits, ELF/PE headers, strings and first-instruction stops. Linux target input uses a PTY; Windows uses a separate console. The download contains source code and setup instructions, not a bundled GDB installation.' if english else 'GitHub Windows 환경의 MSYS2 UCRT64에서 C 예제의 실제 GDB 실행·중단점·스레드·프레임·메모리 조회를 검증했습니다. 모든 실행 파일의 호환성을 보장하지는 않습니다. GDB는 별도로 설치해야 합니다. CTF 도구는 메모리·레지스터 수정, ELF/PE 헤더·문자열과 첫 명령어 정지를 지원합니다. Linux는 웹 입력 패널을, Windows는 별도 콘솔을 사용합니다. LLDB·WinDbg 연결, 디스크 파일 패치와 역실행은 제공하지 않습니다. 다운로드에는 소스와 설치 설명이 포함되며 GDB 자체는 들어 있지 않습니다.')+'</p>'
        body += '<h2>'+('Debugging guides' if english else '디버깅 가이드')+'</h2><p>'+('Twenty-one guides cover breakpoints, stepping, symbols, memory errors and reading Python and JavaScript exceptions. Each article links to the relevant official documentation.' if english else '중단점, 단계 실행, 심볼과 메모리 오류부터 Python·JavaScript 오류 읽기까지 CTF 실습을 포함해 21편의 글을 정리했습니다. 각 글 아래에서 관련 공식 문서를 확인할 수 있습니다.')+f'</p><p><a href="{prefix}/guides/">'+('Browse guides' if english else '가이드 읽기')+'</a></p>'
        body += '<p><a href="'+prefix+'/guides/ctf-memory-edit-lab/">'+('CTF lab: change two memory locations to pass a gate' if english else 'CTF 실습: 메모리 두 곳을 바꿔 잠금 통과하기')+'</a></p>'
        template = re.sub(r'<main class="reading-layout">.*?</main>', lambda _: '<main class="reading-layout"><article class="policy-article">'+body+'</article></main>', template, flags=re.S)
        template = re.sub(r'<title>.*?</title>', '<title>'+title+' | DBG Desk</title>', template)
        for locale_prefix in ['', '/en']:
            template = template.replace(base_url+locale_prefix+'/about/', base_url+locale_prefix+'/')
        template = template.replace('href="/about/" lang=', 'href="/" lang=').replace('href="/en/about/" lang=', 'href="/en/" lang=')
        template = re.sub(r'(<meta name="description" content=")[^"]*', r'\g<1>'+title, template)
        template = template.replace('aria-current="page"', '')
        target.write_text(template)
        # Public-site policies supplement local-tool policies without changing local behavior.
        privacy = destination/prefix.lstrip('/')/'privacy/index.html'
        text = privacy.read_text()
        note = ('<section><h2>Public website</h2><p>This site serves static guides and a source download. It does not provide a file upload or a remote debugging API. The site contains no advertising or analytics code added by DBG Desk. The hosting infrastructure processes requests to deliver pages; its own service policies apply. Use the contact page to reach DBG Desk. Inquiries use public GitHub issues; do not include private information. The following sections describe the downloaded local tool.</p></section>' if english else '<section><h2>공개 웹사이트</h2><p>이 사이트는 가이드와 소스 다운로드를 제공합니다. 파일 업로드나 원격 디버깅 API는 공개하지 않습니다. DBG Desk가 추가한 광고·분석 코드는 없습니다. 호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다. 운영 및 문의 창구는 DBG Desk의 문의 페이지입니다. 문의는 공개 GitHub 이슈로 받으므로 개인정보를 적지 마세요. 아래 항목은 내려받아 사용하는 로컬 도구의 처리 방식입니다.</p></section>')
        text = text.replace('</h1>', '</h1>'+note, 1)
        privacy.write_text(text)

    # Publish the actual workspace separately from the site's introduction.
    for language in ['ko', 'en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        document = (ROOT/'web/index.html').read_text()
        document = document.replace('<html lang="ko">', '<html lang="ko" data-hosting="public">', 1)
        document = re.sub(r'<!-- SEO:START -->.*?<!-- SEO:END -->',
                          '<link rel="canonical" href="'+base_url+'/debugger/">', document, flags=re.S)
        document = localize_markup(document, '/debugger/', language, base_url, True)
        setup = ('<details id="engine-setup" class="engine-setup"><summary>Local engine connection</summary><p>The debugger workspace is open. Program execution needs GDB and the Python server on your PC. The public website has no running engine. Start server.py from the downloaded source; it opens an authenticated local workspace automatically.</p><p><a href="/downloads/dbg-local-v0.1.zip">Download local engine source</a> · <a href="/en/#setup">Setup instructions</a></p></details>' if english else '<details id="engine-setup" class="engine-setup"><summary>로컬 엔진 연결</summary><p>디버거 화면이 열렸습니다. 실제 프로그램 실행에는 PC의 GDB와 Python 서버가 필요합니다. 공개 사이트에는 실행 엔진이 연결돼 있지 않습니다. 내려받은 소스의 server.py를 실행하면 인증된 로컬 디버거 화면이 자동으로 열립니다.</p><p><a href="/downloads/dbg-local-v0.1.zip">로컬 엔진 소스 다운로드</a> · <a href="/#setup">설치 방법</a></p></details>')
        document = document.replace('<section class="target card"', setup+'<section class="target card"', 1)
        document = re.sub(r'(<span id="selected-file"[^>]*>).*?(</span>)',
                          lambda match: match[1]+('Connect a local engine to open a binary.' if english else '로컬 엔진에 연결하면 파일을 열 수 있습니다.')+match[2], document, flags=re.S)
        target = destination/prefix.lstrip('/')/'debugger/index.html'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(document)
    sitemap = destination/'sitemap.xml'
    tree = ET.parse(sitemap)
    namespace = '{http://www.sitemaps.org/schemas/sitemap/0.9}'
    for route in ['/debugger/', '/en/debugger/']:
        item = ET.SubElement(tree.getroot(), namespace+'url')
        ET.SubElement(item, namespace+'loc').text = base_url+route
        ET.SubElement(item, namespace+'lastmod').text = config['updated']
    ET.register_namespace('', namespace[1:-1])
    tree.write(sitemap, encoding='utf-8', xml_declaration=True)
    (destination/'launch.js').unlink(missing_ok=True)
    (destination/'download-prompt.js').unlink(missing_ok=True)

    if base_url.endswith('.github.io'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            text = text.replace('The hosting infrastructure processes requests to deliver pages; its own service policies apply.', 'GitHub Pages hosts this website. GitHub logs and stores visitor IP addresses for security, including visitors who are not signed in. See the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub Privacy Statement</a>.')
            text = text.replace('호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다.', '이 사이트는 GitHub Pages에서 제공합니다. GitHub는 로그인 여부와 관계없이 보안을 위해 방문자의 IP 주소를 기록·보관합니다. 자세한 내용은 <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub 개인정보처리방침</a>을 참고하세요.')
            page.write_text(text)
        (destination/'.nojekyll').touch()
    if base_url.endswith('.pages.dev'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>Cloudflare Pages hosting</h2><p>Cloudflare Pages delivers this static website. The hosting service may process connection information and use security cookies to deliver and protect the site. See the <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare Privacy Policy</a>. DBG Desk does not upload local debugging data to this hosting service.</p></section>' if prefix else '<section><h2>Cloudflare Pages 호스팅</h2><p>이 정적 웹사이트는 Cloudflare Pages에서 제공합니다. 호스팅 서비스는 사이트 전달과 보호를 위해 연결 정보를 처리하거나 보안 쿠키를 사용할 수 있습니다. 자세한 내용은 <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare 개인정보처리방침</a>을 참고하세요. DBG Desk의 로컬 디버깅 정보는 이 호스팅 서비스로 업로드하지 않습니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    for page in destination.rglob('*.html'):
        text = page.read_text()
        # Every public navigation enters the workspace, not the introduction.
        text = re.sub(r'(<nav\b[^>]*>)(.*?)(</nav>)',
                      lambda match: match[1] + match[2].replace('href="/"', 'href="/debugger/"').replace('href="/en/"', 'href="/en/debugger/"') + match[3], text, flags=re.S)
        if verification_tags:
            text = text.replace('</head>', ''.join(verification_tags)+'</head>')
        if publisher:
            text = text.replace('</head>', '<meta name="google-adsense-account" content="'+publisher+'"></head>')
        text=text.replace('href="/downloads/dbg-local-v0.1.zip"', 'href="/downloads/dbg-local-v0.1.zip?v='+digest[:12]+'"')
        page.write_text(text)
    if publisher:
        (destination/'ads.txt').write_text('google.com, '+publisher.removeprefix('ca-')+', DIRECT, f08c47fec0942fa0\n')
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>AdSense site verification</h2><p>This website includes a Google AdSense publisher verification meta tag and an ads.txt authorization record for a site review. These entries do not load advertising scripts or set advertising cookies. Advertising is not currently served. This policy and any required consent settings will be updated before advertising code is enabled.</p></section>' if prefix else '<section><h2>애드센스 사이트 확인</h2><p>사이트 심사를 위해 Google AdSense 게시자 확인용 메타 태그와 ads.txt 판매자 승인 정보를 게시했습니다. 이 정보 자체는 광고 스크립트를 실행하거나 광고 쿠키를 생성하지 않습니다. 현재 광고는 게재하지 않으며, 광고 코드를 도입하기 전에 개인정보처리방침과 필요한 동의 설정을 갱신합니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    return {'base_url' :base_url, 'pages':len(list(destination.rglob('*.html'))), 'sha256':digest}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--destination', default=str(ROOT/'public-site/dist'))
    args = parser.parse_args()
    print(json.dumps(export(args.base_url, args.destination)))
