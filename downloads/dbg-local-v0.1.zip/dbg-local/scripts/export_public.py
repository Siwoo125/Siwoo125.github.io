"""Export a static public site. Never publishes the local debugging API."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import tempfile
from scripts.build_content import build, esc, nav
from scripts.localization import localize_markup
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def gdb_prompt(english):
    title = 'Local GDB mode' if english else '로컬 GDB 모드'
    intro = 'Download the local connector to debug programs on your computer.' if english else 'PC의 프로그램을 디버깅하려면 로컬 연결 프로그램을 내려받으세요.'
    note = 'Extract the ZIP, install Python and GDB, then start the connector.' if english else 'ZIP을 풀고 Python과 GDB를 설치한 뒤 연결 프로그램을 실행하세요.'
    return ('<dialog id="gdb-download-dialog" class="gdb-download-dialog" aria-labelledby="gdb-download-title">'
            '<button type="button" class="gdb-dialog-close" data-gdb-close aria-label="'+('Close' if english else '닫기')+'">×</button>'
            '<h2 id="gdb-download-title">'+title+'</h2><p>'+intro+'</p><p class="gdb-download-note">'+note+'</p>'
            '<div class="gdb-dialog-actions"><a id="gdb-download-link" download href="/downloads/dbg-local-v0.1.zip">'+('Download GDB connector' if english else 'GDB 모드 다운로드')+'</a>'
            '<button type="button" data-gdb-close autofocus>'+('Continue in browser' if english else '브라우저에서 계속')+'</button></div>'
            '<p><a id="gdb-setup-link" href="#setup">'+('Setup instructions' if english else '설치 방법')+'</a></p>'
            '<p class="gdb-download-note">'+('Browser mode works without downloading anything.' if english else '브라우저 모드는 다운로드 없이 사용할 수 있습니다.')+'</p></dialog>'
            '<script src="/gdb-download-prompt.js" defer></script>')

def export(base_url, destination):
    config = json.loads((ROOT/'site_config.json').read_text())
    publisher = config.get('adsense_publisher_id', '')
    if publisher and not re.fullmatch(r'ca-pub-[0-9]{16}', publisher):
        raise ValueError('Invalid AdSense publisher ID')
    slot = config.get('adsense_guide_slot', '')
    if slot and not re.fullmatch(r'[0-9]{1,20}', slot):
        raise ValueError('Invalid AdSense guide slot')
    ad_origins = config.get('adsense_enabled_origins', [])
    if not isinstance(ad_origins, list) or any(not isinstance(origin, str) or not re.fullmatch(r'https://[A-Za-z0-9.-]+', origin) for origin in ad_origins):
        raise ValueError('AdSense origins must be HTTPS origins without paths')
    ads_enabled = base_url.rstrip('/') in ad_origins
    if ads_enabled and (not publisher or not slot):
        raise ValueError('An enabled advertising origin needs a publisher and guide slot')
    verification_tags = []
    cloudflare = base_url.rstrip('/') == config.get('cloudflare_public_url', '').rstrip('/')
    naver_field = 'cloudflare_naver_site_verification' if cloudflare and config.get('cloudflare_naver_site_verification') else 'naver_site_verification'
    verification_fields = [('google_site_verification','google-site-verification'), (naver_field,'naver-site-verification')]
    if cloudflare:
        verification_fields.append(('cloudflare_google_site_verification', 'google-site-verification'))
    for field, name in verification_fields:
        value = config.get(field, '')
        if value:
            if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,200}', value):
                raise ValueError('Invalid site verification token: '+field)
            verification_tags.append('<meta name="'+name+'" content="'+value+'">')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temporary:
        staging = Path(temporary)
        build(base_url, staging)
        routes = json.loads((staging/'routes.json').read_text())
        for route, (source, mime) in routes.items():
            target = destination / route.lstrip('/')
            if route.endswith('/'):
                target /= 'index.html'
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staging/source, target)
    for asset in ['style.css', 'contact.js', 'inspector.js', 'workbench.js', 'memory-tools.js', 'advanced.js', 'ctf.js', 'app.js', 'browser-ui.js', 'browser-storage.js', 'browser-engine.js', 'browser-worker.js', 'browser.css', 'guide-ads.js', 'gdb-download-prompt.js']:
        shutil.copyfile(ROOT/'web'/asset, destination/asset)
    shutil.copytree(ROOT/'web/vendor', destination/'vendor', dirs_exist_ok=True)
    shutil.copytree(ROOT/'web/browser-examples', destination/'browser-examples', dirs_exist_ok=True)
    archive = ROOT/'dbg-local-v0.1.zip'
    downloads = destination/'downloads'
    downloads.mkdir(exist_ok=True)
    shutil.copyfile(archive, downloads/archive.name)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (downloads/(archive.name+'.sha256')).write_text(digest+'  '+archive.name+'\n')
    setup_sections = {}
    for language in ['ko','en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        target = destination/prefix.lstrip('/')/'index.html'
        # Reuse the document shell so navigation and locale links stay consistent.
        template = (destination/prefix.lstrip('/')/'about/index.html').read_text()
        title = 'Browser debugger and debugging guides' if english else '브라우저 디버거와 디버깅 가이드'
        paragraphs = [
            'Open an ELF or PE file and step through its x86/x64 instructions in your browser. Registers and memory sit next to the code. There is nothing to install, and your file is not uploaded.',
            'Set a breakpoint by clicking an address, or edit a register or memory value while stopped. Not sure where to start? Open an ELF or PE example and follow the loop that adds 5 down to 1.',
            'With auto-save on, this browser keeps your latest file, execution position, memory, breakpoints and input/output in this browser. Wait for the saved indicator before closing. Reload the page to pick up where you left off.',
            'Browser mode emulates the CPU and a few Linux input/output calls. It cannot load Linux shared libraries or Windows DLLs and APIs. Use local GDB mode when your program needs those, or when you need to attach to a process or inspect source symbols. The guides cover setup, breakpoints, memory errors and CTF exercises.'
        ] if english else [
            'ELF·PE 파일을 열고 x86/x64 명령어를 한 줄씩 실행해 보세요. 코드 옆에서 레지스터와 메모리가 어떻게 바뀌는지 볼 수 있습니다. 따로 설치할 프로그램은 없고, 파일을 서버로 보내지도 않습니다.',
            '주소를 누르면 중단점이 생깁니다. 멈춘 상태에서 레지스터나 메모리 값을 바꿀 수도 있습니다. 처음이라면 ELF·PE 예제를 열어 보세요. 5부터 1까지 더하는 짧은 반복문으로 시작할 수 있습니다.',
            '자동 저장을 켜 두면 마지막 작업이 이 브라우저에 남습니다. 저장됨 표시를 확인하고 닫으면 됩니다. 다시 열거나 새로고침해도 파일, 실행 위치, 메모리, 중단점과 입력·출력을 이어서 볼 수 있습니다.',
            '브라우저 모드에서는 CPU와 일부 Linux 입력·출력만 실행합니다. Linux 공유 라이브러리나 Windows DLL·API가 필요한 프로그램은 로컬 GDB 모드를 쓰세요. 실행 중인 프로세스에 붙거나 소스 심볼을 볼 때도 GDB가 필요합니다. 설치 방법과 중단점, 메모리 오류, CTF 실습은 가이드에 정리했습니다.'
        ]
        body = '<h1>DBG Desk</h1>' + ''.join('<p>'+esc(text)+'</p>' for text in paragraphs)
        body += '<p><a class="debugger-link" href="'+prefix+'/debugger/">'+('Open browser debugger' if english else '브라우저 디버거 열기')+'</a></p>'
        body += '<p><a href="'+prefix+'/guides/">'+('Read guides' if english else '가이드 읽기')+'</a> · <a href="'+prefix+'/native/">'+('Advanced local GDB mode' if english else '고급 로컬 GDB 모드')+'</a></p>'
        body += '<details id="setup"><summary>'+('Local GDB setup and source download' if english else '로컬 GDB 설치 안내와 소스 다운로드')+'</summary><p>'+('For native debugging, install Python 3.10 or later and GDB. On Windows, install GDB with MSYS2 UCRT64:' if english else '운영체제의 실제 프로그램을 디버깅하려면 Python 3.10 이상과 GDB가 필요합니다. Windows에서는 MSYS2 UCRT64로 GDB를 준비합니다.')+'</p><pre><code>pacman -S --needed mingw-w64-ucrt-x86_64-gdb mingw-w64-ucrt-x86_64-gcc</code></pre><p>'+('Extract the ZIP and double-click start-windows.bat. On Linux, run sh start-linux.sh.' if english else 'ZIP을 풀고 Windows에서는 start-windows.bat를 엽니다. Linux에서는 sh start-linux.sh로 실행합니다.')+'</p><p><a download href="/downloads/dbg-local-v0.1.zip">'+('Download local GDB source' if english else '로컬 GDB 소스 다운로드')+'</a> · <a href="/downloads/dbg-local-v0.1.zip.sha256">SHA-256</a></p></details>'
        setup_sections[language] = re.search(r'<details id="setup">.*?</details>', body, re.S)[0].replace('<details id="setup">', '<details id="setup" class="cpu-help">', 1)
        template = re.sub(r'<main class="reading-layout">.*?</main>', lambda _: '<main class="reading-layout"><article class="policy-article">'+body+'</article></main>', template, flags=re.S)
        template = re.sub(r'<title>.*?</title>', '<title>'+title+' | DBG Desk</title>', template)
        for locale_prefix in ['', '/en']:
            template = template.replace(base_url+locale_prefix+'/about/', base_url+locale_prefix+'/')
        template = template.replace('href="/about/" lang=', 'href="/" lang=').replace('href="/en/about/" lang=', 'href="/en/" lang=')
        template = re.sub(r'(<meta name="description" content=")[^"]*', r'\g<1>'+title, template)
        template = re.sub(r'(<meta property="og:title" content=")[^"]*', lambda m:m[1]+esc(title), template)
        template = re.sub(r'(<meta property="og:description" content=")[^"]*', lambda m:m[1]+esc(paragraphs[0]), template)
        template = template.replace('aria-current="page"', '')
        target.write_text(template)
        # Public-site policies supplement local-tool policies without changing local behavior.
        privacy = destination/prefix.lstrip('/')/'privacy/index.html'
        text = privacy.read_text()
        note = ('<section><h2>Public website</h2><p>This site serves a browser CPU debugger, static guides and a source download. It does not provide a file upload or a remote debugging API. The site contains no advertising or analytics code added by DBG Desk. The hosting infrastructure processes requests to deliver pages; its own service policies apply. Use the contact page to reach DBG Desk. Inquiries use public GitHub issues; do not include private information. The sections below distinguish browser mode and local GDB data handling.</p></section>' if english else '<section><h2>공개 웹사이트</h2><p>이 사이트는 브라우저 CPU 디버거, 가이드와 소스 다운로드를 제공합니다. 파일 업로드나 원격 디버깅 API는 공개하지 않습니다. DBG Desk가 추가한 광고·분석 코드는 없습니다. 호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다. 운영 및 문의 창구는 DBG Desk의 문의 페이지입니다. 문의는 공개 GitHub 이슈로 받으므로 개인정보를 적지 마세요. 아래 항목에서 브라우저 모드와 로컬 GDB의 처리 방식을 구분해 설명합니다.</p></section>')
        if ads_enabled:
            note = note.replace('The site contains no advertising or analytics code added by DBG Desk.', 'Guide articles and the bottom of the browser debugger load Google AdSense. Local GDB debugger pages do not load advertising code. No separate analytics script is added.')
            note = note.replace('DBG Desk가 추가한 광고·분석 코드는 없습니다.', '가이드 글과 브라우저 디버거 하단에는 Google AdSense 광고가 있습니다. 로컬 GDB 화면에는 광고 코드를 넣지 않으며 별도 분석 스크립트도 추가하지 않습니다.')
        text = text.replace('</h1>', '</h1>'+note, 1)
        privacy.write_text(text)

    # Publish the actual workspace separately from the site's introduction.
    for language in ['ko', 'en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        document = (ROOT/'web/index.html').read_text()
        document = document.replace('<html lang="ko">', '<html lang="ko" data-hosting="public">', 1)
        document = re.sub(r'<!-- SEO:START -->.*?<!-- SEO:END -->',
                          '<link rel="canonical" href="'+base_url+'/native/">', document, flags=re.S)
        document = localize_markup(document, '/native/', language, base_url, True)
        setup = ('<details id="engine-setup" class="engine-setup"><summary>Connect local GDB</summary><p>This mode needs GDB and Python on your computer. Download the source and run server.py to open the connected debugger.</p><p><a href="/downloads/dbg-local-v0.1.zip">Download local engine source</a> · <a href="/en/#setup">Setup instructions</a></p></details>' if english else '<details id="engine-setup" class="engine-setup"><summary>로컬 GDB 연결하기</summary><p>이 모드는 PC에 GDB와 Python이 필요합니다. 소스를 내려받아 server.py를 실행하면 GDB에 연결된 디버거가 열립니다.</p><p><a href="/downloads/dbg-local-v0.1.zip">로컬 엔진 소스 다운로드</a> · <a href="/#setup">설치 방법</a></p></details>')
        document = document.replace('<section class="target card"', setup+'<section class="target card"', 1)
        document = re.sub(r'(<span id="selected-file"[^>]*>).*?(</span>)',
                          lambda match: match[1]+('Connect a local engine to open a binary.' if english else '로컬 엔진에 연결하면 파일을 열 수 있습니다.')+match[2], document, flags=re.S)
        target = destination/prefix.lstrip('/')/'native/index.html'
        target.parent.mkdir(parents=True, exist_ok=True)
        switch = '<p><a href="'+prefix+'/debugger/">'+('Open browser mode without installation' if english else '설치 없이 브라우저 모드 열기')+'</a></p>'
        document = document.replace('<main', switch+'<main', 1)
        target.write_text(document)
        browser_source = (ROOT/'web/browser.html').read_text().replace('<!-- BROWSER:NAV -->', nav('/'))
        for route in ['/', '/debugger/']:
            browser = localize_markup(browser_source, route, language, base_url, True)
            # The root opens the debugger directly; /debugger/ remains an alias.
            browser = browser.replace('</head>', '<link rel="canonical" href="'+base_url+prefix+'/debugger/"></head>')
            browser = browser.replace('</main>', setup_sections[language]+'</main>', 1)
            browser = browser.replace('</header>', '<button type="button" id="cpu-gdb-download">'+('Local GDB download' if english else 'GDB 모드 다운로드')+'</button></header>', 1)
            browser = browser.replace('</body>', gdb_prompt(english)+'</body>', 1)
            browser_target = destination/(prefix+route).lstrip('/')/'index.html'
            browser_target.parent.mkdir(parents=True,exist_ok=True)
            browser_target.write_text(browser)
    sitemap = destination/'sitemap.xml'
    tree = ET.parse(sitemap)
    namespace = '{http://www.sitemaps.org/schemas/sitemap/0.9}'
    for item in tree.getroot():
        if item.find(namespace+'loc').text in [base_url+'/',base_url+'/en/']:
            item.find(namespace+'lastmod').text=config.get('browser_updated',config['updated'])
    for route in ['/debugger/', '/en/debugger/', '/native/', '/en/native/']:
        item = ET.SubElement(tree.getroot(), namespace+'url')
        ET.SubElement(item, namespace+'loc').text = base_url+route
        ET.SubElement(item, namespace+'lastmod').text = config.get('browser_updated',config['updated'])
    ET.register_namespace('', namespace[1:-1])
    tree.write(sitemap, encoding='utf-8', xml_declaration=True)
    (destination/'launch.js').unlink(missing_ok=True)
    (destination/'download-prompt.js').unlink(missing_ok=True)

    if base_url.endswith('.github.io'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            text = text.replace('The hosting infrastructure processes requests to deliver pages; its own service policies apply.', 'GitHub Pages hosts this website. GitHub logs and stores visitor IP addresses for security, including visitors who are not signed in. See the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub Privacy Statement</a>.')
            text = text.replace('호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다.', '이 사이트는 GitHub Pages에서 제공합니다. GitHub는 로그인 여부와 관계없이 보안을 위해 방문자의 IP 주소를 기록·보관합니다. 자세한 내용은 <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub 개인정보처리방침</a>을 참고하세요.')
            page.write_text(text)
        (destination/'.nojekyll').touch()
    if base_url.endswith('.pages.dev'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>Cloudflare Pages hosting</h2><p>Cloudflare Pages delivers this static website. The hosting service may process connection information and use security cookies to deliver and protect the site. See the <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare Privacy Policy</a>. DBG Desk does not upload local debugging data to this hosting service.</p></section>' if prefix else '<section><h2>Cloudflare Pages 호스팅</h2><p>이 정적 웹사이트는 Cloudflare Pages에서 제공합니다. 호스팅 서비스는 사이트 전달과 보호를 위해 연결 정보를 처리하거나 보안 쿠키를 사용할 수 있습니다. 자세한 내용은 <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare 개인정보처리방침</a>을 참고하세요. DBG Desk의 로컬 디버깅 정보는 이 호스팅 서비스로 업로드하지 않습니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    for page in destination.rglob('*.html'):
        text = page.read_text()
        route = page.relative_to(destination).as_posix()
        browser_ad = route in ('index.html', 'en/index.html', 'debugger/index.html', 'en/debugger/index.html')
        guide_ad = re.fullmatch(r'(?:en/)?guides/[a-z0-9-]+/index\.html', route)
        if ads_enabled and (guide_ad or browser_ad):
            label = 'Advertisement' if route.startswith('en/') else '광고'
            ad_class = 'guide-ad debugger-ad' if browser_ad else 'guide-ad'
            ad = ('<aside class="'+ad_class+'" aria-label="'+label+'"><span class="guide-ad-label">'+label+'</span>'
                  '<ins class="adsbygoogle" style="display:block" data-ad-client="'+publisher+'" data-ad-slot="'+slot+'" data-ad-format="auto" data-full-width-responsive="true"></ins>'
                  '</aside>')
            # The debugger ad follows all controls and help, without covering them.
            if browser_ad:
                text = text.replace('</main>', ad+'</main>', 1)
            else:
                text = text.replace('<section class="related">', ad+'<section class="related">', 1)
            loader = '<script src="/guide-ads.js" defer data-ad-origin="'+base_url.rstrip('/')+'" data-ad-client="'+publisher+'"></script>'
            text = text.replace('</head>', loader+'</head>', 1)
        # Every public navigation enters the workspace, not the introduction.
        text = re.sub(r'(<nav\b[^>]*>)(.*?)(</nav>)',
                      lambda match: match[1] + match[2].replace('href="/"', 'href="/debugger/"').replace('href="/en/"', 'href="/en/debugger/"') + match[3], text, flags=re.S)
        if verification_tags:
            text = text.replace('</head>', ''.join(verification_tags)+'</head>')
        if publisher:
            text = text.replace('</head>', '<meta name="google-adsense-account" content="'+publisher+'"></head>')
        text=text.replace('href="/downloads/dbg-local-v0.1.zip"', 'href="/downloads/dbg-local-v0.1.zip?v='+digest[:12]+'"')
        page.write_text(text)
    if publisher:
        (destination/'ads.txt').write_text('google.com, '+publisher.removeprefix('ca-')+', DIRECT, f08c47fec0942fa0\n')
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>AdSense site verification</h2><p>This website includes a Google AdSense publisher verification meta tag and an ads.txt authorization record for a site review. These entries do not load advertising scripts or set advertising cookies. Advertising is not currently served. This policy and any required consent settings will be updated before advertising code is enabled.</p></section>' if prefix else '<section><h2>애드센스 사이트 확인</h2><p>사이트 심사를 위해 Google AdSense 게시자 확인용 메타 태그와 ads.txt 판매자 승인 정보를 게시했습니다. 이 정보 자체는 광고 스크립트를 실행하거나 광고 쿠키를 생성하지 않습니다. 현재 광고는 게재하지 않으며, 광고 코드를 도입하기 전에 개인정보처리방침과 필요한 동의 설정을 갱신합니다.</p></section>')
            if ads_enabled:
                note = ('<section><h2>Google AdSense</h2><p>Google and third-party advertising providers may use cookies to show ads based on visits to this and other websites. Guide articles and the bottom of the browser debugger on dbgdesk.pages.dev load Google AdSense. Local GDB pages do not. Learn about <a href="https://policies.google.com/technologies/ads">Google advertising data use</a> and <a href="https://policies.google.com/privacy">Google’s privacy policy</a>. You can manage personalized ads in <a href="https://www.google.com/settings/ads">Google Ad Settings</a> or use the <a href="https://www.aboutads.info/choices/">third-party advertising opt-out tools</a>.</p></section>' if prefix else '<section><h2>Google AdSense</h2><p>Google과 제3자 광고 제공업체는 쿠키를 사용해 이 사이트와 다른 웹사이트의 방문 기록을 바탕으로 광고를 표시할 수 있습니다. dbgdesk.pages.dev의 가이드 글과 브라우저 디버거 하단에서 Google AdSense를 불러옵니다. 로컬 GDB 화면에는 광고를 넣지 않습니다. <a href="https://policies.google.com/technologies/ads">Google 광고의 데이터 사용 방식</a>과 <a href="https://policies.google.com/privacy">Google 개인정보처리방침</a>을 참고하세요. 개인 맞춤 광고는 <a href="https://www.google.com/settings/ads">Google 광고 설정</a>에서 관리하거나 <a href="https://www.aboutads.info/choices/">제3자 광고 쿠키 수신 거부 도구</a>로 설정할 수 있습니다.</p></section>')
            else:
                note = note.replace('Advertising is not currently served. This policy and any required consent settings will be updated before advertising code is enabled.', 'No advertising script is loaded on this website origin. AdSense advertising is enabled only on the approved dbgdesk.pages.dev origin, as described below.')
                note = note.replace('현재 광고는 게재하지 않으며, 광고 코드를 도입하기 전에 개인정보처리방침과 필요한 동의 설정을 갱신합니다.', '이 사이트 주소에서는 광고 스크립트를 불러오지 않습니다. 애드센스 광고는 승인된 dbgdesk.pages.dev 주소에서만 사용하며 아래에서 설명합니다.')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    return {'base_url' :base_url, 'pages':len(list(destination.rglob('*.html'))), 'sha256':digest}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--destination', default=str(ROOT/'public-site/dist'))
    args = parser.parse_args()
    print(json.dumps(export(args.base_url, args.destination)))
