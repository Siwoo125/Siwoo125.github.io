"""Export a static public site. Never publishes the local debugging API."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import tempfile
from scripts.build_content import build, esc

ROOT = Path(__file__).resolve().parents[1]

def export(base_url, destination):
    config = json.loads((ROOT/'site_config.json').read_text())
    publisher = config.get('adsense_publisher_id', '')
    if publisher and not re.fullmatch(r'ca-pub-[0-9]{16}', publisher):
        raise ValueError('Invalid AdSense publisher ID')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temporary:
        staging = Path(temporary)
        build(base_url, staging)
        routes = json.loads((staging/'routes.json').read_text())
        for route, (source, mime) in routes.items():
            target = destination / route.lstrip('/')
            if route.endswith('/'):
                target /= 'index.html'
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staging/source, target)
    for asset in ['style.css', 'contact.js']:
        shutil.copyfile(ROOT/'web'/asset, destination/asset)
    archive = ROOT/'dbg-local-v0.1.zip'
    downloads = destination/'downloads'
    downloads.mkdir(exist_ok=True)
    shutil.copyfile(archive, downloads/archive.name)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (downloads/(archive.name+'.sha256')).write_text(digest+'  '+archive.name+'\n')
    for language in ['ko','en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        target = destination/prefix.lstrip('/')/'index.html'
        # Reuse the document shell so navigation and locale links stay consistent.
        template = (destination/prefix.lstrip('/')/'about/index.html').read_text()
        title = 'Local debugger and debugging guides' if english else '로컬 디버거와 디버깅 가이드'
        body = ('<h1>DBG Desk</h1><p>A browser interface for GDB running on your computer.</p><p>Open a binary, set breakpoints and inspect registers, instructions, memory and the call stack. Search loaded memory with HEX patterns or UTF-8 text, inspect numeric values, compare two recorded stops and export a Markdown report. This public website provides guides and the source download; start the Python server on your PC to use the debugger.</p><h2>Run locally</h2><p>Install Python 3.10 or later and GDB. On Windows, install GDB and GCC with MSYS2 UCRT64:</p>' if english else '<h1>DBG Desk</h1><p>내 PC의 GDB를 브라우저에서 사용하는 디버거입니다.</p><p>바이너리를 열어 중단점을 걸고 명령어, 레지스터, 메모리와 호출 스택을 확인합니다. 메모리를 HEX·문자열로 검색하고 바이트를 정수·실수로 읽을 수 있습니다. 두 정지 시점의 값을 비교하고 Markdown 보고서로 저장할 수도 있습니다. 이 공개 사이트에서는 가이드와 소스를 제공합니다. 디버깅 화면은 내려받은 Python 서버를 PC에서 실행해 엽니다.</p><h2>로컬에서 실행하기</h2><p>Python 3.10 이상과 GDB가 필요합니다. Windows에서는 MSYS2 UCRT64 터미널에 다음 명령을 입력합니다.</p>')
        body += '<pre><code>pacman -S --needed mingw-w64-ucrt-x86_64-gdb mingw-w64-ucrt-x86_64-gcc</code></pre>'
        body += '<p>'+('Extract the source ZIP, then run this command in its folder:' if english else '소스 ZIP을 풀고 해당 폴더의 터미널에서 실행합니다.')+'</p><pre><code>py -3 server.py --gdb C:\\msys64\\ucrt64\\bin\\gdb.exe</code></pre>'
        body += '<p>'+('Open the local URL printed in the terminal. Select or drop a file to load it; execution starts only when you press Run.' if english else '터미널에 나온 로컬 주소를 엽니다. 파일 선택이나 드래그로 바이너리를 불러온 뒤 실행 버튼을 누릅니다.')+'</p>'
        body += '<p><a download href="/downloads/dbg-local-v0.1.zip">'+('Download source ZIP' if english else '소스 ZIP 다운로드')+'</a> · <a href="/downloads/dbg-local-v0.1.zip.sha256">SHA-256</a></p>'
        body += '<h2>'+('Breakpoints and context' if english else '중단점과 조사 문맥')+'</h2><p>'+('Use comparison conditions, ignored hit counts and temporary breakpoints to narrow down stops. Data breakpoints can stop on memory changes or accesses. Select a thread or stack frame to inspect its registers and local variables. Source-line stepping and run to address complement instruction stepping.' if english else '조건 비교식, 건너뛸 횟수와 임시 중단점으로 필요한 정지 지점을 고릅니다. 데이터 중단점은 메모리 값의 변경이나 접근을 감시합니다. 스레드·호출 프레임을 선택해 해당 문맥의 레지스터와 지역 변수를 확인하고, 소스 줄 실행이나 선택 주소까지 실행할 수 있습니다.')+'</p>'
        body += '<h2>'+('Testing and limitations' if english else '검증 범위와 제한')+'</h2><p>'+('Native GDB debugging of a C example was verified on a GitHub Windows runner with MSYS2 UCRT64. This does not guarantee compatibility with every binary. GDB is installed separately. LLDB, WinDbg, memory editing and an interactive target terminal are not included. The download contains source code and setup instructions, not a bundled GDB installation.' if english else 'GitHub Windows 환경의 MSYS2 UCRT64에서 C 예제의 실제 GDB 실행·중단점·스레드·프레임·메모리 조회를 검증했습니다. 모든 실행 파일의 호환성을 보장하지는 않습니다. GDB는 별도로 설치해야 합니다. LLDB·WinDbg 연결, 메모리 수정, 대상 프로그램용 대화형 터미널은 제공하지 않습니다. 다운로드에는 소스와 설치 설명이 포함되며 GDB 자체는 들어 있지 않습니다.')+'</p>'
        body += '<h2>'+('Debugging guides' if english else '디버깅 가이드')+'</h2><p>'+('Twenty guides cover breakpoints, stepping, symbols, memory errors and reading Python and JavaScript exceptions. Each article links to the relevant official documentation.' if english else '중단점, 단계 실행, 심볼과 메모리 오류부터 Python·JavaScript 오류 읽기까지 20편의 글을 정리했습니다. 각 글 아래에서 관련 공식 문서를 확인할 수 있습니다.')+f'</p><p><a href="{prefix}/guides/">'+('Browse guides' if english else '가이드 읽기')+'</a></p>'
        template = re.sub(r'<main class="reading-layout">.*?</main>', lambda _: '<main class="reading-layout"><article class="policy-article">'+body+'</article></main>', template, flags=re.S)
        template = re.sub(r'<title>.*?</title>', '<title>'+title+' | DBG Desk</title>', template)
        for locale_prefix in ['', '/en']:
            template = template.replace(base_url+locale_prefix+'/about/', base_url+locale_prefix+'/')
        template = template.replace('href="/about/" lang=', 'href="/" lang=').replace('href="/en/about/" lang=', 'href="/en/" lang=')
        template = re.sub(r'(<meta name="description" content=")[^"]*', r'\g<1>'+title, template)
        template = template.replace('aria-current="page"', '')
        target.write_text(template)
        # Public-site policies supplement local-tool policies without changing local behavior.
        privacy = destination/prefix.lstrip('/')/'privacy/index.html'
        text = privacy.read_text()
        note = ('<section><h2>Public website</h2><p>This site serves static guides and a source download. It does not provide a file upload or a remote debugging API. The site contains no advertising or analytics code added by DBG Desk. The hosting infrastructure processes requests to deliver pages; its own service policies apply. Contact: DBG Desk, psiwoo66@gmail.com. Email inquiries are handled in Gmail; deletion requests can be sent to the same address. The following sections describe the downloaded local tool.</p></section>' if english else '<section><h2>공개 웹사이트</h2><p>이 사이트는 가이드와 소스 다운로드를 제공합니다. 파일 업로드나 원격 디버깅 API는 공개하지 않습니다. DBG Desk가 추가한 광고·분석 코드는 없습니다. 호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다. 운영 및 문의 창구는 DBG Desk, psiwoo66@gmail.com입니다. 문의 메일은 Gmail에서 처리하며 같은 주소로 삭제를 요청할 수 있습니다. 아래 항목은 내려받아 사용하는 로컬 도구의 처리 방식입니다.</p></section>')
        text = text.replace('</h1>', '</h1>'+note, 1)
        text = text.replace('공개 서비스 운영에 앞서 문의 메일의 보관 기간과 삭제 절차를 확정해 이 안내에 추가할 예정입니다.', '문의 메일은 답변과 후속 확인에 필요한 동안 보관합니다. 삭제 요청은 같은 주소로 보내주세요.')
        text = text.replace('Before public operation, a retention period and deletion procedure for inquiry emails will be established and added to this notice.', 'Inquiry emails are retained for replies and follow-up. Send deletion requests to the same address.')
        privacy.write_text(text)
        # Remove obsolete pre-publication status from public copies only.
        for slug in ['about','privacy','terms']:
            page = destination/prefix.lstrip('/')/slug/'index.html'
            document = page.read_text()
            document = document.replace('현재는 로컬 테스트 단계이며 공개 배포와 광고 연동은 하지 않았습니다.', '가이드와 소스를 공개하고 있습니다. 광고는 연결하지 않았습니다.')
            document = document.replace('현재는 공개 배포 전의 로컬 개발 단계입니다. 공개 운영 전에는 운영자 식별 정보와 실제 운영에 필요한 정책 항목을 보완합니다.', '운영 명칭은 DBG Desk이며 이메일로 문의와 개인정보 관련 요청을 받습니다.')
            document = document.replace('공개 호스팅 서비스나 외부 계정 연동은 운영하지 않습니다.', '공개 웹사이트와 로컬 도구의 데이터 처리는 위 적용 범위를 참고하세요.')
            document = document.replace('There is no public hosting service or external account integration.', 'The public website and local tool have separate data handling as described above.')
            document = document.replace('The project is being tested locally. Public deployment and advertising integration have not been performed.', 'The guides and source are publicly available. Advertising is not connected.')
            document = document.replace('The project is currently in local development before public deployment. Operator identification and other policy details required for actual public operation remain to be completed before that stage.', 'The operator uses the name DBG Desk and handles inquiries and data requests at that address.')
            page.write_text(document)

    if base_url.endswith('.github.io'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            text = text.replace('The hosting infrastructure processes requests to deliver pages; its own service policies apply.', 'GitHub Pages hosts this website. GitHub logs and stores visitor IP addresses for security, including visitors who are not signed in. See the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub Privacy Statement</a>.')
            text = text.replace('호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다.', '이 사이트는 GitHub Pages에서 제공합니다. GitHub는 로그인 여부와 관계없이 보안을 위해 방문자의 IP 주소를 기록·보관합니다. 자세한 내용은 <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub 개인정보처리방침</a>을 참고하세요.')
            page.write_text(text)
        (destination/'.nojekyll').touch()
    for page in destination.rglob('*.html'):
        text = page.read_text().replace('디버거 열기', '디버거 설치 안내').replace('Open debugger', 'Debugger setup')
        if publisher:
            text = text.replace('</head>', '<meta name="google-adsense-account" content="'+publisher+'"></head>')
        text=text.replace('href="/downloads/dbg-local-v0.1.zip"', 'href="/downloads/dbg-local-v0.1.zip?v='+digest[:12]+'"')
        page.write_text(text)
    if publisher:
        (destination/'ads.txt').write_text('google.com, '+publisher.removeprefix('ca-')+', DIRECT, f08c47fec0942fa0\n')
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>AdSense site verification</h2><p>This website includes a Google AdSense publisher verification meta tag and an ads.txt authorization record for a site review. These entries do not load advertising scripts or set advertising cookies. Advertising is not currently served. This policy and any required consent settings will be updated before advertising code is enabled.</p></section>' if prefix else '<section><h2>애드센스 사이트 확인</h2><p>사이트 심사를 위해 Google AdSense 게시자 확인용 메타 태그와 ads.txt 판매자 승인 정보를 게시했습니다. 이 정보 자체는 광고 스크립트를 실행하거나 광고 쿠키를 생성하지 않습니다. 현재 광고는 게재하지 않으며, 광고 코드를 도입하기 전에 개인정보처리방침과 필요한 동의 설정을 갱신합니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    return {'base_url' :base_url, 'pages':len(list(destination.rglob('*.html'))), 'sha256':digest}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--destination', default=str(ROOT/'public-site/dist'))
    args = parser.parse_args()
    print(json.dumps(export(args.base_url, args.destination)))
