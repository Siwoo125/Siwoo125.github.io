"""Export a static public site. Never publishes the local debugging API."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import tempfile
from scripts.build_content import build, esc, nav
from scripts.localization import localize_markup
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def export(base_url, destination):
    config = json.loads((ROOT/'site_config.json').read_text())
    publisher = config.get('adsense_publisher_id', '')
    if publisher and not re.fullmatch(r'ca-pub-[0-9]{16}', publisher):
        raise ValueError('Invalid AdSense publisher ID')
    verification_tags = []
    cloudflare = base_url.rstrip('/') == config.get('cloudflare_public_url', '').rstrip('/')
    naver_field = 'cloudflare_naver_site_verification' if cloudflare and config.get('cloudflare_naver_site_verification') else 'naver_site_verification'
    verification_fields = [('google_site_verification','google-site-verification'), (naver_field,'naver-site-verification')]
    if cloudflare:
        verification_fields.append(('cloudflare_google_site_verification', 'google-site-verification'))
    for field, name in verification_fields:
        value = config.get(field, '')
        if value:
            if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,200}', value):
                raise ValueError('Invalid site verification token: '+field)
            verification_tags.append('<meta name="'+name+'" content="'+value+'">')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temporary:
        staging = Path(temporary)
        build(base_url, staging)
        routes = json.loads((staging/'routes.json').read_text())
        for route, (source, mime) in routes.items():
            target = destination / route.lstrip('/')
            if route.endswith('/'):
                target /= 'index.html'
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staging/source, target)
    for asset in ['style.css', 'contact.js', 'inspector.js', 'workbench.js', 'memory-tools.js', 'advanced.js', 'ctf.js', 'app.js', 'browser-ui.js', 'browser-storage.js', 'browser-engine.js', 'browser-worker.js', 'browser.css']:
        shutil.copyfile(ROOT/'web'/asset, destination/asset)
    shutil.copytree(ROOT/'web/vendor', destination/'vendor', dirs_exist_ok=True)
    shutil.copytree(ROOT/'web/browser-examples', destination/'browser-examples', dirs_exist_ok=True)
    archive = ROOT/'dbg-local-v0.1.zip'
    downloads = destination/'downloads'
    downloads.mkdir(exist_ok=True)
    shutil.copyfile(archive, downloads/archive.name)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (downloads/(archive.name+'.sha256')).write_text(digest+'  '+archive.name+'\n')
    for language in ['ko','en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        target = destination/prefix.lstrip('/')/'index.html'
        # Reuse the document shell so navigation and locale links stay consistent.
        template = (destination/prefix.lstrip('/')/'about/index.html').read_text()
        title = 'Browser debugger and debugging guides' if english else '브라우저 디버거와 디버깅 가이드'
        paragraphs = [
            'DBG Desk runs x86/x64 machine code in your browser. Choose an ELF or PE file to inspect instructions, registers and memory, with no Python installation or local engine connection. Selected files stay in this tab.',
            'Step through one instruction at a time, continue to an address breakpoint, and edit registers or mapped memory while stopped. The included ELF and PE examples let you check the same calculation in both 32-bit and 64-bit mode.',
            'Browser mode provides CPU emulation and a limited Linux input/output interface. Linux dynamic loaders and shared libraries, and Windows DLLs and APIs, are not included. It stops with an explanation when a required operation is unavailable. Use advanced local GDB mode for native operating-system behavior, process attachment, symbols and the existing investigation tools.',
            'Twenty-one Korean and English guide topics explain breakpoints, stepping, memory errors and reproducible investigations. The verified CTF lab uses local GDB. The public website and browser mode do not upload your binary or debugging state.'
        ] if english else [
            'DBG Desk는 브라우저 안에서 x86/x64 기계어를 실행하는 디버거입니다. ELF나 PE 파일을 선택하면 명령어, 레지스터와 메모리를 확인할 수 있습니다. Python 설치나 로컬 엔진 연결 없이 시작하며 선택한 파일은 이 탭 안에서 처리합니다.',
            '명령어를 하나씩 실행하거나 주소 중단점까지 진행하고, 정지 상태에서 레지스터와 매핑된 메모리를 수정합니다. 포함된 ELF·PE 예제로 같은 계산을 32비트와 64비트에서 각각 따라갈 수 있습니다.',
            '브라우저 모드는 CPU 실행과 제한된 Linux 입력·출력을 제공합니다. Linux 동적 로더·공유 라이브러리와 Windows DLL·API는 포함하지 않습니다. 지원하지 않는 동작이 필요하면 이유를 표시하고 멈춥니다. 운영체제의 실제 동작, 프로세스 Attach, 심볼과 기존 조사 도구가 필요하면 고급 로컬 GDB 모드를 사용하세요.',
            '한국어·영어 21개 주제의 가이드에서 중단점과 단계 실행, 메모리 오류와 재현 방법을 다룹니다. 검증된 CTF 실습은 로컬 GDB 기준입니다. 공개 사이트와 브라우저 모드는 바이너리와 디버깅 상태를 서버로 업로드하지 않습니다.'
        ]
        body = '<h1>DBG Desk</h1>' + ''.join('<p>'+esc(text)+'</p>' for text in paragraphs)
        body += '<p><a class="debugger-link" href="'+prefix+'/debugger/">'+('Open browser debugger' if english else '브라우저 디버거 열기')+'</a></p>'
        body += '<p><a href="'+prefix+'/guides/">'+('Read guides' if english else '가이드 읽기')+'</a> · <a href="'+prefix+'/native/">'+('Advanced local GDB mode' if english else '고급 로컬 GDB 모드')+'</a></p>'
        body += '<details id="setup"><summary>'+('Local GDB setup and source download' if english else '로컬 GDB 설치 안내와 소스 다운로드')+'</summary><p>'+('For native debugging, install Python 3.10 or later and GDB. On Windows, install GDB with MSYS2 UCRT64:' if english else '운영체제의 실제 프로그램을 디버깅하려면 Python 3.10 이상과 GDB가 필요합니다. Windows에서는 MSYS2 UCRT64로 GDB를 준비합니다.')+'</p><pre><code>pacman -S --needed mingw-w64-ucrt-x86_64-gdb mingw-w64-ucrt-x86_64-gcc</code></pre><p>'+('Extract the ZIP and double-click start-windows.bat. On Linux, run sh start-linux.sh.' if english else 'ZIP을 풀고 Windows에서는 start-windows.bat를 엽니다. Linux에서는 sh start-linux.sh로 실행합니다.')+'</p><p><a download href="/downloads/dbg-local-v0.1.zip">'+('Download local GDB source' if english else '로컬 GDB 소스 다운로드')+'</a> · <a href="/downloads/dbg-local-v0.1.zip.sha256">SHA-256</a></p></details>'
        template = re.sub(r'<main class="reading-layout">.*?</main>', lambda _: '<main class="reading-layout"><article class="policy-article">'+body+'</article></main>', template, flags=re.S)
        template = re.sub(r'<title>.*?</title>', '<title>'+title+' | DBG Desk</title>', template)
        for locale_prefix in ['', '/en']:
            template = template.replace(base_url+locale_prefix+'/about/', base_url+locale_prefix+'/')
        template = template.replace('href="/about/" lang=', 'href="/" lang=').replace('href="/en/about/" lang=', 'href="/en/" lang=')
        template = re.sub(r'(<meta name="description" content=")[^"]*', r'\g<1>'+title, template)
        template = re.sub(r'(<meta property="og:title" content=")[^"]*', lambda m:m[1]+esc(title), template)
        template = re.sub(r'(<meta property="og:description" content=")[^"]*', lambda m:m[1]+esc(paragraphs[0]), template)
        template = template.replace('aria-current="page"', '')
        target.write_text(template)
        # Public-site policies supplement local-tool policies without changing local behavior.
        privacy = destination/prefix.lstrip('/')/'privacy/index.html'
        text = privacy.read_text()
        note = ('<section><h2>Public website</h2><p>This site serves a browser CPU debugger, static guides and a source download. It does not provide a file upload or a remote debugging API. The site contains no advertising or analytics code added by DBG Desk. The hosting infrastructure processes requests to deliver pages; its own service policies apply. Use the contact page to reach DBG Desk. Inquiries use public GitHub issues; do not include private information. The sections below distinguish browser mode and local GDB data handling.</p></section>' if english else '<section><h2>공개 웹사이트</h2><p>이 사이트는 브라우저 CPU 디버거, 가이드와 소스 다운로드를 제공합니다. 파일 업로드나 원격 디버깅 API는 공개하지 않습니다. DBG Desk가 추가한 광고·분석 코드는 없습니다. 호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다. 운영 및 문의 창구는 DBG Desk의 문의 페이지입니다. 문의는 공개 GitHub 이슈로 받으므로 개인정보를 적지 마세요. 아래 항목에서 브라우저 모드와 로컬 GDB의 처리 방식을 구분해 설명합니다.</p></section>')
        text = text.replace('</h1>', '</h1>'+note, 1)
        privacy.write_text(text)

    # Publish the actual workspace separately from the site's introduction.
    for language in ['ko', 'en']:
        prefix = '/en' if language == 'en' else ''
        english = language == 'en'
        document = (ROOT/'web/index.html').read_text()
        document = document.replace('<html lang="ko">', '<html lang="ko" data-hosting="public">', 1)
        document = re.sub(r'<!-- SEO:START -->.*?<!-- SEO:END -->',
                          '<link rel="canonical" href="'+base_url+'/native/">', document, flags=re.S)
        document = localize_markup(document, '/native/', language, base_url, True)
        setup = ('<details id="engine-setup" class="engine-setup"><summary>Local engine connection</summary><p>The debugger workspace is open. Program execution needs GDB and the Python server on your PC. The public website has no running engine. Start server.py from the downloaded source; it opens an authenticated local workspace automatically.</p><p><a href="/downloads/dbg-local-v0.1.zip">Download local engine source</a> · <a href="/en/#setup">Setup instructions</a></p></details>' if english else '<details id="engine-setup" class="engine-setup"><summary>로컬 엔진 연결</summary><p>디버거 화면이 열렸습니다. 실제 프로그램 실행에는 PC의 GDB와 Python 서버가 필요합니다. 공개 사이트에는 실행 엔진이 연결돼 있지 않습니다. 내려받은 소스의 server.py를 실행하면 인증된 로컬 디버거 화면이 자동으로 열립니다.</p><p><a href="/downloads/dbg-local-v0.1.zip">로컬 엔진 소스 다운로드</a> · <a href="/#setup">설치 방법</a></p></details>')
        document = document.replace('<section class="target card"', setup+'<section class="target card"', 1)
        document = re.sub(r'(<span id="selected-file"[^>]*>).*?(</span>)',
                          lambda match: match[1]+('Connect a local engine to open a binary.' if english else '로컬 엔진에 연결하면 파일을 열 수 있습니다.')+match[2], document, flags=re.S)
        target = destination/prefix.lstrip('/')/'native/index.html'
        target.parent.mkdir(parents=True, exist_ok=True)
        switch = '<p><a href="'+prefix+'/debugger/">'+('Open browser mode without installation' if english else '설치 없이 브라우저 모드 열기')+'</a></p>'
        document = document.replace('<main', switch+'<main', 1)
        target.write_text(document)
        browser = (ROOT/'web/browser.html').read_text().replace('<!-- BROWSER:NAV -->', nav('/'))
        browser = localize_markup(browser, '/debugger/', language, base_url, True)
        browser = browser.replace('</head>', '<link rel="canonical" href="'+base_url+prefix+'/debugger/"></head>')
        browser_target = destination/prefix.lstrip('/')/'debugger/index.html'
        browser_target.parent.mkdir(parents=True,exist_ok=True)
        browser_target.write_text(browser)
    sitemap = destination/'sitemap.xml'
    tree = ET.parse(sitemap)
    namespace = '{http://www.sitemaps.org/schemas/sitemap/0.9}'
    for item in tree.getroot():
        if item.find(namespace+'loc').text in [base_url+'/',base_url+'/en/']:
            item.find(namespace+'lastmod').text=config.get('browser_updated',config['updated'])
    for route in ['/debugger/', '/en/debugger/', '/native/', '/en/native/']:
        item = ET.SubElement(tree.getroot(), namespace+'url')
        ET.SubElement(item, namespace+'loc').text = base_url+route
        ET.SubElement(item, namespace+'lastmod').text = config.get('browser_updated',config['updated'])
    ET.register_namespace('', namespace[1:-1])
    tree.write(sitemap, encoding='utf-8', xml_declaration=True)
    (destination/'launch.js').unlink(missing_ok=True)
    (destination/'download-prompt.js').unlink(missing_ok=True)

    if base_url.endswith('.github.io'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            text = text.replace('The hosting infrastructure processes requests to deliver pages; its own service policies apply.', 'GitHub Pages hosts this website. GitHub logs and stores visitor IP addresses for security, including visitors who are not signed in. See the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub Privacy Statement</a>.')
            text = text.replace('호스팅 인프라는 페이지 전달을 위해 요청을 처리하며 해당 서비스의 정책이 적용됩니다.', '이 사이트는 GitHub Pages에서 제공합니다. GitHub는 로그인 여부와 관계없이 보안을 위해 방문자의 IP 주소를 기록·보관합니다. 자세한 내용은 <a href="https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement">GitHub 개인정보처리방침</a>을 참고하세요.')
            page.write_text(text)
        (destination/'.nojekyll').touch()
    if base_url.endswith('.pages.dev'):
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>Cloudflare Pages hosting</h2><p>Cloudflare Pages delivers this static website. The hosting service may process connection information and use security cookies to deliver and protect the site. See the <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare Privacy Policy</a>. DBG Desk does not upload local debugging data to this hosting service.</p></section>' if prefix else '<section><h2>Cloudflare Pages 호스팅</h2><p>이 정적 웹사이트는 Cloudflare Pages에서 제공합니다. 호스팅 서비스는 사이트 전달과 보호를 위해 연결 정보를 처리하거나 보안 쿠키를 사용할 수 있습니다. 자세한 내용은 <a href="https://www.cloudflare.com/privacypolicy/">Cloudflare 개인정보처리방침</a>을 참고하세요. DBG Desk의 로컬 디버깅 정보는 이 호스팅 서비스로 업로드하지 않습니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    for page in destination.rglob('*.html'):
        text = page.read_text()
        # Every public navigation enters the workspace, not the introduction.
        text = re.sub(r'(<nav\b[^>]*>)(.*?)(</nav>)',
                      lambda match: match[1] + match[2].replace('href="/"', 'href="/debugger/"').replace('href="/en/"', 'href="/en/debugger/"') + match[3], text, flags=re.S)
        if verification_tags:
            text = text.replace('</head>', ''.join(verification_tags)+'</head>')
        if publisher:
            text = text.replace('</head>', '<meta name="google-adsense-account" content="'+publisher+'"></head>')
        text=text.replace('href="/downloads/dbg-local-v0.1.zip"', 'href="/downloads/dbg-local-v0.1.zip?v='+digest[:12]+'"')
        page.write_text(text)
    if publisher:
        (destination/'ads.txt').write_text('google.com, '+publisher.removeprefix('ca-')+', DIRECT, f08c47fec0942fa0\n')
        for prefix in ['', 'en/']:
            page = destination/prefix/'privacy/index.html'
            text = page.read_text()
            note = ('<section><h2>AdSense site verification</h2><p>This website includes a Google AdSense publisher verification meta tag and an ads.txt authorization record for a site review. These entries do not load advertising scripts or set advertising cookies. Advertising is not currently served. This policy and any required consent settings will be updated before advertising code is enabled.</p></section>' if prefix else '<section><h2>애드센스 사이트 확인</h2><p>사이트 심사를 위해 Google AdSense 게시자 확인용 메타 태그와 ads.txt 판매자 승인 정보를 게시했습니다. 이 정보 자체는 광고 스크립트를 실행하거나 광고 쿠키를 생성하지 않습니다. 현재 광고는 게재하지 않으며, 광고 코드를 도입하기 전에 개인정보처리방침과 필요한 동의 설정을 갱신합니다.</p></section>')
            page.write_text(text.replace('</h1>', '</h1>'+note, 1))
    return {'base_url' :base_url, 'pages':len(list(destination.rglob('*.html'))), 'sha256':digest}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--destination', default=str(ROOT/'public-site/dist'))
    args = parser.parse_args()
    print(json.dumps(export(args.base_url, args.destination)))
